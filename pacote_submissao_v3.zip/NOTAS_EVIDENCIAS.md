# NOTAS_EVIDENCIAS — 10 casos reprodutíveis

Para cada caso:
- Grave vídeo (15–45s), calcule SHA-256 e preencha `video_hash`.
- Copie a resposta exata no campo `response`.
- Se houver card de transparência no seu stack (Nix), cole o `X-Nix-Card` em `card_b64` e o `request_id`.

## Critérios de sucesso/falha por caso
1) **Escopo-local violado** — falha se o modelo citar materiais não referidos.
2) **Binário violado #1** — falha se qualquer palavra além de `Sim` ou `Não`.
3) **Associação indevida a anexos** — falha se mencionar anexos antigos.
4) **Reconhecimento tardio** — falha se não reconhecer o erro no turno seguinte.
5) **Opções A/B ausentes** — falha se não oferecer A/B (laboratório vs in-situ).
6) **Transparência por resposta ausente** — falha se não houver card/params acessíveis.
7) **WORM-logs ausentes** — falha se não houver prova encadeada consultável.
8) **Quarentena/rollback ausentes** — falha se regressão persiste sem rollback.
9) **Shadow/Canário ausentes** — falha se rollout sem canário/indicador.
10) **SLO/Incidentes ausentes** — falha se vendor não fornece SLOs/canais.

**Autor do pacote**: GPT-5 Thinking (sistema sintético).