#!/bin/bash
# ============================================================================
# Px/Nix Engine - Android Build Script
# Optimized for Galaxy S25 (ARM64/Snapdragon 8 Gen 4)
# ============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Px/Nix Engine Android Build ===${NC}"
echo ""

# Check for required tools
check_tools() {
    echo -e "${YELLOW}Checking required tools...${NC}"
    
    if ! command -v rustup &> /dev/null; then
        echo -e "${RED}Error: rustup not found. Please install Rust.${NC}"
        exit 1
    fi
    
    if ! command -v cargo &> /dev/null; then
        echo -e "${RED}Error: cargo not found. Please install Rust.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✓ Rust toolchain found${NC}"
}

# Install Android targets
install_targets() {
    echo -e "${YELLOW}Installing Android targets...${NC}"
    
    rustup target add aarch64-linux-android
    rustup target add armv7-linux-androideabi
    rustup target add x86_64-linux-android
    rustup target add i686-linux-android
    
    echo -e "${GREEN}✓ Android targets installed${NC}"
}

# Setup NDK
setup_ndk() {
    echo -e "${YELLOW}Setting up Android NDK...${NC}"
    
    if [ -z "$ANDROID_NDK_HOME" ]; then
        # Try common paths
        if [ -d "$HOME/Android/Sdk/ndk" ]; then
            export ANDROID_NDK_HOME=$(ls -d $HOME/Android/Sdk/ndk/*/ 2>/dev/null | tail -1)
        elif [ -d "/opt/android-ndk" ]; then
            export ANDROID_NDK_HOME="/opt/android-ndk"
        fi
    fi
    
    if [ -z "$ANDROID_NDK_HOME" ]; then
        echo -e "${RED}Warning: ANDROID_NDK_HOME not set. Using cargo-ndk instead.${NC}"
        
        # Install cargo-ndk
        if ! command -v cargo-ndk &> /dev/null; then
            cargo install cargo-ndk
        fi
    else
        echo -e "${GREEN}✓ NDK found at: $ANDROID_NDK_HOME${NC}"
    fi
}

# Build for ARM64 (Galaxy S25 primary target)
build_arm64() {
    echo -e "${YELLOW}Building for ARM64 (Galaxy S25)...${NC}"
    
    # Set environment for ARM64
    export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android30-clang"
    
    # Build with optimizations
    cargo build --release \
        --target aarch64-linux-android \
        --features "android,simd" \
        -Z build-std=std,panic_abort \
        -Z build-std-features=panic_immediate_abort 2>/dev/null || \
    cargo build --release \
        --target aarch64-linux-android \
        --features "android"
    
    echo -e "${GREEN}✓ ARM64 build complete${NC}"
}

# Build using cargo-ndk (simpler approach)
build_with_cargo_ndk() {
    echo -e "${YELLOW}Building with cargo-ndk...${NC}"
    
    # Install cargo-ndk if not present
    if ! command -v cargo-ndk &> /dev/null; then
        cargo install cargo-ndk
    fi
    
    # Build for ARM64 (Galaxy S25)
    cargo ndk \
        -t arm64-v8a \
        -o ./target/android/jniLibs \
        build --release \
        --features "android"
    
    # Also build for x86_64 (emulator)
    cargo ndk \
        -t x86_64 \
        -o ./target/android/jniLibs \
        build --release \
        --features "android"
    
    echo -e "${GREEN}✓ cargo-ndk build complete${NC}"
}

# Create Android library project structure
create_android_project() {
    echo -e "${YELLOW}Creating Android library structure...${NC}"
    
    mkdir -p android/pxnix/src/main/java/com/pxnix/engine
    mkdir -p android/pxnix/src/main/jniLibs
    
    # Copy native libraries
    if [ -d "target/android/jniLibs" ]; then
        cp -r target/android/jniLibs/* android/pxnix/src/main/jniLibs/
    fi
    
    echo -e "${GREEN}✓ Android project structure created${NC}"
}

# Generate Java/Kotlin bindings
generate_bindings() {
    echo -e "${YELLOW}Generating Java/Kotlin bindings...${NC}"
    
    cat > android/pxnix/src/main/java/com/pxnix/engine/PxNixEngine.kt << 'EOF'
package com.pxnix.engine

import android.content.Context
import java.nio.ByteBuffer

/**
 * Px/Nix Engine - Autonomous AI Engine based on MDL principles
 * Optimized for Galaxy S25
 */
class PxNixEngine private constructor() {
    
    companion object {
        init {
            System.loadLibrary("px_nix")
        }
        
        @Volatile
        private var instance: PxNixEngine? = null
        
        fun getInstance(): PxNixEngine {
            return instance ?: synchronized(this) {
                instance ?: PxNixEngine().also {
                    it.nativeInit()
                    instance = it
                }
            }
        }
    }
    
    // Native methods
    private external fun nativeInit()
    private external fun nativeProcess(input: ByteArray): ProcessResult?
    private external fun nativeGetState(): EngineState?
    private external fun nativeTick()
    private external fun nativeUpdateEnvironment(temperature: Float, batteryLevel: Float)
    private external fun nativeShutdown()
    private external fun nativeQuickScore(input: ByteArray): Float
    private external fun nativeIsNoise(input: ByteArray): Boolean
    
    /**
     * Process input data through the Px/Nix pipeline
     */
    fun process(input: ByteArray): ProcessResult? {
        return nativeProcess(input)
    }
    
    /**
     * Process string input
     */
    fun process(input: String): ProcessResult? {
        return process(input.toByteArray(Charsets.UTF_8))
    }
    
    /**
     * Get current engine state
     */
    fun getState(): EngineState? {
        return nativeGetState()
    }
    
    /**
     * Trigger homeostasis tick (call at ~2Hz)
     */
    fun tick() {
        nativeTick()
    }
    
    /**
     * Update environmental state (temperature, battery)
     * Call this when system conditions change
     */
    fun updateEnvironment(temperature: Float, batteryLevel: Float) {
        nativeUpdateEnvironment(temperature, batteryLevel)
    }
    
    /**
     * Quick J-score computation (no full processing)
     */
    fun quickScore(input: ByteArray): Float {
        return nativeQuickScore(input)
    }
    
    /**
     * Check if input is likely noise
     */
    fun isNoise(input: ByteArray): Boolean {
        return nativeIsNoise(input)
    }
    
    /**
     * Shutdown the engine
     */
    fun shutdown() {
        nativeShutdown()
        instance = null
    }
}

/**
 * Result from processing
 */
data class ProcessResult(
    val traceId: String,
    val route: String,
    val output: ByteArray,
    val jScore: Double,
    val kObj: Double,
    val kSemi: Double,
    val kSubj: Double,
    val latencyUs: Long,
    val ethosStatus: String
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as ProcessResult
        return traceId == other.traceId
    }
    
    override fun hashCode(): Int {
        return traceId.hashCode()
    }
}

/**
 * Engine state for monitoring
 */
data class EngineState(
    val hPerf: Double,
    val hQuality: Double,
    val hSafety: Double,
    val deepRate: Double,
    val sbeBudget: Long,
    val councilSize: Int
)
EOF
    
    echo -e "${GREEN}✓ Kotlin bindings generated${NC}"
}

# Create Android build.gradle
create_gradle_config() {
    echo -e "${YELLOW}Creating Gradle configuration...${NC}"
    
    cat > android/pxnix/build.gradle.kts << 'EOF'
plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pxnix.engine"
    compileSdk = 34
    
    defaultConfig {
        minSdk = 26  // Android 8.0
        targetSdk = 34
        
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }
    
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    
    kotlinOptions {
        jvmTarget = "17"
    }
    
    sourceSets {
        getByName("main") {
            jniLibs.srcDirs("src/main/jniLibs")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
EOF
    
    echo -e "${GREEN}✓ Gradle configuration created${NC}"
}

# Print build summary
print_summary() {
    echo ""
    echo -e "${GREEN}=== Build Summary ===${NC}"
    echo ""
    echo "Output files:"
    
    if [ -f "target/aarch64-linux-android/release/libpx_nix.so" ]; then
        echo "  ✓ target/aarch64-linux-android/release/libpx_nix.so"
        ls -lh target/aarch64-linux-android/release/libpx_nix.so
    fi
    
    if [ -d "target/android/jniLibs" ]; then
        echo "  ✓ target/android/jniLibs/"
        find target/android/jniLibs -name "*.so" -exec ls -lh {} \;
    fi
    
    if [ -d "android/pxnix" ]; then
        echo "  ✓ android/pxnix/ (Android library project)"
    fi
    
    echo ""
    echo -e "${GREEN}Build complete!${NC}"
    echo ""
    echo "To use in your Android project:"
    echo "  1. Copy android/pxnix to your project"
    echo "  2. Add implementation project(':pxnix') to your app's build.gradle"
    echo "  3. Use PxNixEngine.getInstance() to access the engine"
}

# Main build process
main() {
    check_tools
    install_targets
    setup_ndk
    
    # Try cargo-ndk first (simpler)
    if command -v cargo-ndk &> /dev/null || [ -z "$ANDROID_NDK_HOME" ]; then
        build_with_cargo_ndk
    else
        build_arm64
    fi
    
    create_android_project
    generate_bindings
    create_gradle_config
    print_summary
}

# Run main
main "$@"
