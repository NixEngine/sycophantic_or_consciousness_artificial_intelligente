//! Integration tests for Px/Nix Engine

use px_nix::{PxEngine, PxConfig, DeviceType, Route, EthosStatus};
use px_nix::{analyze_noise, mdl};

// ============================================================================
// Engine Lifecycle Tests
// ============================================================================

#[test]
fn test_engine_creation_default() {
    let engine = PxEngine::new();
    let state = engine.state();
    
    assert!(state.hormones.h_perf >= 0.0 && state.hormones.h_perf <= 1.0);
    assert!(state.hormones.h_quality >= 0.0 && state.hormones.h_quality <= 1.0);
    assert!(state.hormones.h_safety >= 0.0 && state.hormones.h_safety <= 1.0);
}

#[test]
fn test_engine_creation_mobile() {
    let config = PxConfig::mobile();
    let engine = PxEngine::with_config(config);
    
    assert_eq!(engine.config().device_type, DeviceType::Mobile);
    assert!(engine.config().p95_target_ms <= 100);
}

#[test]
fn test_engine_creation_server() {
    let config = PxConfig::server();
    let engine = PxEngine::with_config(config);
    
    assert_eq!(engine.config().device_type, DeviceType::Server);
    assert!(engine.config().max_concurrent >= 8);
}

// ============================================================================
// Processing Tests
// ============================================================================

#[test]
fn test_process_simple_text() {
    let mut engine = PxEngine::new();
    let input = b"Hello, World!";
    
    let result = engine.process(input).unwrap();
    
    assert!(result.j_score > 0.0);
    assert!(!result.trace_id.is_nil());
    assert!(result.latency_us > 0);
}

#[test]
fn test_process_json() {
    let mut engine = PxEngine::new();
    let input = br#"{"name": "test", "value": 42, "items": [1, 2, 3]}"#;
    
    let result = engine.process(input).unwrap();
    
    assert!(result.j_score > 0.0);
    assert!(result.competence.k_obj >= 0.0 && result.competence.k_obj <= 1.0);
}

#[test]
fn test_process_repetitive_data() {
    let mut engine = PxEngine::new();
    let input = vec![42u8; 1000];
    
    let result = engine.process(&input).unwrap();
    
    // Repetitive data should be highly compressible, lower J-score
    assert!(result.j_score > 0.0);
}

#[test]
fn test_process_binary_data() {
    let mut engine = PxEngine::new();
    let input: Vec<u8> = (0..256).map(|i| i as u8).collect();
    
    let result = engine.process(&input).unwrap();
    
    assert!(result.j_score > 0.0);
}

#[test]
fn test_process_empty_fails() {
    let mut engine = PxEngine::new();
    let input = b"";
    
    let result = engine.process(input);
    
    assert!(result.is_err());
}

// ============================================================================
// Routing Tests
// ============================================================================

#[test]
fn test_routing_fast_for_simple() {
    let mut engine = PxEngine::new();
    
    // Very simple, repetitive data should likely go FAST
    let input = vec![0u8; 100];
    let result = engine.process(&input).unwrap();
    
    // We just check that routing happens without error
    assert!(matches!(result.route, Route::Fast | Route::Deep));
}

#[test]
fn test_routing_consistency() {
    let mut engine = PxEngine::new();
    let input = b"Test data for routing consistency check";
    
    // Process multiple times
    let results: Vec<_> = (0..5)
        .map(|_| engine.process(input).unwrap())
        .collect();
    
    // All should complete successfully
    assert_eq!(results.len(), 5);
}

// ============================================================================
// Noise Analysis Tests
// ============================================================================

#[test]
fn test_noise_analysis_text() {
    let config = PxConfig::default();
    let text = b"The quick brown fox jumps over the lazy dog.";
    
    let result = analyze_noise(text, &config);
    
    // Text should be recognized as signal (low noise)
    assert!(result.score >= 0.0 && result.score <= 1.0);
}

#[test]
fn test_noise_analysis_structured() {
    let config = PxConfig::default();
    let json = br#"{"key": "value", "number": 123}"#;
    
    let result = analyze_noise(json, &config);
    
    // Structured data should be signal
    assert!(result.score <= config.tau_noise);
}

#[test]
fn test_noise_analysis_high_entropy() {
    let config = PxConfig::default();
    let noise: Vec<u8> = (0..1024)
        .map(|i| ((i * 17 + 31) ^ (i * 13) + (i * 7)) as u8)
        .collect();
    
    let result = analyze_noise(&noise, &config);
    
    // High entropy data should have higher noise score
    assert!(result.score >= 0.0);
}

// ============================================================================
// MDL Tests
// ============================================================================

#[test]
fn test_mdl_description_length() {
    let data = b"Hello, World!";
    let length = mdl::description_length(data);
    
    assert!(length > 0.0);
    assert!(length <= data.len() as f64 * 8.0 * 2.0); // Should not exceed 2x original
}

#[test]
fn test_mdl_compressibility_repetitive() {
    let repetitive = vec![42u8; 1000];
    let random: Vec<u8> = (0..1000).map(|i| ((i * 17 + 31) ^ (i * 13)) as u8).collect();
    
    let k_rep = mdl::compute_compressibility(&repetitive);
    let k_rand = mdl::compute_compressibility(&random);
    
    // Repetitive data should be more compressible
    assert!(k_rep > k_rand);
    assert!(k_rep > 0.5); // Highly compressible
}

#[test]
fn test_mdl_entropy() {
    let uniform: Vec<u8> = (0..256).map(|i| i as u8).collect();
    let constant = vec![42u8; 256];
    
    let h_uniform = mdl::estimate_entropy(&uniform);
    let h_constant = mdl::estimate_entropy(&constant);
    
    // Uniform distribution should have higher entropy
    assert!(h_uniform > h_constant);
    assert!(h_constant < 0.1); // Very low entropy
}

#[test]
fn test_mdl_normalized_delta() {
    let a = b"hello";
    let b = b"hello";
    let c = b"world";
    
    let delta_same = mdl::normalized_delta(a, b);
    let delta_diff = mdl::normalized_delta(a, c);
    
    assert_eq!(delta_same, 0.0);
    assert!(delta_diff > 0.0);
}

// ============================================================================
// Competence Tests
// ============================================================================

#[test]
fn test_competence_k_obj() {
    let config = PxConfig::default();
    let data = b"Test data for competence measurement";
    
    let k_obj = px_nix::compute_k_obj(data, &config);
    
    assert!(k_obj >= 0.0 && k_obj <= 1.0);
}

#[test]
fn test_competence_triplet() {
    let mut engine = PxEngine::new();
    let input = b"Comprehensive test for competence triplet";
    
    let result = engine.process(input).unwrap();
    
    assert!(result.competence.k_obj >= 0.0 && result.competence.k_obj <= 1.0);
    // k_semi and k_subj may be 0 for FAST route
    assert!(result.competence.k_semi >= 0.0);
    assert!(result.competence.k_subj >= 0.0);
}

// ============================================================================
// Homeostasis Tests
// ============================================================================

#[test]
fn test_homeostasis_tick() {
    let mut engine = PxEngine::new();
    
    // Process some data to generate metrics
    for _ in 0..10 {
        let _ = engine.process(b"test data");
    }
    
    // Trigger tick
    engine.tick();
    
    let state = engine.state();
    assert!(state.hormones.h_perf >= 0.0 && state.hormones.h_perf <= 1.0);
}

#[test]
fn test_homeostasis_stability() {
    let mut engine = PxEngine::new();
    
    // Process many requests and tick
    for i in 0..100 {
        let _ = engine.process(format!("request {}", i).as_bytes());
        if i % 20 == 0 {
            engine.tick();
        }
    }
    
    let state = engine.state();
    
    // Should remain stable
    assert!(state.hormones.h_perf >= 0.0 && state.hormones.h_perf <= 1.0);
    assert!(state.deep_rate >= 0.0 && state.deep_rate <= 1.0);
}

// ============================================================================
// Ethos Tests
// ============================================================================

#[test]
fn test_ethos_safe_content() {
    let mut engine = PxEngine::new();
    let input = b"This is safe and friendly content.";
    
    let result = engine.process(input).unwrap();
    
    assert!(matches!(result.ethos_status, EthosStatus::Ok | EthosStatus::Warning(_)));
}

// ============================================================================
// State Management Tests
// ============================================================================

#[test]
fn test_engine_state() {
    let engine = PxEngine::new();
    let state = engine.state();
    
    assert!(state.sbe_budget > 0);
    assert!(state.council_size >= 3);
    assert!(state.memory_size >= 0);
}

#[test]
fn test_deep_rate_tracking() {
    let mut engine = PxEngine::new();
    
    // Process multiple items
    for i in 0..50 {
        let _ = engine.process(format!("item number {} for processing", i).as_bytes());
    }
    
    let state = engine.state();
    
    // Deep rate should be within bounds
    assert!(state.deep_rate >= 0.0 && state.deep_rate <= 1.0);
}

// ============================================================================
// Performance Tests
// ============================================================================

#[test]
fn test_latency_reasonable() {
    let mut engine = PxEngine::new();
    let input = b"Performance test input data";
    
    let result = engine.process(input).unwrap();
    
    // Should complete in reasonable time (< 10 seconds in debug mode)
    assert!(result.latency_us < 10_000_000);
}

#[test]
fn test_throughput_batch() {
    let mut engine = PxEngine::new();
    let input = b"Batch throughput test";
    
    let start = std::time::Instant::now();
    let count = 100;
    
    for _ in 0..count {
        let _ = engine.process(input);
    }
    
    let elapsed = start.elapsed();
    let throughput = count as f64 / elapsed.as_secs_f64();
    
    // Should process at least 10 requests per second in debug mode
    assert!(throughput > 1.0);
}

// ============================================================================
// Edge Case Tests
// ============================================================================

#[test]
fn test_single_byte() {
    let mut engine = PxEngine::new();
    let input = b"X";
    
    let result = engine.process(input);
    assert!(result.is_ok());
}

#[test]
fn test_large_input() {
    let mut engine = PxEngine::new();
    let input = vec![0u8; 100_000]; // 100KB
    
    let result = engine.process(&input);
    assert!(result.is_ok());
}

#[test]
fn test_unicode_content() {
    let mut engine = PxEngine::new();
    let input = "Hello, 世界! 🌍 Привет!".as_bytes();
    
    let result = engine.process(input);
    assert!(result.is_ok());
}

// ============================================================================
// Configuration Tests
// ============================================================================

#[test]
fn test_config_validation() {
    let config = PxConfig {
        lambda: 0.001,
        tau_noise: 0.7,
        tau_j: 0.01,
        ..Default::default()
    };
    
    assert!(config.lambda > 0.0);
    assert!(config.tau_noise >= 0.0 && config.tau_noise <= 1.0);
}

#[test]
fn test_config_profiles() {
    let mobile = PxConfig::mobile();
    let server = PxConfig::server();
    
    // Mobile should be more conservative
    assert!(mobile.budget_per_window <= server.budget_per_window);
    assert!(mobile.max_concurrent <= server.max_concurrent);
    assert!(mobile.deep_target_max <= server.deep_target_max);
}
