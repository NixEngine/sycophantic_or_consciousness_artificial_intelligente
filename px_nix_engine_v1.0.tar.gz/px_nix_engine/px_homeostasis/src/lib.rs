//! # Px Homeostasis - Sistema Autonômico
//!
//! Implementa controle hormonal (H_perf, H_quality, H_safety) com:
//! - EWMA + histerese para hormônios
//! - PID para controle de p95/%DEEP
//! - Circuit breakers e reflexos
//! - Snapshots por contexto

#![forbid(unsafe_code)]

use parking_lot::Mutex;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

/// Sistema de Homeostase
pub struct HomeostasisSystem {
    /// Vitais do sistema
    vitals: Mutex<Vitals>,
    /// Hormônios
    hormones: Mutex<Hormones>,
    /// Knobs de controle
    knobs: Mutex<Knobs>,
    /// Controlador PID
    pid: Mutex<PidController>,
    /// Circuit breakers
    breakers: Mutex<CircuitBreakers>,
    /// Snapshots por contexto
    snapshots: Mutex<HashMap<String, Snapshot>>,
    /// Configuração
    config: HomeostasisConfig,
}

/// Vitais do sistema (sensores O(1))
#[derive(Debug, Default)]
pub struct Vitals {
    /// Latência p50 (µs)
    pub p50_us: AtomicU64,
    /// Latência p95 (µs)
    pub p95_us: AtomicU64,
    /// Tamanho da fila
    pub queue_len: AtomicU64,
    /// Taxa de erros (por mil)
    pub error_rate_permil: AtomicU64,
    /// Porcentagem DEEP
    pub deep_percent: AtomicU64,
    /// Taxa de ambíguos (por mil)
    pub ambiguous_rate_permil: AtomicU64,
    /// CPU percent
    pub cpu_percent: AtomicU64,
    /// Memória usada (bytes)
    pub memory_bytes: AtomicU64,
}

impl Vitals {
    /// Registra latência
    pub fn record_latency(&self, latency_us: u64) {
        // Simplificado: atualiza p95 com EWMA
        let current = self.p95_us.load(Ordering::Relaxed);
        let alpha = 0.1;
        let new = ((1.0 - alpha) * current as f64 + alpha * latency_us as f64) as u64;
        self.p95_us.store(new, Ordering::Relaxed);
    }

    /// Registra erro
    pub fn record_error(&self) {
        self.error_rate_permil.fetch_add(10, Ordering::Relaxed);
    }

    /// Registra decisão DEEP
    pub fn record_deep(&self) {
        let current = self.deep_percent.load(Ordering::Relaxed);
        self.deep_percent.store((current + 1).min(100), Ordering::Relaxed);
    }

    /// Registra decisão FAST
    pub fn record_fast(&self) {
        let current = self.deep_percent.load(Ordering::Relaxed);
        self.deep_percent.store(current.saturating_sub(1), Ordering::Relaxed);
    }

    /// Decay periódico das taxas
    pub fn decay(&self, factor: f64) {
        let err = self.error_rate_permil.load(Ordering::Relaxed);
        self.error_rate_permil.store((err as f64 * factor) as u64, Ordering::Relaxed);
        
        let amb = self.ambiguous_rate_permil.load(Ordering::Relaxed);
        self.ambiguous_rate_permil.store((amb as f64 * factor) as u64, Ordering::Relaxed);
    }
}

/// Hormônios do sistema (escalares 0-1)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Hormones {
    /// H_perf: stress/energia
    pub h_perf: f64,
    /// H_quality: eficácia/ganho
    pub h_quality: f64,
    /// H_safety: risco/erros
    pub h_safety: f64,
    /// Timestamp da última atualização
    pub last_update: u64,
}

impl Default for Hormones {
    fn default() -> Self {
        Self {
            h_perf: 0.5,
            h_quality: 0.5,
            h_safety: 0.3,
            last_update: 0,
        }
    }
}

impl Hormones {
    /// Atualiza hormônios com EWMA
    pub fn update(&mut self, vitals: &Vitals, config: &HomeostasisConfig) {
        let alpha = config.ewma_alpha;
        
        // H_perf: sobe com p95↑, fila↑, CPU↑
        let p95 = vitals.p95_us.load(Ordering::Relaxed) as f64;
        let queue = vitals.queue_len.load(Ordering::Relaxed) as f64;
        let cpu = vitals.cpu_percent.load(Ordering::Relaxed) as f64;
        
        let stress = (p95 / config.target_p95_us as f64 * 0.4 +
                      queue / 100.0 * 0.3 +
                      cpu / 100.0 * 0.3).min(1.0);
        
        // EWMA com histerese
        let new_perf = alpha * stress + (1.0 - alpha) * self.h_perf;
        if (new_perf - self.h_perf).abs() > config.hysteresis {
            self.h_perf = new_perf.clamp(0.0, 1.0);
        }
        
        // H_quality: sobe com bons outcomes
        let deep = vitals.deep_percent.load(Ordering::Relaxed) as f64;
        let quality_signal = (deep / config.target_deep_percent as f64).min(1.5) / 1.5;
        let new_quality = alpha * quality_signal + (1.0 - alpha) * self.h_quality;
        if (new_quality - self.h_quality).abs() > config.hysteresis {
            self.h_quality = new_quality.clamp(0.0, 1.0);
        }
        
        // H_safety: sobe com erros/ambíguos
        let errors = vitals.error_rate_permil.load(Ordering::Relaxed) as f64 / 1000.0;
        let ambiguous = vitals.ambiguous_rate_permil.load(Ordering::Relaxed) as f64 / 1000.0;
        let risk = (errors * 0.7 + ambiguous * 0.3).min(1.0);
        
        let new_safety = alpha * risk + (1.0 - alpha) * self.h_safety;
        if (new_safety - self.h_safety).abs() > config.hysteresis {
            self.h_safety = new_safety.clamp(0.0, 1.0);
        }
        
        self.last_update = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
    }
}

/// Knobs de controle ajustáveis
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Knobs {
    /// Alvo de %DEEP
    pub deep_target: f64,
    /// efSearch do ANN
    pub ann_ef: u32,
    /// Tamanho do Council
    pub council_size: u32,
    /// Quantização de embeddings
    pub embedding_quant: QuantLevel,
    /// Limiar de ruído
    pub noise_tau: f64,
    /// Codec ativo
    pub active_codec: String,
    /// Modo de energia
    pub power_mode: PowerMode,
}

impl Default for Knobs {
    fn default() -> Self {
        Self {
            deep_target: 0.3,
            ann_ef: 64,
            council_size: 5,
            embedding_quant: QuantLevel::Float32,
            noise_tau: 0.7,
            active_codec: "lz4".into(),
            power_mode: PowerMode::Balanced,
        }
    }
}

/// Nível de quantização
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum QuantLevel {
    Float32,
    Float16,
    Int8,
    Int4,
}

/// Modo de energia
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PowerMode {
    Performance,
    Balanced,
    Eco,
}

/// Controlador PID simples
#[derive(Debug)]
pub struct PidController {
    kp: f64,
    ki: f64,
    kd: f64,
    integral: f64,
    last_error: f64,
    target: f64,
}

impl PidController {
    pub fn new(kp: f64, ki: f64, kd: f64, target: f64) -> Self {
        Self {
            kp, ki, kd,
            integral: 0.0,
            last_error: 0.0,
            target,
        }
    }

    pub fn update(&mut self, current: f64, dt: f64) -> f64 {
        let error = self.target - current;
        self.integral += error * dt;
        self.integral = self.integral.clamp(-100.0, 100.0); // Anti-windup
        
        let derivative = if dt > 0.0 { (error - self.last_error) / dt } else { 0.0 };
        self.last_error = error;
        
        self.kp * error + self.ki * self.integral + self.kd * derivative
    }

    pub fn set_target(&mut self, target: f64) {
        self.target = target;
    }

    pub fn reset(&mut self) {
        self.integral = 0.0;
        self.last_error = 0.0;
    }
}

/// Circuit breakers
#[derive(Debug, Default)]
pub struct CircuitBreakers {
    /// Estado do breaker de latência
    pub latency_open: bool,
    /// Estado do breaker de erros
    pub error_open: bool,
    /// Estado do breaker de memória
    pub memory_open: bool,
    /// Timestamps de abertura
    pub open_times: HashMap<String, Instant>,
    /// Contadores de trips
    pub trip_counts: HashMap<String, u32>,
}

impl CircuitBreakers {
    /// Verifica se deve abrir breaker
    pub fn check_and_trip(&mut self, name: &str, condition: bool, threshold: u32) -> bool {
        let count = self.trip_counts.entry(name.to_string()).or_insert(0);
        
        if condition {
            *count += 1;
            if *count >= threshold {
                self.open_times.insert(name.to_string(), Instant::now());
                return true;
            }
        } else {
            *count = count.saturating_sub(1);
        }
        false
    }

    /// Verifica se breaker pode fechar (após cooldown)
    pub fn can_close(&self, name: &str, cooldown: Duration) -> bool {
        if let Some(&open_time) = self.open_times.get(name) {
            open_time.elapsed() >= cooldown
        } else {
            true
        }
    }

    /// Fecha breaker
    pub fn close(&mut self, name: &str) {
        self.open_times.remove(name);
        self.trip_counts.remove(name);
    }
}

/// Snapshot de estado
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Snapshot {
    pub context: String,
    pub hormones: Hormones,
    pub knobs: Knobs,
    pub timestamp: u64,
}

/// Configuração do sistema
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HomeostasisConfig {
    /// Alpha do EWMA
    pub ewma_alpha: f64,
    /// Largura da histerese
    pub hysteresis: f64,
    /// Alvo de p95 (µs)
    pub target_p95_us: u64,
    /// Alvo de %DEEP
    pub target_deep_percent: u64,
    /// Intervalo do tick (ms)
    pub tick_interval_ms: u64,
    /// Cooldown de circuit breaker (ms)
    pub breaker_cooldown_ms: u64,
}

impl Default for HomeostasisConfig {
    fn default() -> Self {
        Self {
            ewma_alpha: 0.2,
            hysteresis: 0.05,
            target_p95_us: 50_000, // 50ms
            target_deep_percent: 30,
            tick_interval_ms: 500,
            breaker_cooldown_ms: 5000,
        }
    }
}

impl HomeostasisSystem {
    /// Cria novo sistema de homeostase
    pub fn new(config: HomeostasisConfig) -> Self {
        Self {
            vitals: Mutex::new(Vitals::default()),
            hormones: Mutex::new(Hormones::default()),
            knobs: Mutex::new(Knobs::default()),
            pid: Mutex::new(PidController::new(0.1, 0.01, 0.05, config.target_p95_us as f64)),
            breakers: Mutex::new(CircuitBreakers::default()),
            snapshots: Mutex::new(HashMap::new()),
            config,
        }
    }

    /// Executa tick do sistema autonômico
    pub fn tick(&self) {
        let vitals = self.vitals.lock();
        
        // Atualiza hormônios
        let mut hormones = self.hormones.lock();
        hormones.update(&vitals, &self.config);
        
        // Aplica ajustes baseados em hormônios
        let mut knobs = self.knobs.lock();
        
        // H_perf alto -> reduzir carga
        if hormones.h_perf > 0.7 {
            knobs.deep_target *= 0.9;
            knobs.ann_ef = (knobs.ann_ef as f64 * 0.8) as u32;
            knobs.council_size = knobs.council_size.saturating_sub(1).max(1);
            if hormones.h_perf > 0.9 {
                knobs.power_mode = PowerMode::Eco;
            }
        } else if hormones.h_perf < 0.3 {
            // Folga -> pode aumentar qualidade
            knobs.deep_target = (knobs.deep_target * 1.1).min(0.5);
            knobs.ann_ef = (knobs.ann_ef + 8).min(128);
        }
        
        // H_safety alto -> mais cautela
        if hormones.h_safety > 0.6 {
            knobs.noise_tau *= 0.95; // Mais conservador
        }
        
        // PID para p95
        let current_p95 = vitals.p95_us.load(Ordering::Relaxed) as f64;
        let mut pid = self.pid.lock();
        let adjustment = pid.update(current_p95, self.config.tick_interval_ms as f64 / 1000.0);
        
        // Aplica ajuste do PID ao deep_target
        if adjustment.abs() > 1.0 {
            knobs.deep_target = (knobs.deep_target - adjustment * 0.01).clamp(0.1, 0.6);
        }
        
        // Decay das taxas
        drop(vitals);
        self.vitals.lock().decay(0.99);
    }

    /// Verifica reflexos (circuit breakers)
    pub fn check_reflexes(&self) -> Option<ReflexAction> {
        let vitals = self.vitals.lock();
        let mut breakers = self.breakers.lock();
        
        let p95 = vitals.p95_us.load(Ordering::Relaxed);
        let errors = vitals.error_rate_permil.load(Ordering::Relaxed);
        
        // Latência crítica
        if breakers.check_and_trip("latency", p95 > self.config.target_p95_us * 3, 3) {
            return Some(ReflexAction::DegradeToFast);
        }
        
        // Erros em cascata
        if breakers.check_and_trip("errors", errors > 100, 5) {
            return Some(ReflexAction::FallbackCache);
        }
        
        None
    }

    /// Salva snapshot do estado atual
    pub fn save_snapshot(&self, context: &str) {
        let snapshot = Snapshot {
            context: context.to_string(),
            hormones: self.hormones.lock().clone(),
            knobs: self.knobs.lock().clone(),
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
        };
        self.snapshots.lock().insert(context.to_string(), snapshot);
    }

    /// Restaura snapshot
    pub fn restore_snapshot(&self, context: &str) -> bool {
        if let Some(snapshot) = self.snapshots.lock().get(context) {
            *self.knobs.lock() = snapshot.knobs.clone();
            true
        } else {
            false
        }
    }

    /// Obtém vitais
    pub fn get_vitals(&self) -> VitalsSnapshot {
        let v = self.vitals.lock();
        VitalsSnapshot {
            p95_us: v.p95_us.load(Ordering::Relaxed),
            queue_len: v.queue_len.load(Ordering::Relaxed),
            error_rate_permil: v.error_rate_permil.load(Ordering::Relaxed),
            deep_percent: v.deep_percent.load(Ordering::Relaxed),
            cpu_percent: v.cpu_percent.load(Ordering::Relaxed),
        }
    }

    /// Obtém hormônios
    pub fn get_hormones(&self) -> Hormones {
        self.hormones.lock().clone()
    }

    /// Obtém knobs
    pub fn get_knobs(&self) -> Knobs {
        self.knobs.lock().clone()
    }

    /// Registra latência
    pub fn record_latency(&self, latency_us: u64) {
        self.vitals.lock().record_latency(latency_us);
    }

    /// Registra erro
    pub fn record_error(&self) {
        self.vitals.lock().record_error();
    }
}

/// Ação de reflexo
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReflexAction {
    DegradeToFast,
    FallbackCache,
    Throttle,
    Quarantine,
}

/// Snapshot dos vitais (para serialização)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VitalsSnapshot {
    pub p95_us: u64,
    pub queue_len: u64,
    pub error_rate_permil: u64,
    pub deep_percent: u64,
    pub cpu_percent: u64,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_homeostasis_creation() {
        let system = HomeostasisSystem::new(HomeostasisConfig::default());
        let hormones = system.get_hormones();
        assert!(hormones.h_perf >= 0.0 && hormones.h_perf <= 1.0);
    }

    #[test]
    fn test_hormone_update() {
        let system = HomeostasisSystem::new(HomeostasisConfig::default());
        
        // Simula alta latência
        for _ in 0..10 {
            system.record_latency(100_000); // 100ms
        }
        
        system.tick();
        
        let hormones = system.get_hormones();
        // H_perf deve aumentar com alta latência
        assert!(hormones.h_perf > 0.5);
    }

    #[test]
    fn test_snapshot() {
        let system = HomeostasisSystem::new(HomeostasisConfig::default());
        
        system.save_snapshot("test_context");
        assert!(system.restore_snapshot("test_context"));
        assert!(!system.restore_snapshot("nonexistent"));
    }

    #[test]
    fn test_pid_controller() {
        let mut pid = PidController::new(1.0, 0.1, 0.01, 50.0);
        
        // Valor abaixo do target -> output positivo
        let output = pid.update(30.0, 0.1);
        assert!(output > 0.0);
        
        // Valor acima do target -> output negativo
        let output = pid.update(70.0, 0.1);
        assert!(output < 0.0);
    }
}
