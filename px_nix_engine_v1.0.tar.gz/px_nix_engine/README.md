# Px/Nix Engine

> **Autonomous AI Engine based on Minimum Description Length (MDL) Principles**

[![Rust](https://img.shields.io/badge/rust-1.75%2B-orange.svg)](https://www.rust-lang.org/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Build Status](https://img.shields.io/badge/build-passing-brightgreen.svg)]()

## Overview

The Px/Nix Engine is a novel approach to autonomous AI systems, grounded in the mathematical principles of Minimum Description Length (MDL). The core insight is that intelligence can be measured and optimized through compression—the ability to find shorter descriptions of data through understanding its structure.

### Central Formula

```
J(Φ) = ℓ(Φ) + res(Φ,D)
```

Where:
- **J(Φ)**: Total description length (lower is better)
- **ℓ(Φ)**: Model complexity (how complex is the transform?)
- **res(Φ,D)**: Residual (what the model can't explain)

## Architecture

The engine follows a **Nucleus/Skin** (Núcleo/Pele) architecture:

```
┌─────────────────────────────────────────────────────────────┐
│                         SKIN (Adaptive)                      │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │ Noise-First │→ │   Router    │→ │ Homeostasis │         │
│  │  Analysis   │  │ FAST/DEEP   │  │  Controller │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
│         │              │                 │                  │
│         ▼              ▼                 ▼                  │
│  ┌─────────────────────────────────────────────────────┐   │
│  │                   NUCLEUS (Core)                     │   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌────────┐ │   │
│  │  │  Prisma │→ │   DSL   │→ │ Council │→ │ Ethos  │ │   │
│  │  │Decompose│  │  Stair  │  │  Vote   │  │  Gate  │ │   │
│  │  └─────────┘  └─────────┘  └─────────┘  └────────┘ │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### Key Components

| Component | Description |
|-----------|-------------|
| **Noise-First** | N1-N6 cascade for early detection of uninformative data |
| **Router** | FAST/DEEP path selection based on noise and homeostasis |
| **Homeostasis** | Hormonal control (H_perf, H_quality, H_safety) |
| **Prisma** | Spectral decomposition into information bands |
| **Council** | Multi-avatar voting for robust decisions |
| **SBE** | Stochastic Budget Exploration for resource allocation |
| **Ethos** | Ethical validation gate |

## Features

- **MDL-Based Intelligence**: All decisions optimized for description length
- **Autonomous Homeostasis**: Self-regulating system with hormonal feedback
- **Noise-First Processing**: Early detection saves compute on uninformative data
- **Multi-Perspective Council**: Diverse avatars vote on decisions
- **Resource-Bounded**: Time and memory budgets enforced
- **Mobile Optimized**: SIMD/NEON support for Galaxy S25 and ARM64

## Installation

### From Cargo

```bash
cargo install px_nix
```

### From Source

```bash
git clone https://github.com/pxnix/px_nix_engine
cd px_nix_engine
cargo build --release
```

### For Android (Galaxy S25)

```bash
./build_android.sh
```

## Quick Start

```rust
use px_nix::{PxEngine, PxConfig};

fn main() {
    // Create engine with default configuration
    let mut engine = PxEngine::new();
    
    // Process some data
    let input = b"Hello, World! This is a test.";
    let result = engine.process(input).unwrap();
    
    println!("J-Score: {:.4}", result.j_score);
    println!("Route: {:?}", result.route);
    println!("Competence: K_obj={:.4}", result.competence.k_obj);
    println!("Latency: {} µs", result.latency_us);
}
```

### Mobile Configuration

```rust
use px_nix::{PxEngine, PxConfig};

// Optimized for Galaxy S25
let config = PxConfig::mobile();
let mut engine = PxEngine::with_config(config);
```

### Server Configuration

```rust
// High-throughput server configuration
let config = PxConfig::server();
let mut engine = PxEngine::with_config(config);
```

## Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `lambda` | 0.001 | MDL balance factor |
| `tau_noise` | 0.7 | Noise threshold for FAST/DEEP routing |
| `tau_j` | 0.01 | J-score improvement threshold |
| `tau_k` | 0.05 | Competence threshold |
| `p95_target_ms` | 100 | Target p95 latency |
| `deep_target_max` | 0.3 | Maximum DEEP route fraction |
| `budget_per_window` | 1000 | Processing budget per window |

## Competence Metrics

The engine uses a **Competence Triplet** for evaluation:

### K_obj (Objective Competence)

```
K_obj = (P_obj · X · R★ · (1-κ) · δ)^(1/5)
```

- **P_obj**: Objective purity (compressibility)
- **X**: Intensity of experience
- **R★**: Reproducibility score
- **κ**: Contamination level
- **δ**: Temporal coherence

### K_semi (Semi-Objective Competence)

```
K_semi = K_obj(R⊙D) · e^(-αℓ(R)) · (1-βχ(D;R))
```

### K_subj (Subjective Competence)

```
K_subj = ((1-res) · Ω · R★^(C) · (1-η))^(1/4) · e^(-γℓ(C))
```

## Noise Cascade (N1-N6)

The Noise-First analysis uses a cascade of detectors with early-exit:

| Stage | Name | Cost | Description |
|-------|------|------|-------------|
| N1 | Compressibility | Medium | LZ4/Zstd compression ratio |
| N2 | Entropy | O(n) | Rolling histogram entropy |
| N3 | LZ-Hint | O(n) | Rolling hash match detection |
| N4 | Syndrome | Medium | Hamming/BCH parity checks |
| N5 | Format | O(1) | Magic bytes detection |
| N6 | Spectral | Medium | Goertzel spectral flatness |

**Decision Rule**: `N(x) = median{w_j·N_j}`, early-exit if 2+ indicators ≥ threshold

## Homeostasis

The hormonal control system maintains stability:

```rust
// Hormones (EWMA + hysteresis)
H_perf = f(latency, queue, cpu)      // Performance stress
H_quality = f(error_rate, gains)      // Quality indicator
H_safety = f(errors, ambiguous)       // Safety level

// Operating Modes
enum OperatingMode {
    Normal,          // Standard operation
    HighPerformance, // Increased DEEP rate
    EcoMode,         // Battery/thermal conservation
    Degraded,        // Circuit breaker active
    Emergency,       // FAST-only, minimal processing
}
```

## FFI / C Interface

```c
#include "px_nix.h"

// Create engine
PxHandle engine = px_engine_new();

// Process data
PxResultFFI result;
px_engine_process(engine, data, len, &result);

printf("J-Score: %f\n", result.j_score);
printf("Latency: %lu µs\n", result.latency_us);

// Cleanup
px_engine_free(engine);
```

## Android/JNI (Kotlin)

```kotlin
import com.pxnix.engine.PxNixEngine

val engine = PxNixEngine.getInstance()

val result = engine.process("Hello, World!".toByteArray())

println("J-Score: ${result.jScore}")
println("Route: ${result.route}")
println("Latency: ${result.latencyUs} µs")
```

## Benchmarks

Run benchmarks:

```bash
cargo bench
```

Typical results on desktop (Intel i7):

| Operation | Size | Throughput |
|-----------|------|------------|
| description_length | 1KB | 150 MB/s |
| noise_analysis | 4KB | 80 MB/s |
| full_process | 1KB | 50 µs |

## CLI Usage

```bash
# Interactive mode
px_nix_cli

# Process file
px_nix_cli process -i input.txt -o output.txt

# Run benchmarks
px_nix_cli benchmark --iterations 1000

# Show configuration
px_nix_cli config
```

## Project Structure

```
px_nix_engine/
├── Cargo.toml           # Project configuration
├── build.rs             # Build script
├── build_android.sh     # Android build script
├── src/
│   ├── lib.rs           # Main library
│   ├── main.rs          # CLI binary
│   ├── noise.rs         # Noise-First analysis (N1-N6)
│   ├── homeostasis.rs   # Hormonal control system
│   ├── competence.rs    # K_obj, K_semi, K_subj metrics
│   ├── router.rs        # FAST/DEEP routing
│   ├── sbe.rs           # Stochastic Budget Exploration
│   ├── prism.rs         # Prisma decomposition
│   ├── dsl.rs           # DSL-Stair (language ladder)
│   ├── synthesis.rs     # Transform synthesis
│   ├── council.rs       # Multi-avatar voting
│   ├── memory.rs        # Memory management with ROI
│   ├── ethos.rs         # Ethical validation
│   ├── ledger.rs        # WORM audit log
│   ├── causal.rs        # Causal reasoning (do-calculus)
│   ├── utils.rs         # Utilities
│   ├── android.rs       # JNI bindings
│   └── ffi.rs           # C FFI
├── benches/
│   ├── mdl_benchmark.rs
│   └── noise_benchmark.rs
└── tests/
    └── integration_tests.rs
```

## Mathematical Foundations

### MDL Principle

The Minimum Description Length principle states that the best model is the one that minimizes the total description length of the data and the model itself:

```
Φ* = argmin_Φ [ℓ(Φ) + ℓ(D|Φ)]
```

### Kolmogorov Complexity

True Kolmogorov complexity K(x) is incomputable, but we approximate it using practical compression:

```
K̂(x) = min_{codec ∈ Committee} |codec(x)|
```

### Lyapunov Stability

Homeostasis stability is verified using a Lyapunov function:

```
E = 0.4·p95_excess + 0.2·deep_excess + 0.3·error + 0.1·ambiguous
```

The system is stable if dE/dt ≤ 0.

## Contributing

Contributions are welcome! Please read [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT License - see [LICENSE](LICENSE) for details.

## References

1. Rissanen, J. (1978). Modeling by shortest data description. *Automatica*, 14(5), 465-471.
2. Grünwald, P. D. (2007). *The Minimum Description Length Principle*. MIT Press.
3. Solomonoff, R. J. (1964). A formal theory of inductive inference. *Information and Control*, 7(1-2), 1-22.

---

**Built with ❤️ using Rust**
