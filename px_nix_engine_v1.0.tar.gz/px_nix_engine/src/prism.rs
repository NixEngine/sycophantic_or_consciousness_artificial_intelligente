//! # Prism Module (Prisma Informacional)
//! 
//! Decomposes data into coherence bands, separating signal from noise.
//! 
//! ## Bands
//! - B0: White noise / high entropy
//! - B1: Harmonic / spectral lines
//! - B2: Sparse transients
//! - B3: Low-rank / trends
//! - B4: Symbolic / grammatical structure

use crate::{PxConfig, PxError, mdl};

/// Band from prism decomposition
#[derive(Debug, Clone)]
pub struct Band {
    pub index: usize,
    pub name: String,
    pub coefficients: Vec<f64>,
    pub coherence_index: f64,
    pub gain: f64,
    pub purity: f64,
}

/// Prism decomposition result
#[derive(Debug, Clone)]
pub struct PrismResult {
    pub bands: Vec<Band>,
    pub residual: Vec<u8>,
    pub total_gain: f64,
    pub residual_ratio: f64,
}

/// Decompose data into coherence bands
pub fn decompose(data: &[u8], config: &PxConfig) -> Result<Vec<Band>, PxError> {
    if data.is_empty() {
        return Ok(vec![]);
    }
    
    let mut bands = Vec::new();
    
    // Convert to f64 for processing
    let samples: Vec<f64> = data.iter().map(|&b| b as f64 - 128.0).collect();
    let n = samples.len();
    
    // B0: High entropy / noise band
    let (b0_coeffs, b0_coherence) = extract_noise_band(&samples);
    bands.push(Band {
        index: 0,
        name: "noise".into(),
        coefficients: b0_coeffs,
        coherence_index: b0_coherence,
        gain: 0.0,
        purity: 1.0 - b0_coherence,
    });
    
    // B1: Spectral lines (using Goertzel for efficiency)
    let (b1_coeffs, b1_coherence) = extract_spectral_band(&samples);
    bands.push(Band {
        index: 1,
        name: "spectral".into(),
        coefficients: b1_coeffs,
        coherence_index: b1_coherence,
        gain: compute_band_gain(&samples, &bands[1].coefficients),
        purity: b1_coherence,
    });
    
    // B2: Sparse transients (wavelet-like)
    let (b2_coeffs, b2_coherence) = extract_transient_band(&samples);
    bands.push(Band {
        index: 2,
        name: "transient".into(),
        coefficients: b2_coeffs,
        coherence_index: b2_coherence,
        gain: compute_band_gain(&samples, &bands[2].coefficients),
        purity: b2_coherence,
    });
    
    // B3: Low-rank / trends (moving average)
    let (b3_coeffs, b3_coherence) = extract_trend_band(&samples);
    bands.push(Band {
        index: 3,
        name: "trend".into(),
        coefficients: b3_coeffs,
        coherence_index: b3_coherence,
        gain: compute_band_gain(&samples, &bands[3].coefficients),
        purity: b3_coherence,
    });
    
    // B4: Symbolic / structure (for text-like data)
    if is_likely_text(data) {
        let (b4_coeffs, b4_coherence) = extract_symbolic_band(data);
        bands.push(Band {
            index: 4,
            name: "symbolic".into(),
            coefficients: b4_coeffs,
            coherence_index: b4_coherence,
            gain: 0.0,
            purity: b4_coherence,
        });
    }
    
    Ok(bands)
}

/// Full prism decomposition with reconstruction
pub fn decompose_full(data: &[u8], config: &PxConfig) -> Result<PrismResult, PxError> {
    let bands = decompose(data, config)?;
    
    // Compute residual
    let samples: Vec<f64> = data.iter().map(|&b| b as f64 - 128.0).collect();
    let reconstructed = reconstruct_from_bands(&bands, samples.len());
    
    let residual: Vec<u8> = samples.iter()
        .zip(reconstructed.iter())
        .map(|(&s, &r)| ((s - r + 128.0).clamp(0.0, 255.0)) as u8)
        .collect();
    
    let total_gain: f64 = bands.iter().map(|b| b.gain).sum();
    let residual_ratio = mdl::description_length(&residual) / mdl::description_length(data);
    
    Ok(PrismResult {
        bands,
        residual,
        total_gain,
        residual_ratio,
    })
}

fn extract_noise_band(samples: &[f64]) -> (Vec<f64>, f64) {
    // Estimate noise using MAD
    let mut sorted = samples.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    
    let median = if sorted.is_empty() {
        0.0
    } else {
        sorted[sorted.len() / 2]
    };
    
    let deviations: Vec<f64> = samples.iter().map(|&s| (s - median).abs()).collect();
    let mut sorted_dev = deviations.clone();
    sorted_dev.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    
    let mad = if sorted_dev.is_empty() {
        0.0
    } else {
        sorted_dev[sorted_dev.len() / 2]
    };
    
    // Noise estimate
    let sigma = mad * 1.4826;
    
    // Extract high-frequency noise
    let noise: Vec<f64> = samples.iter()
        .zip(samples.iter().skip(1))
        .map(|(&a, &b)| (b - a) / 2.0)
        .collect();
    
    // Coherence: low for white noise
    let coherence = if sigma > 0.0 {
        let var: f64 = samples.iter().map(|&s| (s - median).powi(2)).sum::<f64>() / samples.len() as f64;
        1.0 - (sigma.powi(2) / var.max(0.001)).min(1.0)
    } else {
        1.0
    };
    
    (noise, coherence)
}

fn extract_spectral_band(samples: &[f64]) -> (Vec<f64>, f64) {
    let n = samples.len();
    if n < 8 {
        return (vec![], 0.0);
    }
    
    // Goertzel for selected frequencies
    let num_bins = 16.min(n / 2);
    let mut powers = Vec::with_capacity(num_bins);
    let mut phases = Vec::with_capacity(num_bins);
    
    for k in 1..=num_bins {
        let freq = k as f64 / n as f64;
        let (power, phase) = goertzel_complex(samples, freq);
        powers.push(power);
        phases.push(phase);
    }
    
    // Find dominant frequencies
    let threshold = powers.iter().cloned().fold(0.0f64, f64::max) * 0.1;
    let dominant: Vec<f64> = powers.iter()
        .zip(phases.iter())
        .filter(|(&p, _)| p > threshold)
        .map(|(&p, _)| p)
        .collect();
    
    // Coherence: how concentrated is spectral energy
    let total_power: f64 = powers.iter().sum();
    let dominant_power: f64 = dominant.iter().sum();
    
    let coherence = if total_power > 0.0 {
        dominant_power / total_power
    } else {
        0.0
    };
    
    (dominant, coherence)
}

fn extract_transient_band(samples: &[f64]) -> (Vec<f64>, f64) {
    // Simple wavelet-like decomposition using Haar
    let n = samples.len();
    if n < 4 {
        return (vec![], 0.0);
    }
    
    let mut details = Vec::new();
    let mut approx = samples.to_vec();
    
    // One level of Haar decomposition
    while approx.len() >= 2 {
        let mut new_approx = Vec::with_capacity(approx.len() / 2);
        let mut new_detail = Vec::with_capacity(approx.len() / 2);
        
        for chunk in approx.chunks_exact(2) {
            let avg = (chunk[0] + chunk[1]) / 2.0;
            let diff = (chunk[0] - chunk[1]) / 2.0;
            new_approx.push(avg);
            new_detail.push(diff);
        }
        
        details.extend(new_detail);
        approx = new_approx;
        
        if approx.len() < 4 {
            break;
        }
    }
    
    // Find sparse transients (large detail coefficients)
    let mut sorted_details: Vec<f64> = details.iter().map(|d| d.abs()).collect();
    sorted_details.sort_by(|a, b| b.partial_cmp(a).unwrap_or(std::cmp::Ordering::Equal));
    
    let threshold = sorted_details.get(sorted_details.len() / 10).copied().unwrap_or(0.0);
    let transients: Vec<f64> = details.iter()
        .filter(|&&d| d.abs() > threshold)
        .copied()
        .collect();
    
    // Coherence: sparsity
    let coherence = 1.0 - (transients.len() as f64 / details.len().max(1) as f64);
    
    (transients, coherence)
}

fn extract_trend_band(samples: &[f64]) -> (Vec<f64>, f64) {
    let n = samples.len();
    if n < 4 {
        return (samples.to_vec(), 1.0);
    }
    
    // Moving average for trend extraction
    let window = (n / 10).max(3).min(100);
    let mut trend = Vec::with_capacity(n);
    
    for i in 0..n {
        let start = i.saturating_sub(window / 2);
        let end = (i + window / 2 + 1).min(n);
        let avg = samples[start..end].iter().sum::<f64>() / (end - start) as f64;
        trend.push(avg);
    }
    
    // Coherence: smoothness of trend
    let diffs: Vec<f64> = trend.windows(2).map(|w| (w[1] - w[0]).abs()).collect();
    let avg_diff = diffs.iter().sum::<f64>() / diffs.len().max(1) as f64;
    let max_range = samples.iter().cloned().fold(f64::NEG_INFINITY, f64::max)
        - samples.iter().cloned().fold(f64::INFINITY, f64::min);
    
    let coherence = if max_range > 0.0 {
        1.0 - (avg_diff / max_range).min(1.0)
    } else {
        1.0
    };
    
    (trend, coherence)
}

fn extract_symbolic_band(data: &[u8]) -> (Vec<f64>, f64) {
    // For text data, extract character frequencies as "symbolic" representation
    let mut freq = [0u64; 256];
    for &b in data {
        freq[b as usize] += 1;
    }
    
    // Convert to normalized frequencies
    let total = data.len() as f64;
    let coeffs: Vec<f64> = freq.iter()
        .map(|&f| f as f64 / total)
        .filter(|&f| f > 0.001)
        .collect();
    
    // Coherence: deviation from uniform distribution
    let expected = 1.0 / 256.0;
    let deviation: f64 = freq.iter()
        .map(|&f| ((f as f64 / total) - expected).powi(2))
        .sum();
    
    let coherence = (deviation / expected).sqrt().min(1.0);
    
    (coeffs, coherence)
}

fn goertzel_complex(samples: &[f64], freq: f64) -> (f64, f64) {
    let n = samples.len();
    let k = (freq * n as f64).round() as usize;
    let w = 2.0 * std::f64::consts::PI * k as f64 / n as f64;
    let coeff = 2.0 * w.cos();
    
    let mut s0 = 0.0;
    let mut s1 = 0.0;
    let mut s2 = 0.0;
    
    for &sample in samples {
        s0 = sample + coeff * s1 - s2;
        s2 = s1;
        s1 = s0;
    }
    
    // Complex result
    let real = s1 - s2 * w.cos();
    let imag = s2 * w.sin();
    
    let power = real * real + imag * imag;
    let phase = imag.atan2(real);
    
    (power, phase)
}

fn is_likely_text(data: &[u8]) -> bool {
    if data.is_empty() {
        return false;
    }
    
    let printable = data.iter()
        .filter(|&&b| (b >= 32 && b < 127) || b == b'\n' || b == b'\r' || b == b'\t')
        .count();
    
    printable as f64 / data.len() as f64 > 0.8
}

fn compute_band_gain(original: &[f64], band_coeffs: &[f64]) -> f64 {
    if original.is_empty() || band_coeffs.is_empty() {
        return 0.0;
    }
    
    // Simplified gain computation
    let original_energy: f64 = original.iter().map(|&x| x * x).sum();
    let band_energy: f64 = band_coeffs.iter().map(|&x| x * x).sum();
    
    if original_energy > 0.0 {
        band_energy / original_energy
    } else {
        0.0
    }
}

fn reconstruct_from_bands(bands: &[Band], length: usize) -> Vec<f64> {
    // Simplified reconstruction (sum of trends and spectral)
    let mut result = vec![0.0; length];
    
    for band in bands {
        if band.name == "trend" && band.coefficients.len() == length {
            for (i, &c) in band.coefficients.iter().enumerate() {
                result[i] += c * band.purity;
            }
        }
    }
    
    result
}

/// Select informational bands (filter out noise)
pub fn select_info_bands(bands: &[Band], threshold: f64) -> Vec<&Band> {
    bands.iter()
        .filter(|b| b.coherence_index >= threshold && b.name != "noise")
        .collect()
}

/// Reconstruct data from selected bands
pub fn reconstruct(bands: &[Band], original_len: usize) -> Vec<u8> {
    let samples = reconstruct_from_bands(bands, original_len);
    samples.iter()
        .map(|&s| (s + 128.0).clamp(0.0, 255.0) as u8)
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_decompose() {
        let config = PxConfig::default();
        let data: Vec<u8> = (0..256).map(|i| ((i as f64 * 0.1).sin() * 50.0 + 128.0) as u8).collect();
        
        let bands = decompose(&data, &config).unwrap();
        assert!(!bands.is_empty());
    }
    
    #[test]
    fn test_text_detection() {
        assert!(is_likely_text(b"Hello, World!"));
        assert!(!is_likely_text(&[0u8, 1, 2, 3, 255, 254]));
    }
}
