//! # Memory Module
//! 
//! Memory management with ROI-based promotion and selective forgetting.
//! 
//! ## Key Formulas
//! - ROI(d) = (ℓ(d) - min_Φ ℓ(Φ(d))) / (1 + cost(d))
//! - promote(d) ⟺ ROI(d) · P_obj({d}) ≥ τ_m
//! - decay: w_{t+1} = w_t · e^(-λ(1-ROI)) · (1 + α·access_count/max_access)

use crate::{PxConfig, PxError, mdl, synthesis::Transform};
use hashbrown::HashMap;
use uuid::Uuid;
use std::time::Instant;

/// Memory item
#[derive(Debug, Clone)]
pub struct MemoryItem {
    pub id: Uuid,
    pub version: u32,
    pub kind: MemoryKind,
    pub payload: Vec<u8>,
    pub embedding: Vec<f32>,
    pub provenance: Provenance,
    pub t_score: f32,
    pub ig_score: f32,
    pub roi: f32,
    pub decay_factor: f32,
    pub weight: f64,
    pub created_at: Instant,
    pub last_used: Instant,
    pub access_count: u32,
}

/// Memory item kind
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MemoryKind {
    Data,
    Pattern,
    Transform,
    Knowledge,
    Strategy,
}

/// Provenance tracking
#[derive(Debug, Clone)]
pub struct Provenance {
    pub source: String,
    pub trace_id: Option<Uuid>,
    pub parent_id: Option<Uuid>,
    pub confidence: f64,
}

/// Memory manager
pub struct MemoryManager {
    config: PxConfig,
    /// Items by ID
    items: HashMap<Uuid, MemoryItem>,
    /// Index by kind
    by_kind: HashMap<MemoryKind, Vec<Uuid>>,
    /// ANN index for similarity search (embeddings)
    embedding_dim: usize,
    /// Maximum items
    max_items: usize,
    /// Current memory usage
    total_bytes: usize,
    /// Maximum bytes
    max_bytes: usize,
    /// Decay rate (λ)
    decay_lambda: f64,
    /// Access boost (α)
    access_alpha: f64,
}

impl MemoryManager {
    pub fn new(config: &PxConfig) -> Self {
        Self {
            config: config.clone(),
            items: HashMap::new(),
            by_kind: HashMap::new(),
            embedding_dim: 128,
            max_items: 10000,
            total_bytes: 0,
            max_bytes: 100 * 1024 * 1024, // 100MB
            decay_lambda: 0.01,
            access_alpha: 0.1,
        }
    }
    
    /// Promote data to memory
    pub fn promote(&mut self, data: &[u8], phi: &Transform) -> Result<Uuid, PxError> {
        // Compute ROI
        let roi = compute_roi(data, phi);
        
        // Compute P_obj
        let p_obj = crate::competence::compute_p_obj(data, &self.config);
        
        // Check promotion threshold
        if roi * p_obj < self.config.tau_memory as f32 {
            return Err(PxError::MemoryError("Below promotion threshold".into()));
        }
        
        // Check capacity
        self.ensure_capacity(data.len())?;
        
        // Create embedding
        let embedding = compute_embedding(data);
        
        // Create item
        let id = Uuid::new_v4();
        let item = MemoryItem {
            id,
            version: 1,
            kind: classify_kind(data),
            payload: data.to_vec(),
            embedding,
            provenance: Provenance {
                source: "promote".into(),
                trace_id: None,
                parent_id: None,
                confidence: p_obj,
            },
            t_score: 0.0,
            ig_score: roi,
            roi,
            decay_factor: 1.0,
            weight: 1.0,
            created_at: Instant::now(),
            last_used: Instant::now(),
            access_count: 0,
        };
        
        self.total_bytes += data.len();
        
        // Index
        self.by_kind
            .entry(item.kind)
            .or_insert_with(Vec::new)
            .push(id);
        
        self.items.insert(id, item);
        
        Ok(id)
    }
    
    /// Retrieve item by ID
    pub fn get(&mut self, id: &Uuid) -> Option<&MemoryItem> {
        if let Some(item) = self.items.get_mut(id) {
            item.last_used = Instant::now();
            item.access_count += 1;
        }
        self.items.get(id)
    }
    
    /// Search by similarity
    pub fn search_similar(&self, embedding: &[f32], k: usize) -> Vec<(Uuid, f64)> {
        let mut results: Vec<_> = self.items.iter()
            .map(|(id, item)| {
                let sim = cosine_similarity(&item.embedding, embedding);
                (*id, sim)
            })
            .collect();
        
        results.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        results.truncate(k);
        results
    }
    
    /// Search by kind
    pub fn search_by_kind(&self, kind: MemoryKind, limit: usize) -> Vec<&MemoryItem> {
        self.by_kind
            .get(&kind)
            .map(|ids| {
                ids.iter()
                    .filter_map(|id| self.items.get(id))
                    .take(limit)
                    .collect()
            })
            .unwrap_or_default()
    }
    
    /// Apply decay to all items
    pub fn apply_decay(&mut self) {
        let max_access = self.items.values()
            .map(|i| i.access_count)
            .max()
            .unwrap_or(1)
            .max(1);
        
        let mut to_remove = Vec::new();
        
        for (id, item) in &mut self.items {
            // w_{t+1} = w_t · e^(-λ(1-ROI)) · (1 + α·access_count/max_access)
            let roi = item.roi as f64;
            let access_boost = 1.0 + self.access_alpha * (item.access_count as f64 / max_access as f64);
            
            item.weight *= (-self.decay_lambda * (1.0 - roi)).exp() * access_boost;
            item.decay_factor = item.weight as f32;
            
            // Remove if decayed too much
            if item.weight < 0.01 {
                to_remove.push(*id);
            }
        }
        
        // Remove decayed items
        for id in to_remove {
            self.remove(&id);
        }
    }
    
    /// Remove item
    pub fn remove(&mut self, id: &Uuid) -> Option<MemoryItem> {
        if let Some(item) = self.items.remove(id) {
            self.total_bytes = self.total_bytes.saturating_sub(item.payload.len());
            
            if let Some(ids) = self.by_kind.get_mut(&item.kind) {
                ids.retain(|i| i != id);
            }
            
            Some(item)
        } else {
            None
        }
    }
    
    /// Ensure capacity for new item
    fn ensure_capacity(&mut self, new_bytes: usize) -> Result<(), PxError> {
        // Check item count
        while self.items.len() >= self.max_items {
            // Remove lowest weight item
            let min_id = self.items.iter()
                .min_by(|a, b| a.1.weight.partial_cmp(&b.1.weight).unwrap_or(std::cmp::Ordering::Equal))
                .map(|(id, _)| *id);
            
            if let Some(id) = min_id {
                self.remove(&id);
            } else {
                break;
            }
        }
        
        // Check byte capacity
        while self.total_bytes + new_bytes > self.max_bytes {
            let min_id = self.items.iter()
                .min_by(|a, b| a.1.weight.partial_cmp(&b.1.weight).unwrap_or(std::cmp::Ordering::Equal))
                .map(|(id, _)| *id);
            
            if let Some(id) = min_id {
                self.remove(&id);
            } else {
                return Err(PxError::MemoryError("Cannot free memory".into()));
            }
        }
        
        Ok(())
    }
    
    /// Get memory size
    pub fn size(&self) -> usize {
        self.items.len()
    }
    
    /// Get total bytes used
    pub fn bytes_used(&self) -> usize {
        self.total_bytes
    }
    
    /// Create snapshot
    pub fn snapshot(&self) -> MemorySnapshot {
        MemorySnapshot {
            item_count: self.items.len(),
            total_bytes: self.total_bytes,
            by_kind: self.by_kind.iter()
                .map(|(k, v)| (*k, v.len()))
                .collect(),
            avg_weight: self.items.values().map(|i| i.weight).sum::<f64>() / self.items.len().max(1) as f64,
            avg_roi: self.items.values().map(|i| i.roi as f64).sum::<f64>() / self.items.len().max(1) as f64,
        }
    }
}

/// Memory snapshot
#[derive(Debug, Clone)]
pub struct MemorySnapshot {
    pub item_count: usize,
    pub total_bytes: usize,
    pub by_kind: HashMap<MemoryKind, usize>,
    pub avg_weight: f64,
    pub avg_roi: f64,
}

/// Compute ROI for data
/// ROI(d) = (ℓ(d) - min_Φ ℓ(Φ(d))) / (1 + cost(d))
pub fn compute_roi(data: &[u8], phi: &Transform) -> f32 {
    let l_d = mdl::description_length(data);
    
    let l_phi_d = match phi.apply(data) {
        Ok(transformed) => mdl::description_length(&transformed) + phi.description_length(),
        Err(_) => l_d,
    };
    
    let cost = data.len() as f64 * 0.001; // Simple cost model
    
    ((l_d - l_phi_d) / (1.0 + cost)).max(0.0) as f32
}

/// Compute embedding for data
fn compute_embedding(data: &[u8]) -> Vec<f32> {
    // Simple embedding: byte frequency histogram + length features
    let mut embedding = vec![0.0f32; 128];
    
    // Byte frequencies (first 64 dims)
    for &b in data {
        let bucket = (b as usize) / 4;
        if bucket < 64 {
            embedding[bucket] += 1.0;
        }
    }
    
    // Normalize
    let sum: f32 = embedding[..64].iter().sum();
    if sum > 0.0 {
        for v in &mut embedding[..64] {
            *v /= sum;
        }
    }
    
    // Length features (dims 64-67)
    embedding[64] = (data.len() as f32).log2() / 20.0;
    embedding[65] = (data.len() as f32 / 1000.0).min(1.0);
    
    // Entropy (dim 68)
    let entropy = crate::noise::analyze_noise(data, &PxConfig::default()).metrics.n2_entropy;
    embedding[68] = entropy as f32;
    
    // Compressibility (dim 69)
    let compress = mdl::compute_compressibility(data);
    embedding[69] = compress as f32;
    
    embedding
}

/// Cosine similarity
fn cosine_similarity(a: &[f32], b: &[f32]) -> f64 {
    if a.len() != b.len() {
        return 0.0;
    }
    
    let dot: f32 = a.iter().zip(b.iter()).map(|(&x, &y)| x * y).sum();
    let norm_a: f32 = a.iter().map(|&x| x * x).sum::<f32>().sqrt();
    let norm_b: f32 = b.iter().map(|&x| x * x).sum::<f32>().sqrt();
    
    if norm_a < 1e-10 || norm_b < 1e-10 {
        return 0.0;
    }
    
    (dot / (norm_a * norm_b)) as f64
}

/// Classify data kind
fn classify_kind(data: &[u8]) -> MemoryKind {
    // Simple heuristic
    if std::str::from_utf8(data).is_ok() {
        if data.len() > 100 {
            MemoryKind::Knowledge
        } else {
            MemoryKind::Pattern
        }
    } else {
        MemoryKind::Data
    }
}

/// Memory pack for serialization
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct MemPack {
    pub version: u32,
    pub items: Vec<MemPackItem>,
    pub metadata: MemPackMetadata,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct MemPackItem {
    pub id: String,
    pub kind: String,
    pub payload_b64: String,
    pub roi: f32,
    pub weight: f64,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct MemPackMetadata {
    pub created_at: String,
    pub item_count: usize,
    pub total_bytes: usize,
}

impl MemoryManager {
    /// Export to MemPack
    pub fn export(&self) -> MemPack {
        let items: Vec<MemPackItem> = self.items.values()
            .map(|item| MemPackItem {
                id: item.id.to_string(),
                kind: format!("{:?}", item.kind),
                payload_b64: base64_encode(&item.payload),
                roi: item.roi,
                weight: item.weight,
            })
            .collect();
        
        MemPack {
            version: 1,
            items,
            metadata: MemPackMetadata {
                created_at: crate::utils::now_iso(),
                item_count: self.items.len(),
                total_bytes: self.total_bytes,
            },
        }
    }
    
    /// Import from MemPack
    pub fn import(&mut self, pack: &MemPack) -> Result<usize, PxError> {
        let mut imported = 0;
        
        for item in &pack.items {
            let payload = base64_decode(&item.payload_b64)
                .map_err(|e| PxError::MemoryError(format!("Invalid base64: {}", e)))?;
            
            let id = Uuid::parse_str(&item.id)
                .map_err(|e| PxError::MemoryError(format!("Invalid UUID: {}", e)))?;
            
            let kind = match item.kind.as_str() {
                "Data" => MemoryKind::Data,
                "Pattern" => MemoryKind::Pattern,
                "Transform" => MemoryKind::Transform,
                "Knowledge" => MemoryKind::Knowledge,
                "Strategy" => MemoryKind::Strategy,
                _ => MemoryKind::Data,
            };
            
            let embedding = compute_embedding(&payload);
            
            let mem_item = MemoryItem {
                id,
                version: 1,
                kind,
                payload: payload.clone(),
                embedding,
                provenance: Provenance {
                    source: "import".into(),
                    trace_id: None,
                    parent_id: None,
                    confidence: 1.0,
                },
                t_score: 0.0,
                ig_score: item.roi,
                roi: item.roi,
                decay_factor: item.weight as f32,
                weight: item.weight,
                created_at: Instant::now(),
                last_used: Instant::now(),
                access_count: 0,
            };
            
            self.total_bytes += payload.len();
            self.by_kind.entry(kind).or_insert_with(Vec::new).push(id);
            self.items.insert(id, mem_item);
            imported += 1;
        }
        
        Ok(imported)
    }
}

fn base64_encode(data: &[u8]) -> String {
    // Simple base64 encoding
    const CHARSET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut result = String::new();
    
    for chunk in data.chunks(3) {
        let b0 = chunk[0] as usize;
        let b1 = chunk.get(1).copied().unwrap_or(0) as usize;
        let b2 = chunk.get(2).copied().unwrap_or(0) as usize;
        
        let n = (b0 << 16) | (b1 << 8) | b2;
        
        result.push(CHARSET[(n >> 18) & 63] as char);
        result.push(CHARSET[(n >> 12) & 63] as char);
        result.push(if chunk.len() > 1 { CHARSET[(n >> 6) & 63] as char } else { '=' });
        result.push(if chunk.len() > 2 { CHARSET[n & 63] as char } else { '=' });
    }
    
    result
}

fn base64_decode(s: &str) -> Result<Vec<u8>, String> {
    const DECODE: [i8; 128] = [
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,63,
        52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-1,-1,-1,
        -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,
        15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,
        -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,
        41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1,
    ];
    
    let bytes: Vec<u8> = s.bytes().filter(|&b| b != b'=').collect();
    let mut result = Vec::new();
    
    for chunk in bytes.chunks(4) {
        if chunk.len() < 2 {
            continue;
        }
        
        let v: Vec<i8> = chunk.iter()
            .map(|&b| if b < 128 { DECODE[b as usize] } else { -1 })
            .collect();
        
        if v.iter().any(|&x| x < 0) {
            return Err("Invalid base64 character".into());
        }
        
        let n = ((v[0] as u32) << 18) | ((v.get(1).copied().unwrap_or(0) as u32) << 12)
            | ((v.get(2).copied().unwrap_or(0) as u32) << 6) | (v.get(3).copied().unwrap_or(0) as u32);
        
        result.push((n >> 16) as u8);
        if chunk.len() > 2 {
            result.push((n >> 8) as u8);
        }
        if chunk.len() > 3 {
            result.push(n as u8);
        }
    }
    
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_memory_manager() {
        let config = PxConfig::default();
        let mut mem = MemoryManager::new(&config);
        
        assert_eq!(mem.size(), 0);
    }
    
    #[test]
    fn test_cosine_similarity() {
        let a = vec![1.0, 0.0, 0.0];
        let b = vec![1.0, 0.0, 0.0];
        assert!((cosine_similarity(&a, &b) - 1.0).abs() < 0.001);
        
        let c = vec![0.0, 1.0, 0.0];
        assert!(cosine_similarity(&a, &c).abs() < 0.001);
    }
    
    #[test]
    fn test_base64() {
        let data = b"Hello, World!";
        let encoded = base64_encode(data);
        let decoded = base64_decode(&encoded).unwrap();
        assert_eq!(decoded, data);
    }
}
