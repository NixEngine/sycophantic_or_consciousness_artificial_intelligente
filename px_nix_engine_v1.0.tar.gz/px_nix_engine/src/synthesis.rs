//! # Synthesis Module (DSL-Stair)
//! 
//! Program synthesis with multi-level DSL hierarchy.
//! 
//! ## DSL Levels
//! - Level 0: Linear rules (simple pattern matching)
//! - Level 1: Regular grammars (regex-like)
//! - Level 2: Symbolic expressions (arithmetic)
//! - Level 3: Functional programs (typed lambda)

use crate::{PxConfig, PxError, prism};
use uuid::Uuid;

/// Transform (program/transformer Φ)
#[derive(Debug, Clone)]
pub struct Transform {
    pub id: Uuid,
    pub level: DslLevel,
    pub program: Program,
    pub metadata: TransformMetadata,
}

impl Transform {
    pub fn identity() -> Self {
        Self {
            id: Uuid::new_v4(),
            level: DslLevel::Linear,
            program: Program::Identity,
            metadata: TransformMetadata::default(),
        }
    }
    
    /// Apply transform to data
    pub fn apply(&self, data: &[u8]) -> Result<Vec<u8>, PxError> {
        match &self.program {
            Program::Identity => Ok(data.to_vec()),
            Program::LinearRule(rule) => apply_linear_rule(data, rule),
            Program::RegularGrammar(grammar) => apply_grammar(data, grammar),
            Program::SymbolicExpr(expr) => apply_symbolic(data, expr),
            Program::Functional(func) => apply_functional(data, func),
            Program::Composite(transforms) => {
                let mut result = data.to_vec();
                for t in transforms {
                    result = t.apply(&result)?;
                }
                Ok(result)
            }
        }
    }
    
    /// Description length of the transform
    pub fn description_length(&self) -> f64 {
        match &self.program {
            Program::Identity => 1.0,
            Program::LinearRule(rule) => {
                (rule.pattern.len() + rule.replacement.len()) as f64 * 8.0 + 16.0
            }
            Program::RegularGrammar(g) => {
                g.rules.iter().map(|r| r.len()).sum::<usize>() as f64 * 8.0 + 32.0
            }
            Program::SymbolicExpr(e) => e.complexity() * 8.0 + 64.0,
            Program::Functional(f) => f.complexity() * 8.0 + 128.0,
            Program::Composite(ts) => ts.iter().map(|t| t.description_length()).sum(),
        }
    }
    
    /// Estimated execution cost
    pub fn estimated_cost(&self, input_size: usize) -> u64 {
        match &self.program {
            Program::Identity => 1,
            Program::LinearRule(_) => input_size as u64 * 2,
            Program::RegularGrammar(_) => input_size as u64 * 10,
            Program::SymbolicExpr(_) => input_size as u64 * 5,
            Program::Functional(_) => input_size as u64 * 20,
            Program::Composite(ts) => ts.iter().map(|t| t.estimated_cost(input_size)).sum(),
        }
    }
    
    /// Check if has external calls
    pub fn has_external_calls(&self) -> bool {
        match &self.program {
            Program::Functional(f) => f.has_io,
            _ => false,
        }
    }
    
    /// Get domain if known
    pub fn domain(&self) -> Option<&str> {
        self.metadata.domain.as_deref()
    }
    
    /// Is this a novel/untested transform?
    pub fn is_novel(&self) -> bool {
        self.metadata.times_used == 0
    }
}

/// DSL hierarchy level
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum DslLevel {
    Linear = 0,      // Simple rules
    Regular = 1,     // Regular grammars
    Symbolic = 2,    // Symbolic expressions
    Functional = 3,  // Functional programs
}

/// Program representation
#[derive(Debug, Clone)]
pub enum Program {
    Identity,
    LinearRule(LinearRule),
    RegularGrammar(RegularGrammar),
    SymbolicExpr(SymbolicExpr),
    Functional(FunctionalProgram),
    Composite(Vec<Transform>),
}

/// Linear rule (pattern -> replacement)
#[derive(Debug, Clone)]
pub struct LinearRule {
    pub pattern: Vec<u8>,
    pub replacement: Vec<u8>,
    pub flags: RuleFlags,
}

#[derive(Debug, Clone, Default)]
pub struct RuleFlags {
    pub case_insensitive: bool,
    pub global: bool,
}

/// Regular grammar
#[derive(Debug, Clone)]
pub struct RegularGrammar {
    pub rules: Vec<String>,
    pub start_symbol: String,
}

/// Symbolic expression
#[derive(Debug, Clone)]
pub enum SymbolicExpr {
    Const(f64),
    Var(String),
    Add(Box<SymbolicExpr>, Box<SymbolicExpr>),
    Mul(Box<SymbolicExpr>, Box<SymbolicExpr>),
    Sub(Box<SymbolicExpr>, Box<SymbolicExpr>),
    Div(Box<SymbolicExpr>, Box<SymbolicExpr>),
    Neg(Box<SymbolicExpr>),
    Sin(Box<SymbolicExpr>),
    Cos(Box<SymbolicExpr>),
    Exp(Box<SymbolicExpr>),
    Log(Box<SymbolicExpr>),
}

impl SymbolicExpr {
    fn complexity(&self) -> f64 {
        match self {
            SymbolicExpr::Const(_) | SymbolicExpr::Var(_) => 1.0,
            SymbolicExpr::Add(a, b) | SymbolicExpr::Mul(a, b) |
            SymbolicExpr::Sub(a, b) | SymbolicExpr::Div(a, b) => {
                1.0 + a.complexity() + b.complexity()
            }
            SymbolicExpr::Neg(a) | SymbolicExpr::Sin(a) | 
            SymbolicExpr::Cos(a) | SymbolicExpr::Exp(a) | 
            SymbolicExpr::Log(a) => {
                1.0 + a.complexity()
            }
        }
    }
    
    fn evaluate(&self, vars: &hashbrown::HashMap<String, f64>) -> f64 {
        match self {
            SymbolicExpr::Const(c) => *c,
            SymbolicExpr::Var(name) => vars.get(name).copied().unwrap_or(0.0),
            SymbolicExpr::Add(a, b) => a.evaluate(vars) + b.evaluate(vars),
            SymbolicExpr::Mul(a, b) => a.evaluate(vars) * b.evaluate(vars),
            SymbolicExpr::Sub(a, b) => a.evaluate(vars) - b.evaluate(vars),
            SymbolicExpr::Div(a, b) => {
                let d = b.evaluate(vars);
                if d.abs() < 1e-10 { 0.0 } else { a.evaluate(vars) / d }
            }
            SymbolicExpr::Neg(a) => -a.evaluate(vars),
            SymbolicExpr::Sin(a) => a.evaluate(vars).sin(),
            SymbolicExpr::Cos(a) => a.evaluate(vars).cos(),
            SymbolicExpr::Exp(a) => a.evaluate(vars).exp(),
            SymbolicExpr::Log(a) => a.evaluate(vars).max(1e-10).ln(),
        }
    }
}

/// Functional program
#[derive(Debug, Clone)]
pub struct FunctionalProgram {
    pub params: Vec<String>,
    pub body: FuncBody,
    pub has_io: bool,
}

impl FunctionalProgram {
    fn complexity(&self) -> f64 {
        self.body.complexity() + self.params.len() as f64
    }
}

#[derive(Debug, Clone)]
pub enum FuncBody {
    Const(Vec<u8>),
    Param(String),
    Apply(String, Vec<FuncBody>),
    Let(String, Box<FuncBody>, Box<FuncBody>),
    If(Box<FuncBody>, Box<FuncBody>, Box<FuncBody>),
    Map(Box<FuncBody>, Box<FuncBody>),
    Filter(Box<FuncBody>, Box<FuncBody>),
    Fold(Box<FuncBody>, Box<FuncBody>, Box<FuncBody>),
}

impl FuncBody {
    fn complexity(&self) -> f64 {
        match self {
            FuncBody::Const(_) | FuncBody::Param(_) => 1.0,
            FuncBody::Apply(_, args) => 1.0 + args.iter().map(|a| a.complexity()).sum::<f64>(),
            FuncBody::Let(_, v, b) => 2.0 + v.complexity() + b.complexity(),
            FuncBody::If(c, t, e) => 3.0 + c.complexity() + t.complexity() + e.complexity(),
            FuncBody::Map(f, l) | FuncBody::Filter(f, l) => 2.0 + f.complexity() + l.complexity(),
            FuncBody::Fold(f, i, l) => 3.0 + f.complexity() + i.complexity() + l.complexity(),
        }
    }
}

/// Transform metadata
#[derive(Debug, Clone, Default)]
pub struct TransformMetadata {
    pub domain: Option<String>,
    pub times_used: u64,
    pub avg_gain: f64,
    pub created_at: String,
}

/// Create identity transform
pub fn identity_transform() -> Transform {
    Transform::identity()
}

/// Synthesize transforms at a given DSL level
pub fn synthesize_level(
    data: &[u8],
    level: usize,
    bands: &[prism::Band],
    config: &PxConfig,
) -> Result<Vec<Transform>, PxError> {
    let dsl_level = match level {
        0 => DslLevel::Linear,
        1 => DslLevel::Regular,
        2 => DslLevel::Symbolic,
        _ => DslLevel::Functional,
    };
    
    match dsl_level {
        DslLevel::Linear => synthesize_linear(data, bands, config),
        DslLevel::Regular => synthesize_regular(data, bands, config),
        DslLevel::Symbolic => synthesize_symbolic(data, bands, config),
        DslLevel::Functional => synthesize_functional(data, bands, config),
    }
}

/// Synthesize linear rules
fn synthesize_linear(
    data: &[u8],
    _bands: &[prism::Band],
    _config: &PxConfig,
) -> Result<Vec<Transform>, PxError> {
    let mut transforms = Vec::new();
    
    // Find repeated patterns
    let patterns = find_repeated_patterns(data, 3, 20);
    
    for (pattern, count) in patterns {
        if count >= 3 {
            // Create replacement with shorter encoding
            let replacement = compress_pattern(&pattern);
            
            if replacement.len() < pattern.len() {
                transforms.push(Transform {
                    id: Uuid::new_v4(),
                    level: DslLevel::Linear,
                    program: Program::LinearRule(LinearRule {
                        pattern,
                        replacement,
                        flags: RuleFlags::default(),
                    }),
                    metadata: TransformMetadata::default(),
                });
            }
        }
    }
    
    Ok(transforms)
}

/// Synthesize regular grammar rules
fn synthesize_regular(
    data: &[u8],
    _bands: &[prism::Band],
    _config: &PxConfig,
) -> Result<Vec<Transform>, PxError> {
    let mut transforms = Vec::new();
    
    // For text data, find regex-like patterns
    if let Ok(text) = std::str::from_utf8(data) {
        // Simple digit sequence detection
        if text.chars().any(|c| c.is_ascii_digit()) {
            transforms.push(Transform {
                id: Uuid::new_v4(),
                level: DslLevel::Regular,
                program: Program::RegularGrammar(RegularGrammar {
                    rules: vec!["DIGITS -> [0-9]+".into()],
                    start_symbol: "DIGITS".into(),
                }),
                metadata: TransformMetadata::default(),
            });
        }
        
        // Word pattern detection
        if text.chars().any(|c| c.is_ascii_alphabetic()) {
            transforms.push(Transform {
                id: Uuid::new_v4(),
                level: DslLevel::Regular,
                program: Program::RegularGrammar(RegularGrammar {
                    rules: vec!["WORD -> [a-zA-Z]+".into()],
                    start_symbol: "WORD".into(),
                }),
                metadata: TransformMetadata::default(),
            });
        }
    }
    
    Ok(transforms)
}

/// Synthesize symbolic expressions
fn synthesize_symbolic(
    data: &[u8],
    bands: &[prism::Band],
    _config: &PxConfig,
) -> Result<Vec<Transform>, PxError> {
    let mut transforms = Vec::new();
    
    // Look for numeric patterns in trend band
    if let Some(trend_band) = bands.iter().find(|b| b.name == "trend") {
        if trend_band.coefficients.len() >= 3 {
            let coeffs = &trend_band.coefficients;
            
            // Try to fit linear model: a*x + b
            let n = coeffs.len() as f64;
            let sum_x: f64 = (0..coeffs.len()).map(|i| i as f64).sum();
            let sum_y: f64 = coeffs.iter().sum();
            let sum_xy: f64 = coeffs.iter().enumerate().map(|(i, &y)| i as f64 * y).sum();
            let sum_xx: f64 = (0..coeffs.len()).map(|i| (i as f64).powi(2)).sum();
            
            let denom = n * sum_xx - sum_x * sum_x;
            if denom.abs() > 1e-10 {
                let a = (n * sum_xy - sum_x * sum_y) / denom;
                let b = (sum_y - a * sum_x) / n;
                
                // Create linear transform: a*x + b
                let expr = SymbolicExpr::Add(
                    Box::new(SymbolicExpr::Mul(
                        Box::new(SymbolicExpr::Const(a)),
                        Box::new(SymbolicExpr::Var("x".into())),
                    )),
                    Box::new(SymbolicExpr::Const(b)),
                );
                
                transforms.push(Transform {
                    id: Uuid::new_v4(),
                    level: DslLevel::Symbolic,
                    program: Program::SymbolicExpr(expr),
                    metadata: TransformMetadata::default(),
                });
            }
        }
    }
    
    Ok(transforms)
}

/// Synthesize functional programs
fn synthesize_functional(
    data: &[u8],
    _bands: &[prism::Band],
    _config: &PxConfig,
) -> Result<Vec<Transform>, PxError> {
    let mut transforms = Vec::new();
    
    // Simple map transform: increment each byte
    transforms.push(Transform {
        id: Uuid::new_v4(),
        level: DslLevel::Functional,
        program: Program::Functional(FunctionalProgram {
            params: vec!["data".into()],
            body: FuncBody::Map(
                Box::new(FuncBody::Apply("inc".into(), vec![])),
                Box::new(FuncBody::Param("data".into())),
            ),
            has_io: false,
        }),
        metadata: TransformMetadata::default(),
    });
    
    // Filter transform: keep only printable ASCII
    if std::str::from_utf8(data).is_ok() {
        transforms.push(Transform {
            id: Uuid::new_v4(),
            level: DslLevel::Functional,
            program: Program::Functional(FunctionalProgram {
                params: vec!["data".into()],
                body: FuncBody::Filter(
                    Box::new(FuncBody::Apply("is_printable".into(), vec![])),
                    Box::new(FuncBody::Param("data".into())),
                ),
                has_io: false,
            }),
            metadata: TransformMetadata::default(),
        });
    }
    
    Ok(transforms)
}

// Helper functions

fn apply_linear_rule(data: &[u8], rule: &LinearRule) -> Result<Vec<u8>, PxError> {
    let pattern = &rule.pattern;
    let replacement = &rule.replacement;
    
    if pattern.is_empty() {
        return Ok(data.to_vec());
    }
    
    let mut result = Vec::new();
    let mut i = 0;
    
    while i < data.len() {
        if data[i..].starts_with(pattern) {
            result.extend_from_slice(replacement);
            i += pattern.len();
            if !rule.flags.global {
                result.extend_from_slice(&data[i..]);
                return Ok(result);
            }
        } else {
            result.push(data[i]);
            i += 1;
        }
    }
    
    Ok(result)
}

fn apply_grammar(data: &[u8], _grammar: &RegularGrammar) -> Result<Vec<u8>, PxError> {
    // Simplified: just return data as-is (full implementation would parse)
    Ok(data.to_vec())
}

fn apply_symbolic(data: &[u8], expr: &SymbolicExpr) -> Result<Vec<u8>, PxError> {
    // Apply expression to each byte as x
    let mut vars = hashbrown::HashMap::new();
    
    let result: Vec<u8> = data.iter()
        .map(|&b| {
            vars.insert("x".into(), b as f64);
            let val = expr.evaluate(&vars);
            val.clamp(0.0, 255.0) as u8
        })
        .collect();
    
    Ok(result)
}

fn apply_functional(data: &[u8], _func: &FunctionalProgram) -> Result<Vec<u8>, PxError> {
    // Simplified: just return data (full implementation would interpret)
    Ok(data.to_vec())
}

fn find_repeated_patterns(data: &[u8], min_len: usize, max_len: usize) -> Vec<(Vec<u8>, usize)> {
    let mut counts: hashbrown::HashMap<Vec<u8>, usize> = hashbrown::HashMap::new();
    
    for len in min_len..=max_len.min(data.len()) {
        for window in data.windows(len) {
            *counts.entry(window.to_vec()).or_insert(0) += 1;
        }
    }
    
    let mut patterns: Vec<_> = counts.into_iter()
        .filter(|(_, count)| *count >= 2)
        .collect();
    
    patterns.sort_by(|a, b| (b.0.len() * b.1).cmp(&(a.0.len() * a.1)));
    patterns.truncate(10);
    
    patterns
}

fn compress_pattern(pattern: &[u8]) -> Vec<u8> {
    // Simple run-length encoding
    let compressed = lz4_flex::compress_prepend_size(pattern);
    
    if compressed.len() < pattern.len() {
        compressed
    } else {
        pattern.to_vec()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_identity_transform() {
        let t = identity_transform();
        let data = b"Hello";
        let result = t.apply(data).unwrap();
        assert_eq!(result, data);
    }
    
    #[test]
    fn test_linear_rule() {
        let rule = LinearRule {
            pattern: b"Hello".to_vec(),
            replacement: b"Hi".to_vec(),
            flags: RuleFlags { global: true, ..Default::default() },
        };
        
        let data = b"Hello World Hello";
        let result = apply_linear_rule(data, &rule).unwrap();
        assert_eq!(result, b"Hi World Hi");
    }
    
    #[test]
    fn test_symbolic_expr() {
        let expr = SymbolicExpr::Add(
            Box::new(SymbolicExpr::Var("x".into())),
            Box::new(SymbolicExpr::Const(10.0)),
        );
        
        let mut vars = hashbrown::HashMap::new();
        vars.insert("x".into(), 5.0);
        
        assert_eq!(expr.evaluate(&vars), 15.0);
    }
}
