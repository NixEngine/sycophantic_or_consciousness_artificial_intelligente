//! # Utils Module
//! 
//! Common utilities for the Px/Nix Engine.

use std::time::{SystemTime, UNIX_EPOCH};

/// Get current time in ISO 8601 format
pub fn now_iso() -> String {
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    
    let secs = now.as_secs();
    let millis = now.subsec_millis();
    
    // Simple ISO 8601 format
    format_timestamp(secs, millis)
}

fn format_timestamp(secs: u64, millis: u32) -> String {
    // Calculate date components
    let days_since_epoch = secs / 86400;
    let time_of_day = secs % 86400;
    
    let hours = time_of_day / 3600;
    let minutes = (time_of_day % 3600) / 60;
    let seconds = time_of_day % 60;
    
    // Calculate year, month, day (simplified)
    let (year, month, day) = days_to_ymd(days_since_epoch);
    
    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z",
        year, month, day, hours, minutes, seconds, millis
    )
}

fn days_to_ymd(days: u64) -> (u64, u64, u64) {
    // Simplified calculation
    let mut remaining = days;
    let mut year = 1970u64;
    
    loop {
        let days_in_year = if is_leap_year(year) { 366 } else { 365 };
        if remaining < days_in_year {
            break;
        }
        remaining -= days_in_year;
        year += 1;
    }
    
    let months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let mut month = 1u64;
    
    for (i, &days_in_month) in months.iter().enumerate() {
        let days = if i == 1 && is_leap_year(year) {
            29
        } else {
            days_in_month
        };
        
        if remaining < days {
            break;
        }
        remaining -= days;
        month += 1;
    }
    
    (year, month, remaining + 1)
}

fn is_leap_year(year: u64) -> bool {
    (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)
}

/// Clip value to [0, 1]
pub fn clip01(x: f64) -> f64 {
    x.clamp(0.0, 1.0)
}

/// Geometric mean
pub fn geometric_mean(values: &[f64]) -> f64 {
    if values.is_empty() {
        return 0.0;
    }
    
    let log_sum: f64 = values.iter()
        .filter(|&&x| x > 0.0)
        .map(|x| x.ln())
        .sum();
    
    let n = values.iter().filter(|&&x| x > 0.0).count();
    if n == 0 {
        return 0.0;
    }
    
    (log_sum / n as f64).exp()
}

/// Harmonic mean
pub fn harmonic_mean(values: &[f64]) -> f64 {
    if values.is_empty() {
        return 0.0;
    }
    
    let inv_sum: f64 = values.iter()
        .filter(|&&x| x > 1e-10)
        .map(|x| 1.0 / x)
        .sum();
    
    let n = values.iter().filter(|&&x| x > 1e-10).count();
    if n == 0 || inv_sum < 1e-10 {
        return 0.0;
    }
    
    n as f64 / inv_sum
}

/// Weighted average
pub fn weighted_avg(values: &[(f64, f64)]) -> f64 {
    let total_weight: f64 = values.iter().map(|(_, w)| w).sum();
    if total_weight < 1e-10 {
        return 0.0;
    }
    
    let weighted_sum: f64 = values.iter().map(|(v, w)| v * w).sum();
    weighted_sum / total_weight
}

/// Exponential moving average update
pub fn ewma(current: f64, new_value: f64, alpha: f64) -> f64 {
    alpha * new_value + (1.0 - alpha) * current
}

/// Running statistics
#[derive(Debug, Clone, Default)]
pub struct RunningStats {
    count: u64,
    mean: f64,
    m2: f64,
}

impl RunningStats {
    pub fn new() -> Self {
        Self::default()
    }
    
    /// Update with new value (Welford's algorithm)
    pub fn update(&mut self, x: f64) {
        self.count += 1;
        let delta = x - self.mean;
        self.mean += delta / self.count as f64;
        let delta2 = x - self.mean;
        self.m2 += delta * delta2;
    }
    
    pub fn mean(&self) -> f64 {
        self.mean
    }
    
    pub fn variance(&self) -> f64 {
        if self.count < 2 {
            return 0.0;
        }
        self.m2 / (self.count - 1) as f64
    }
    
    pub fn std(&self) -> f64 {
        self.variance().sqrt()
    }
    
    pub fn count(&self) -> u64 {
        self.count
    }
}

/// Ring buffer for fixed-size history
pub struct RingBuffer<T> {
    buffer: Vec<Option<T>>,
    head: usize,
    size: usize,
}

impl<T: Clone> RingBuffer<T> {
    pub fn new(capacity: usize) -> Self {
        Self {
            buffer: vec![None; capacity],
            head: 0,
            size: 0,
        }
    }
    
    pub fn push(&mut self, item: T) {
        self.buffer[self.head] = Some(item);
        self.head = (self.head + 1) % self.buffer.len();
        if self.size < self.buffer.len() {
            self.size += 1;
        }
    }
    
    pub fn iter(&self) -> impl Iterator<Item = &T> {
        let start = if self.size < self.buffer.len() {
            0
        } else {
            self.head
        };
        
        (0..self.size).map(move |i| {
            let idx = (start + i) % self.buffer.len();
            self.buffer[idx].as_ref().unwrap()
        })
    }
    
    pub fn len(&self) -> usize {
        self.size
    }
    
    pub fn is_empty(&self) -> bool {
        self.size == 0
    }
    
    pub fn clear(&mut self) {
        for item in &mut self.buffer {
            *item = None;
        }
        self.head = 0;
        self.size = 0;
    }
}

/// Simple hash for fingerprinting
pub fn simple_hash(data: &[u8]) -> u64 {
    let mut hash = 0xcbf29ce484222325u64; // FNV-1a offset
    for &byte in data {
        hash ^= byte as u64;
        hash = hash.wrapping_mul(0x100000001b3); // FNV-1a prime
    }
    hash
}

/// Percentile calculation
pub fn percentile(sorted_values: &[f64], p: f64) -> f64 {
    if sorted_values.is_empty() {
        return 0.0;
    }
    
    let idx = (p / 100.0 * (sorted_values.len() - 1) as f64).round() as usize;
    sorted_values[idx.min(sorted_values.len() - 1)]
}

/// Interpolated percentile
pub fn percentile_interp(sorted_values: &[f64], p: f64) -> f64 {
    if sorted_values.is_empty() {
        return 0.0;
    }
    if sorted_values.len() == 1 {
        return sorted_values[0];
    }
    
    let rank = p / 100.0 * (sorted_values.len() - 1) as f64;
    let lower = rank.floor() as usize;
    let upper = (lower + 1).min(sorted_values.len() - 1);
    let frac = rank - lower as f64;
    
    sorted_values[lower] * (1.0 - frac) + sorted_values[upper] * frac
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_now_iso() {
        let ts = now_iso();
        assert!(ts.contains("T"));
        assert!(ts.ends_with("Z"));
    }
    
    #[test]
    fn test_geometric_mean() {
        let values = vec![1.0, 2.0, 4.0, 8.0];
        let gm = geometric_mean(&values);
        assert!((gm - 2.828).abs() < 0.01);
    }
    
    #[test]
    fn test_running_stats() {
        let mut stats = RunningStats::new();
        stats.update(1.0);
        stats.update(2.0);
        stats.update(3.0);
        
        assert!((stats.mean() - 2.0).abs() < 0.001);
        assert!((stats.variance() - 1.0).abs() < 0.001);
    }
    
    #[test]
    fn test_ring_buffer() {
        let mut rb = RingBuffer::new(3);
        rb.push(1);
        rb.push(2);
        rb.push(3);
        rb.push(4);
        
        let items: Vec<_> = rb.iter().copied().collect();
        assert_eq!(items, vec![2, 3, 4]);
    }
    
    #[test]
    fn test_percentile() {
        let values = vec![1.0, 2.0, 3.0, 4.0, 5.0];
        assert_eq!(percentile(&values, 50.0), 3.0);
        assert_eq!(percentile(&values, 0.0), 1.0);
        assert_eq!(percentile(&values, 100.0), 5.0);
    }
}
