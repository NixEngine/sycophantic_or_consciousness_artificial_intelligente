//! # Competence Metrics Module
//! 
//! Computes the competence triplet (K_obj, K_semi, K_subj) for Pareto analysis.
//! 
//! ## Formulas
//! - K_obj: Pure objective competence (no rules, no concepts)
//! - K_semi: Semi-objective competence (with rules R)
//! - K_subj: Subjective competence (with concepts C and rules R)

use crate::{PxConfig, mdl, synthesis::Transform};

/// Competence triplet (Pareto vector)
#[derive(Debug, Clone, Copy, Default)]
pub struct CompetenceTriplet {
    /// Objective competence [0,1]
    pub k_obj: f64,
    /// Semi-objective competence [0,1]
    pub k_semi: f64,
    /// Subjective competence [0,1]
    pub k_subj: f64,
}

impl CompetenceTriplet {
    /// Mix competences with weights
    pub fn mix(&self, w_obj: f64, w_semi: f64, w_subj: f64) -> f64 {
        let sum = w_obj + w_semi + w_subj;
        if sum == 0.0 {
            return 0.0;
        }
        (w_obj * self.k_obj + w_semi * self.k_semi + w_subj * self.k_subj) / sum
    }
    
    /// Consistency check between modes
    pub fn consistency(&self) -> f64 {
        let max_diff = (self.k_obj - self.k_semi).abs()
            .max((self.k_obj - self.k_subj).abs())
            .max((self.k_semi - self.k_subj).abs());
        1.0 - max_diff
    }
    
    /// Check if all competences are above threshold
    pub fn all_above(&self, threshold: f64) -> bool {
        self.k_obj >= threshold && self.k_semi >= threshold && self.k_subj >= threshold
    }
    
    /// Minimum competence
    pub fn min(&self) -> f64 {
        self.k_obj.min(self.k_semi).min(self.k_subj)
    }
}

/// Compute objective competence (A1 formula)
/// K_obj(D) = (P_obj(D) · X(D) · R★(D) · (1-κ(D)) · δ(D))^(1/5)
pub fn compute_k_obj(data: &[u8], config: &PxConfig) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    
    let p_obj = compute_p_obj(data, config);
    let x = compute_x(data, config);
    let r_star = compute_r_star(data, config);
    let kappa = compute_kappa(data, config);
    let delta = compute_delta(data, config);
    
    // Geometric mean (5th root)
    let product = p_obj * x * r_star * (1.0 - kappa) * delta;
    
    if product <= 0.0 {
        return 0.0;
    }
    
    product.powf(1.0 / 5.0)
}

/// Compute semi-objective competence (with rules R)
/// K_semi(D;R) = K_obj(R⊙D) · e^(-α·ℓ(R)) · (1 - β·χ(D;R))
pub fn compute_k_semi(data: &[u8], rules: &[Rule], config: &PxConfig) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    
    // Apply rules to data
    let transformed = apply_rules(data, rules);
    
    // Compute K_obj on transformed data
    let k_obj_r = compute_k_obj(&transformed, config);
    
    // Rule complexity penalty
    let l_r = rules_description_length(rules);
    let alpha = 1e-3;
    let rule_penalty = (-alpha * l_r).exp();
    
    // Contamination index
    let chi = compute_contamination(data, rules, config);
    let beta = 0.5;
    
    k_obj_r * rule_penalty * (1.0 - beta * chi)
}

/// Compute subjective competence (with concepts C and rules R)
/// K_subj(D;C,R) = ((1-res(C⊙R⊙D,C)) · Ω(C) · R★^(C)(D) · (1-η(D)))^(1/4) · e^(-γ·ℓ(C))
pub fn compute_k_subj(data: &[u8], concepts: &[Concept], rules: &[Rule], config: &PxConfig) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    
    // Apply concepts and rules
    let transformed = apply_concepts_and_rules(data, concepts, rules);
    
    // Residual under concept
    let res_c = compute_concept_residual(&transformed, concepts);
    let fit = 1.0 - res_c;
    
    // Concept completeness
    let omega = compute_concept_completeness(data, concepts);
    
    // Reproducibility under concept
    let r_star_c = compute_r_star_concept(data, concepts, config);
    
    // Narrative density (penalty for story-telling)
    let eta = compute_narrative_density(data, config);
    
    // Geometric mean (4th root)
    let product = fit * omega * r_star_c * (1.0 - eta);
    
    if product <= 0.0 {
        return 0.0;
    }
    
    let base = product.powf(0.25);
    
    // Concept complexity penalty
    let l_c = concepts_description_length(concepts);
    let gamma = 5e-4;
    
    base * (-gamma * l_c).exp()
}

/// Compute full competence triplet
pub fn compute_competence(
    data: &[u8], 
    rules: &[Rule], 
    concepts: &[Concept],
    config: &PxConfig,
) -> CompetenceTriplet {
    CompetenceTriplet {
        k_obj: compute_k_obj(data, config),
        k_semi: compute_k_semi(data, rules, config),
        k_subj: compute_k_subj(data, concepts, rules, config),
    }
}

// Component metrics

/// Compute objective purity (A1)
/// P_obj(D) = clip[0,1](1 - min_Φ[res(Φ,D) + λℓ(Φ)] / (1 + λℓ(∅)))
pub fn compute_p_obj(data: &[u8], config: &PxConfig) -> f64 {
    if data.is_empty() {
        return 1.0;
    }
    
    // Use compression as proxy for min_Φ
    let l_data = data.len() as f64 * 8.0;
    let l_compressed = mdl::description_length(data);
    
    let min_j = l_compressed + config.lambda * l_compressed.log2().max(1.0);
    let denominator = 1.0 + config.lambda * 8.0; // ℓ(∅) ~ 8 bits
    
    (1.0 - min_j / (l_data * denominator)).clamp(0.0, 1.0)
}

/// Compute intensity of experience (A2)
/// X(D) = (ℓ(D) - min_Φ[ℓ(Φ(D)) + ℓ(Φ)]) / ℓ(D)
fn compute_x(data: &[u8], config: &PxConfig) -> f64 {
    let l_d = data.len() as f64 * 8.0;
    if l_d == 0.0 {
        return 0.0;
    }
    
    let l_compressed = mdl::description_length(data);
    let model_cost = l_compressed.log2().max(1.0);
    
    ((l_d - l_compressed - model_cost) / l_d).clamp(0.0, 1.0)
}

/// Compute contradiction (A3)
/// κ(D) = min_Φ res(Φ, Φ(D))
fn compute_kappa(data: &[u8], _config: &PxConfig) -> f64 {
    // Approximate using self-consistency of compression
    let compressed = lz4_flex::compress_prepend_size(data);
    
    if let Ok(decompressed) = lz4_flex::decompress_size_prepended(&compressed) {
        if decompressed == data {
            return 0.0; // No contradiction
        }
    }
    
    0.1 // Some contradiction
}

/// Compute reproducibility (A5)
/// R★(D) = 1 - min_Φ E_{S⊂D} res(Φ, D\S)
fn compute_r_star(data: &[u8], _config: &PxConfig) -> f64 {
    if data.len() < 10 {
        return 1.0;
    }
    
    // Sample-based reproducibility check
    use rand::Rng;
    let mut rng = rand::thread_rng();
    
    let mut total_consistency = 0.0;
    let num_samples = 5;
    
    for _ in 0..num_samples {
        // Create random subset (80%)
        let subset: Vec<u8> = data.iter()
            .filter(|_| rng.gen::<f64>() < 0.8)
            .copied()
            .collect();
        
        if subset.is_empty() {
            continue;
        }
        
        // Compare compression ratios
        let ratio_full = mdl::description_length(data) / (data.len() as f64 * 8.0);
        let ratio_subset = mdl::description_length(&subset) / (subset.len() as f64 * 8.0);
        
        let consistency = 1.0 - (ratio_full - ratio_subset).abs();
        total_consistency += consistency;
    }
    
    (total_consistency / num_samples as f64).clamp(0.0, 1.0)
}

/// Compute deterministic emergence (A8)
/// δ(D) = max_Φ (1 - res(Φ,D)) · e^(-λℓ(Φ))
fn compute_delta(data: &[u8], config: &PxConfig) -> f64 {
    let compressed = lz4_flex::compress_prepend_size(data);
    let ratio = compressed.len() as f64 / data.len().max(1) as f64;
    let res = ratio.min(1.0);
    let l_phi = compressed.len() as f64;
    
    (1.0 - res) * (-config.lambda * l_phi).exp()
}

/// Compute contamination index (F1)
/// χ(D;R) = (min_Φ[res(Φ,R⊙D) + ℓ(Φ)] - min_Φ[res(Φ,D) + ℓ(Φ)]) / (1 + ℓ(R))
fn compute_contamination(data: &[u8], rules: &[Rule], _config: &PxConfig) -> f64 {
    if rules.is_empty() {
        return 0.0;
    }
    
    let transformed = apply_rules(data, rules);
    
    let j_original = mdl::description_length(data);
    let j_transformed = mdl::description_length(&transformed);
    let l_r = rules_description_length(rules);
    
    ((j_transformed - j_original) / (1.0 + l_r)).clamp(0.0, 1.0)
}

/// Compute narrative density (F2)
/// η(D) = (1/N) Σ 1[min_Φ Δ(d_i, Φ(d_i)) > 0]
fn compute_narrative_density(data: &[u8], _config: &PxConfig) -> f64 {
    if data.len() < 16 {
        return 0.0;
    }
    
    let window_size = 16;
    let mut count_nonzero = 0;
    let mut total = 0;
    
    for window in data.chunks(window_size) {
        if window.len() < window_size {
            continue;
        }
        
        let compressed = lz4_flex::compress_prepend_size(window);
        if compressed.len() >= window.len() {
            count_nonzero += 1; // Cannot compress = narrative-like
        }
        total += 1;
    }
    
    if total == 0 {
        return 0.0;
    }
    
    count_nonzero as f64 / total as f64
}

/// Compute concept completeness (B10)
/// Ω(C) = 1 - ℓ(D|C) / ℓ(D)
fn compute_concept_completeness(data: &[u8], concepts: &[Concept]) -> f64 {
    if concepts.is_empty() || data.is_empty() {
        return 0.0;
    }
    
    let l_d = mdl::description_length(data);
    
    // Approximate ℓ(D|C) by compression with concept-specific dictionary
    let mut concept_compressed = data.to_vec();
    for concept in concepts {
        // Apply concept patterns as dictionary
        for pattern in &concept.patterns {
            // Simplified: count pattern occurrences
            let _count = count_pattern(data, pattern);
        }
    }
    
    let l_d_given_c = mdl::description_length(&concept_compressed);
    
    (1.0 - l_d_given_c / l_d.max(1.0)).clamp(0.0, 1.0)
}

fn compute_concept_residual(data: &[u8], concepts: &[Concept]) -> f64 {
    if concepts.is_empty() {
        return 1.0;
    }
    
    // Measure how well concepts explain the data
    let covered: usize = concepts.iter()
        .flat_map(|c| c.patterns.iter())
        .map(|p| count_pattern(data, p) * p.len())
        .sum();
    
    let total = data.len().max(1);
    1.0 - (covered as f64 / total as f64).min(1.0)
}

fn compute_r_star_concept(data: &[u8], concepts: &[Concept], config: &PxConfig) -> f64 {
    if concepts.is_empty() {
        return compute_r_star(data, config);
    }
    
    // Reproducibility within concept space
    compute_r_star(data, config) * 0.9 // Slightly reduced for concept constraints
}

fn count_pattern(data: &[u8], pattern: &[u8]) -> usize {
    if pattern.is_empty() || data.len() < pattern.len() {
        return 0;
    }
    
    data.windows(pattern.len())
        .filter(|w| *w == pattern)
        .count()
}

// Data structures

/// Rule for semi-objective competence
#[derive(Debug, Clone)]
pub struct Rule {
    pub id: String,
    pub pattern: Vec<u8>,
    pub replacement: Vec<u8>,
    pub priority: u32,
}

/// Concept for subjective competence
#[derive(Debug, Clone)]
pub struct Concept {
    pub id: String,
    pub name: String,
    pub patterns: Vec<Vec<u8>>,
    pub relations: Vec<(String, String)>,
}

fn apply_rules(data: &[u8], rules: &[Rule]) -> Vec<u8> {
    let mut result = data.to_vec();
    
    // Sort by priority
    let mut sorted_rules = rules.to_vec();
    sorted_rules.sort_by_key(|r| r.priority);
    
    for rule in &sorted_rules {
        // Simple pattern replacement
        let pattern = &rule.pattern;
        let replacement = &rule.replacement;
        
        if pattern.is_empty() {
            continue;
        }
        
        let mut new_result = Vec::new();
        let mut i = 0;
        
        while i < result.len() {
            if result[i..].starts_with(pattern) {
                new_result.extend_from_slice(replacement);
                i += pattern.len();
            } else {
                new_result.push(result[i]);
                i += 1;
            }
        }
        
        result = new_result;
    }
    
    result
}

fn apply_concepts_and_rules(data: &[u8], concepts: &[Concept], rules: &[Rule]) -> Vec<u8> {
    let after_rules = apply_rules(data, rules);
    
    // Concepts are more about interpretation than transformation
    // For now, just return the rule-transformed data
    after_rules
}

fn rules_description_length(rules: &[Rule]) -> f64 {
    let total_bytes: usize = rules.iter()
        .map(|r| r.pattern.len() + r.replacement.len() + r.id.len())
        .sum();
    total_bytes as f64 * 8.0
}

fn concepts_description_length(concepts: &[Concept]) -> f64 {
    let total_bytes: usize = concepts.iter()
        .map(|c| {
            c.name.len() 
            + c.patterns.iter().map(|p| p.len()).sum::<usize>()
            + c.relations.iter().map(|(a, b)| a.len() + b.len()).sum::<usize>()
        })
        .sum();
    total_bytes as f64 * 8.0
}

/// Compute κ_Px index (competence index from families)
/// κ_Px = Σ v_i · I[Solve(τ_i)] / Σ v_i
pub fn compute_kappa_px(results: &[TaskResult]) -> f64 {
    if results.is_empty() {
        return 0.0;
    }
    
    let total_weight: f64 = results.iter().map(|r| r.weight).sum();
    if total_weight == 0.0 {
        return 0.0;
    }
    
    let weighted_success: f64 = results.iter()
        .filter(|r| r.solved)
        .map(|r| r.weight)
        .sum();
    
    weighted_success / total_weight
}

/// Task result for κ_Px computation
#[derive(Debug, Clone)]
pub struct TaskResult {
    pub task_id: String,
    pub family: TaskFamily,
    pub solved: bool,
    pub weight: f64,
    pub proof_level: ProofLevel,
}

/// Task family (canonical Px families)
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TaskFamily {
    /// F_alg: Symbolic algebra
    Algebra,
    /// F_log: Propositional/SMT logic
    Logic,
    /// F_num: Integer/rational arithmetic
    Numeric,
    /// F_seq: Recurrences with closed form
    Sequence,
    /// F_geom: Geometric invariants
    Geometry,
    /// F_ctrl: Optimal plan synthesis
    Control,
}

/// Proof level (P0-P4)
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum ProofLevel {
    P0, // Formal proof
    P1, // Verified
    P2, // Tested
    P3, // Plausible
    P4, // Unknown
}

/// Compute efficiency of transduction
/// η_Px = κ_Px^realized / κ_Px^intrinsic
pub fn compute_eta_px(realized: f64, intrinsic: f64) -> f64 {
    if intrinsic <= 0.0 {
        return 0.0;
    }
    (realized / intrinsic).clamp(0.0, 1.0)
}

/// Meta-cognitive competence (new formula)
/// K_meta(R) = (coherence(R) · efficiency(R) · self_awareness(R) · calibration(R))^(1/4)
pub fn compute_k_meta(reasoning: &ReasoningTrace) -> f64 {
    let coherence = reasoning.coherence();
    let efficiency = reasoning.efficiency();
    let self_awareness = reasoning.self_awareness();
    let calibration = reasoning.calibration();
    
    let product = coherence * efficiency * self_awareness * calibration;
    
    if product <= 0.0 {
        return 0.0;
    }
    
    product.powf(0.25)
}

/// Reasoning trace for meta-cognitive analysis
#[derive(Debug, Clone)]
pub struct ReasoningTrace {
    pub steps: Vec<ReasoningStep>,
    pub confidence: f64,
    pub actual_correctness: Option<bool>,
}

#[derive(Debug, Clone)]
pub struct ReasoningStep {
    pub description: String,
    pub justification: String,
    pub confidence: f64,
}

impl ReasoningTrace {
    pub fn coherence(&self) -> f64 {
        if self.steps.len() < 2 {
            return 1.0;
        }
        
        // Check logical consistency between steps
        // Simplified: use confidence as proxy
        let avg_confidence: f64 = self.steps.iter().map(|s| s.confidence).sum::<f64>() 
            / self.steps.len() as f64;
        
        avg_confidence
    }
    
    pub fn efficiency(&self) -> f64 {
        // Fewer steps for same result = more efficient
        let ideal_steps = 3.0;
        (ideal_steps / self.steps.len().max(1) as f64).min(1.0)
    }
    
    pub fn self_awareness(&self) -> f64 {
        // Presence of metacognitive statements
        let meta_count = self.steps.iter()
            .filter(|s| s.justification.contains("because") || s.justification.contains("therefore"))
            .count();
        
        (meta_count as f64 / self.steps.len().max(1) as f64).min(1.0)
    }
    
    pub fn calibration(&self) -> f64 {
        // How well confidence matches actual correctness
        match self.actual_correctness {
            Some(correct) => {
                if correct {
                    self.confidence
                } else {
                    1.0 - self.confidence
                }
            }
            None => 0.5, // Unknown
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_compute_k_obj() {
        let config = PxConfig::default();
        
        let structured = b"Hello Hello Hello World World World";
        let random: Vec<u8> = (0..100).map(|i| (i * 17 + 31) as u8).collect();
        
        let k_structured = compute_k_obj(structured, &config);
        let k_random = compute_k_obj(&random, &config);
        
        assert!(k_structured > 0.0);
        assert!(k_random > 0.0);
    }
    
    #[test]
    fn test_competence_triplet() {
        let triplet = CompetenceTriplet {
            k_obj: 0.8,
            k_semi: 0.7,
            k_subj: 0.6,
        };
        
        assert!(triplet.consistency() > 0.5);
        assert!(triplet.min() == 0.6);
    }
    
    #[test]
    fn test_kappa_px() {
        let results = vec![
            TaskResult {
                task_id: "1".into(),
                family: TaskFamily::Algebra,
                solved: true,
                weight: 1.0,
                proof_level: ProofLevel::P0,
            },
            TaskResult {
                task_id: "2".into(),
                family: TaskFamily::Logic,
                solved: false,
                weight: 1.0,
                proof_level: ProofLevel::P4,
            },
        ];
        
        let kappa = compute_kappa_px(&results);
        assert_eq!(kappa, 0.5);
    }
}
