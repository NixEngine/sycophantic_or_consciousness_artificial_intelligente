//! # FFI Module
//! 
//! C-compatible Foreign Function Interface for the Px/Nix Engine.
//! Allows integration with C, C++, Python, and other languages.

#![cfg(feature = "ffi")]

use crate::{PxConfig, PxEngine, PxError, DeviceType};
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_void, c_int, c_double, c_ulong};
use std::ptr;
use std::slice;

/// Opaque handle to Px/Nix Engine
pub type PxHandle = *mut c_void;

/// Error codes
pub const PX_OK: c_int = 0;
pub const PX_ERROR_NULL_POINTER: c_int = -1;
pub const PX_ERROR_INVALID_INPUT: c_int = -2;
pub const PX_ERROR_PROCESSING_FAILED: c_int = -3;
pub const PX_ERROR_NOT_INITIALIZED: c_int = -4;
pub const PX_ERROR_BUDGET_EXHAUSTED: c_int = -5;
pub const PX_ERROR_ETHOS_VIOLATION: c_int = -6;

/// Configuration struct for FFI
#[repr(C)]
pub struct PxConfigFFI {
    pub lambda: c_double,
    pub tau_noise: c_double,
    pub tau_j: c_double,
    pub tau_k: c_double,
    pub tau_memory: c_double,
    pub tau_action: c_double,
    pub hysteresis_band: c_double,
    pub deep_target_max: c_double,
    pub p95_target_ms: c_ulong,
    pub ewma_alpha: c_double,
    pub budget_per_window: c_ulong,
    pub window_ms: c_ulong,
    pub enable_simd: c_int,
    pub enable_parallel: c_int,
    pub max_concurrent: c_int,
    pub device_type: c_int, // 0=Mobile, 1=Desktop, 2=Server, 3=Embedded
}

impl Default for PxConfigFFI {
    fn default() -> Self {
        let config = PxConfig::default();
        Self {
            lambda: config.lambda,
            tau_noise: config.tau_noise,
            tau_j: config.tau_j,
            tau_k: config.tau_k,
            tau_memory: config.tau_memory,
            tau_action: config.tau_action,
            hysteresis_band: config.hysteresis_band,
            deep_target_max: config.deep_target_max,
            p95_target_ms: config.p95_target_ms,
            ewma_alpha: config.ewma_alpha,
            budget_per_window: config.budget_per_window,
            window_ms: config.window_ms,
            enable_simd: config.enable_simd as c_int,
            enable_parallel: config.enable_parallel as c_int,
            max_concurrent: config.max_concurrent as c_int,
            device_type: match config.device_type {
                DeviceType::Mobile => 0,
                DeviceType::Desktop => 1,
                DeviceType::Server => 2,
                DeviceType::Embedded => 3,
            },
        }
    }
}

impl From<PxConfigFFI> for PxConfig {
    fn from(ffi: PxConfigFFI) -> Self {
        PxConfig {
            lambda: ffi.lambda,
            tau_noise: ffi.tau_noise,
            tau_j: ffi.tau_j,
            tau_k: ffi.tau_k,
            tau_memory: ffi.tau_memory,
            tau_action: ffi.tau_action,
            hysteresis_band: ffi.hysteresis_band,
            deep_target_max: ffi.deep_target_max,
            p95_target_ms: ffi.p95_target_ms,
            ewma_alpha: ffi.ewma_alpha,
            budget_per_window: ffi.budget_per_window,
            window_ms: ffi.window_ms,
            enable_simd: ffi.enable_simd != 0,
            enable_parallel: ffi.enable_parallel != 0,
            max_concurrent: ffi.max_concurrent as usize,
            device_type: match ffi.device_type {
                0 => DeviceType::Mobile,
                1 => DeviceType::Desktop,
                2 => DeviceType::Server,
                _ => DeviceType::Embedded,
            },
        }
    }
}

/// Result struct for FFI
#[repr(C)]
pub struct PxResultFFI {
    /// J-score (lower is better)
    pub j_score: c_double,
    /// Objective competence [0,1]
    pub k_obj: c_double,
    /// Semi-objective competence [0,1]
    pub k_semi: c_double,
    /// Subjective competence [0,1]
    pub k_subj: c_double,
    /// Latency in microseconds
    pub latency_us: c_ulong,
    /// Route taken (0=FAST, 1=DEEP)
    pub route: c_int,
    /// Ethos status (0=OK, 1=Warning, 2=AskUser, 3=Refuse)
    pub ethos_status: c_int,
    /// Error code (0 if success)
    pub error_code: c_int,
}

impl Default for PxResultFFI {
    fn default() -> Self {
        Self {
            j_score: 0.0,
            k_obj: 0.0,
            k_semi: 0.0,
            k_subj: 0.0,
            latency_us: 0,
            route: 0,
            ethos_status: 0,
            error_code: PX_OK,
        }
    }
}

/// State struct for FFI
#[repr(C)]
pub struct PxStateFFI {
    /// Performance hormone [0,1]
    pub h_perf: c_double,
    /// Quality hormone [0,1]
    pub h_quality: c_double,
    /// Safety hormone [0,1]
    pub h_safety: c_double,
    /// DEEP route rate [0,1]
    pub deep_rate: c_double,
    /// Current SBE budget
    pub sbe_budget: c_ulong,
    /// Memory size (items)
    pub memory_size: c_int,
    /// Council size (avatars)
    pub council_size: c_int,
}

// ============================================================================
// Lifecycle Functions
// ============================================================================

/// Create a new Px/Nix Engine with default configuration
/// 
/// Returns: Handle to engine, or NULL on failure
#[no_mangle]
pub extern "C" fn px_engine_new() -> PxHandle {
    let config = PxConfig::default();
    let engine = Box::new(PxEngine::with_config(config));
    Box::into_raw(engine) as PxHandle
}

/// Create a new Px/Nix Engine with custom configuration
/// 
/// # Arguments
/// * `config` - Pointer to configuration struct
/// 
/// Returns: Handle to engine, or NULL on failure
#[no_mangle]
pub extern "C" fn px_engine_new_with_config(config: *const PxConfigFFI) -> PxHandle {
    if config.is_null() {
        return ptr::null_mut();
    }
    
    let config_ffi = unsafe { &*config };
    let config: PxConfig = (*config_ffi).into();
    let engine = Box::new(PxEngine::with_config(config));
    Box::into_raw(engine) as PxHandle
}

/// Destroy engine and free resources
/// 
/// # Arguments
/// * `handle` - Engine handle from px_engine_new
#[no_mangle]
pub extern "C" fn px_engine_free(handle: PxHandle) {
    if !handle.is_null() {
        unsafe {
            let _ = Box::from_raw(handle as *mut PxEngine);
        }
    }
}

// ============================================================================
// Processing Functions
// ============================================================================

/// Process input data
/// 
/// # Arguments
/// * `handle` - Engine handle
/// * `data` - Input data pointer
/// * `len` - Input data length
/// * `result` - Pointer to result struct to fill
/// 
/// Returns: Error code (PX_OK on success)
#[no_mangle]
pub extern "C" fn px_engine_process(
    handle: PxHandle,
    data: *const u8,
    len: usize,
    result: *mut PxResultFFI,
) -> c_int {
    if handle.is_null() {
        return PX_ERROR_NULL_POINTER;
    }
    if data.is_null() || len == 0 {
        return PX_ERROR_INVALID_INPUT;
    }
    if result.is_null() {
        return PX_ERROR_NULL_POINTER;
    }
    
    let engine = unsafe { &mut *(handle as *mut PxEngine) };
    let input = unsafe { slice::from_raw_parts(data, len) };
    
    match engine.process(input) {
        Ok(res) => {
            let result = unsafe { &mut *result };
            result.j_score = res.j_score;
            result.k_obj = res.competence.k_obj;
            result.k_semi = res.competence.k_semi;
            result.k_subj = res.competence.k_subj;
            result.latency_us = res.latency_us;
            result.route = match res.route {
                crate::router::Route::Fast => 0,
                crate::router::Route::Deep => 1,
            };
            result.ethos_status = match res.ethos_status {
                crate::ethos::EthosStatus::Ok => 0,
                crate::ethos::EthosStatus::Warning(_) => 1,
                crate::ethos::EthosStatus::AskUser(_) => 2,
                crate::ethos::EthosStatus::Refuse(_) => 3,
            };
            result.error_code = PX_OK;
            PX_OK
        }
        Err(e) => {
            let result = unsafe { &mut *result };
            result.error_code = match e {
                PxError::BudgetExhausted => PX_ERROR_BUDGET_EXHAUSTED,
                PxError::EthosViolation(_) => PX_ERROR_ETHOS_VIOLATION,
                PxError::InvalidInput(_) => PX_ERROR_INVALID_INPUT,
                _ => PX_ERROR_PROCESSING_FAILED,
            };
            result.error_code
        }
    }
}

/// Process input and return only J-score (fast path)
/// 
/// # Arguments
/// * `handle` - Engine handle
/// * `data` - Input data pointer
/// * `len` - Input data length
/// 
/// Returns: J-score, or -1.0 on error
#[no_mangle]
pub extern "C" fn px_engine_quick_score(
    handle: PxHandle,
    data: *const u8,
    len: usize,
) -> c_double {
    if handle.is_null() || data.is_null() || len == 0 {
        return -1.0;
    }
    
    let engine = unsafe { &mut *(handle as *mut PxEngine) };
    let input = unsafe { slice::from_raw_parts(data, len) };
    
    match engine.process(input) {
        Ok(result) => result.j_score,
        Err(_) => -1.0,
    }
}

// ============================================================================
// State Functions
// ============================================================================

/// Get current engine state
/// 
/// # Arguments
/// * `handle` - Engine handle
/// * `state` - Pointer to state struct to fill
/// 
/// Returns: Error code (PX_OK on success)
#[no_mangle]
pub extern "C" fn px_engine_get_state(
    handle: PxHandle,
    state: *mut PxStateFFI,
) -> c_int {
    if handle.is_null() || state.is_null() {
        return PX_ERROR_NULL_POINTER;
    }
    
    let engine = unsafe { &*(handle as *mut PxEngine) };
    let engine_state = engine.state();
    
    let state = unsafe { &mut *state };
    state.h_perf = engine_state.hormones.h_perf;
    state.h_quality = engine_state.hormones.h_quality;
    state.h_safety = engine_state.hormones.h_safety;
    state.deep_rate = engine_state.deep_rate;
    state.sbe_budget = engine_state.sbe_budget;
    state.memory_size = engine_state.memory_size as c_int;
    state.council_size = engine_state.council_size as c_int;
    
    PX_OK
}

/// Trigger homeostasis tick
/// 
/// # Arguments
/// * `handle` - Engine handle
/// 
/// Returns: Error code (PX_OK on success)
#[no_mangle]
pub extern "C" fn px_engine_tick(handle: PxHandle) -> c_int {
    if handle.is_null() {
        return PX_ERROR_NULL_POINTER;
    }
    
    let engine = unsafe { &mut *(handle as *mut PxEngine) };
    engine.tick();
    
    PX_OK
}

// ============================================================================
// Noise Analysis Functions
// ============================================================================

/// Quick noise check (returns true if likely noise)
/// 
/// # Arguments
/// * `data` - Input data pointer
/// * `len` - Input data length
/// 
/// Returns: 1 if noise, 0 if signal, -1 on error
#[no_mangle]
pub extern "C" fn px_is_noise(
    data: *const u8,
    len: usize,
) -> c_int {
    if data.is_null() || len == 0 {
        return -1;
    }
    
    let input = unsafe { slice::from_raw_parts(data, len) };
    let config = PxConfig::default();
    let result = crate::noise::analyze_noise(input, &config);
    
    if result.score > config.tau_noise {
        1
    } else {
        0
    }
}

/// Get noise score for data
/// 
/// # Arguments
/// * `data` - Input data pointer
/// * `len` - Input data length
/// 
/// Returns: Noise score [0,1], or -1.0 on error
#[no_mangle]
pub extern "C" fn px_noise_score(
    data: *const u8,
    len: usize,
) -> c_double {
    if data.is_null() || len == 0 {
        return -1.0;
    }
    
    let input = unsafe { slice::from_raw_parts(data, len) };
    let config = PxConfig::default();
    let result = crate::noise::analyze_noise(input, &config);
    
    result.score
}

// ============================================================================
// MDL Functions
// ============================================================================

/// Compute description length of data
/// 
/// # Arguments
/// * `data` - Input data pointer
/// * `len` - Input data length
/// 
/// Returns: Description length in bits, or -1.0 on error
#[no_mangle]
pub extern "C" fn px_description_length(
    data: *const u8,
    len: usize,
) -> c_double {
    if data.is_null() || len == 0 {
        return -1.0;
    }
    
    let input = unsafe { slice::from_raw_parts(data, len) };
    crate::mdl::description_length(input)
}

/// Compute compressibility of data
/// 
/// # Arguments
/// * `data` - Input data pointer
/// * `len` - Input data length
/// 
/// Returns: Compressibility [0,1], or -1.0 on error
#[no_mangle]
pub extern "C" fn px_compressibility(
    data: *const u8,
    len: usize,
) -> c_double {
    if data.is_null() || len == 0 {
        return -1.0;
    }
    
    let input = unsafe { slice::from_raw_parts(data, len) };
    crate::mdl::compute_compressibility(input)
}

// ============================================================================
// Competence Functions
// ============================================================================

/// Compute objective competence
/// 
/// # Arguments
/// * `data` - Input data pointer
/// * `len` - Input data length
/// 
/// Returns: K_obj [0,1], or -1.0 on error
#[no_mangle]
pub extern "C" fn px_compute_k_obj(
    data: *const u8,
    len: usize,
) -> c_double {
    if data.is_null() || len == 0 {
        return -1.0;
    }
    
    let input = unsafe { slice::from_raw_parts(data, len) };
    let config = PxConfig::default();
    crate::competence::compute_k_obj(input, &config)
}

// ============================================================================
// Utility Functions
// ============================================================================

/// Get default configuration
/// 
/// # Arguments
/// * `config` - Pointer to config struct to fill
#[no_mangle]
pub extern "C" fn px_get_default_config(config: *mut PxConfigFFI) {
    if !config.is_null() {
        unsafe {
            *config = PxConfigFFI::default();
        }
    }
}

/// Get version string
/// 
/// Returns: Pointer to null-terminated version string (do not free)
#[no_mangle]
pub extern "C" fn px_version() -> *const c_char {
    static VERSION: &str = "1.0.0\0";
    VERSION.as_ptr() as *const c_char
}

/// Get error message for error code
/// 
/// # Arguments
/// * `code` - Error code
/// 
/// Returns: Pointer to null-terminated error message (do not free)
#[no_mangle]
pub extern "C" fn px_error_message(code: c_int) -> *const c_char {
    static MSG_OK: &str = "Success\0";
    static MSG_NULL: &str = "Null pointer\0";
    static MSG_INVALID: &str = "Invalid input\0";
    static MSG_FAILED: &str = "Processing failed\0";
    static MSG_NOT_INIT: &str = "Not initialized\0";
    static MSG_BUDGET: &str = "Budget exhausted\0";
    static MSG_ETHOS: &str = "Ethos violation\0";
    static MSG_UNKNOWN: &str = "Unknown error\0";
    
    let msg = match code {
        PX_OK => MSG_OK,
        PX_ERROR_NULL_POINTER => MSG_NULL,
        PX_ERROR_INVALID_INPUT => MSG_INVALID,
        PX_ERROR_PROCESSING_FAILED => MSG_FAILED,
        PX_ERROR_NOT_INITIALIZED => MSG_NOT_INIT,
        PX_ERROR_BUDGET_EXHAUSTED => MSG_BUDGET,
        PX_ERROR_ETHOS_VIOLATION => MSG_ETHOS,
        _ => MSG_UNKNOWN,
    };
    
    msg.as_ptr() as *const c_char
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_ffi_lifecycle() {
        let handle = px_engine_new();
        assert!(!handle.is_null());
        px_engine_free(handle);
    }
    
    #[test]
    fn test_ffi_process() {
        let handle = px_engine_new();
        assert!(!handle.is_null());
        
        let data = b"Hello, World!";
        let mut result = PxResultFFI::default();
        
        let code = px_engine_process(
            handle,
            data.as_ptr(),
            data.len(),
            &mut result,
        );
        
        assert_eq!(code, PX_OK);
        assert!(result.j_score > 0.0);
        
        px_engine_free(handle);
    }
    
    #[test]
    fn test_ffi_noise_score() {
        let data = b"Hello, World!";
        let score = px_noise_score(data.as_ptr(), data.len());
        assert!(score >= 0.0 && score <= 1.0);
    }
}
