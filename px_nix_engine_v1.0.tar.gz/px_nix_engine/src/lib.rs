//! # Px/Nix Engine
//! 
//! Autonomous AI Engine based on Minimum Description Length (MDL) principles.
//! 
//! ## Core Philosophy
//! 
//! The Px/Nix Engine operates on the fundamental principle that intelligence
//! can be measured and optimized through compression - the ability to find
//! shorter descriptions of data through understanding its structure.
//! 
//! **Central Formula**: `J(Φ) = ℓ(Φ) + res(Φ,D)`
//! 
//! Where:
//! - `J(Φ)` is the total description length
//! - `ℓ(Φ)` is the model complexity
//! - `res(Φ,D)` is the residual (what the model can't explain)
//! 
//! ## Architecture
//! 
//! The engine follows a **Nucleus/Skin** (Núcleo/Pele) architecture:
//! 
//! - **Nucleus (Core)**: Deterministic, trusted processing with formal guarantees
//! - **Skin (Adaptive)**: Adaptive layers including noise detection, routing, and homeostasis
//! 
//! ## Key Components
//! 
//! - **Noise-First Analysis**: Cascade N1-N6 for early detection of uninformative data
//! - **MDL Metrics**: Objective competence measures based on compression
//! - **Homeostasis**: Hormonal control system for autonomous adaptation
//! - **Council**: Multi-avatar voting system for robust decisions
//! - **SBE**: Stochastic Budget Exploration for resource allocation
//! 
//! ## Example
//! 
//! ```rust
//! use px_nix::{PxEngine, PxConfig};
//! 
//! let config = PxConfig::default();
//! let mut engine = PxEngine::with_config(config);
//! 
//! let input = b"Hello, World!";
//! let result = engine.process(input).unwrap();
//! 
//! println!("J-Score: {:.4}", result.j_score);
//! println!("Route: {:?}", result.route);
//! ```

#![warn(missing_docs)]
#![allow(dead_code)]

// ============================================================================
// Module Declarations
// ============================================================================

pub mod noise;
pub mod homeostasis;
pub mod competence;
pub mod router;
pub mod sbe;
pub mod prism;
pub mod dsl;
pub mod synthesis;
pub mod council;
pub mod memory;
pub mod ethos;
pub mod ledger;
pub mod causal;
pub mod utils;

#[cfg(feature = "android")]
pub mod android;

#[cfg(feature = "ffi")]
pub mod ffi;

// ============================================================================
// Re-exports
// ============================================================================

pub use noise::{NoiseResult, NoiseDecision, analyze_noise};
pub use homeostasis::{HomeostasisController, Hormones, OperatingMode, Vitals};
pub use competence::{CompetenceTriplet, compute_k_obj, compute_k_semi, compute_k_subj};
pub use router::{Router, Route};
pub use sbe::SbeController;
pub use prism::{PrismOperator, Band};
pub use council::{Council, CouncilDecision, Vote};
pub use memory::MemoryManager;
pub use ethos::{EthosGate, EthosStatus, EthosVector};
pub use ledger::{Ledger, Event, LedgerEntry};
pub use causal::{CausalGraph, CausalNode, Intervention};
pub use synthesis::Transform;

// ============================================================================
// Core Types
// ============================================================================

use std::time::Instant;
use uuid::Uuid;

/// Main error type for Px/Nix Engine
#[derive(Debug, thiserror::Error)]
pub enum PxError {
    /// MDL computation error
    #[error("MDL error: {0}")]
    MdlError(String),
    
    /// Noise analysis error
    #[error("Noise analysis error: {0}")]
    NoiseError(String),
    
    /// Router error
    #[error("Router error: {0}")]
    RouterError(String),
    
    /// Council error
    #[error("Council error: {0}")]
    CouncilError(String),
    
    /// Memory error
    #[error("Memory error: {0}")]
    MemoryError(String),
    
    /// Ethos violation
    #[error("Ethos violation: {0}")]
    EthosViolation(String),
    
    /// Budget exhausted
    #[error("Budget exhausted")]
    BudgetExhausted,
    
    /// Invalid input
    #[error("Invalid input: {0}")]
    InvalidInput(String),
    
    /// IO error
    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),
    
    /// Serialization error
    #[error("Serialization error: {0}")]
    SerializationError(String),
}

/// Device type for optimization profiles
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DeviceType {
    /// Mobile device (Galaxy S25, etc.)
    Mobile,
    /// Desktop/laptop
    Desktop,
    /// Server/cloud
    Server,
    /// Embedded device
    Embedded,
}

impl Default for DeviceType {
    fn default() -> Self {
        Self::Desktop
    }
}

/// Engine configuration
#[derive(Debug, Clone)]
pub struct PxConfig {
    // MDL parameters
    /// Lambda: balance between model complexity and residual
    pub lambda: f64,
    
    // Thresholds
    /// Noise threshold for FAST/DEEP routing
    pub tau_noise: f64,
    /// J-score improvement threshold for SBE
    pub tau_j: f64,
    /// Competence threshold for promotion
    pub tau_k: f64,
    /// Memory ROI threshold
    pub tau_memory: f64,
    /// Action threshold
    pub tau_action: f64,
    
    // Homeostasis
    /// Hysteresis band for hormone updates
    pub hysteresis_band: f64,
    /// Maximum DEEP route fraction
    pub deep_target_max: f64,
    /// Target p95 latency in milliseconds
    pub p95_target_ms: u64,
    /// EWMA smoothing factor
    pub ewma_alpha: f64,
    
    // Budget
    /// Budget per processing window
    pub budget_per_window: u64,
    /// Window duration in milliseconds
    pub window_ms: u64,
    
    // Performance
    /// Enable SIMD optimizations
    pub enable_simd: bool,
    /// Enable parallel processing
    pub enable_parallel: bool,
    /// Maximum concurrent operations
    pub max_concurrent: usize,
    /// Target device type
    pub device_type: DeviceType,
}

impl Default for PxConfig {
    fn default() -> Self {
        Self {
            // MDL
            lambda: 1e-3,
            
            // Thresholds
            tau_noise: 0.7,
            tau_j: 0.01,
            tau_k: 0.05,
            tau_memory: 0.1,
            tau_action: 0.5,
            
            // Homeostasis
            hysteresis_band: 0.05,
            deep_target_max: 0.3,
            p95_target_ms: 100,
            ewma_alpha: 0.1,
            
            // Budget
            budget_per_window: 1000,
            window_ms: 1000,
            
            // Performance
            enable_simd: true,
            enable_parallel: true,
            max_concurrent: 4,
            device_type: DeviceType::Desktop,
        }
    }
}

impl PxConfig {
    /// Create config optimized for mobile (Galaxy S25)
    pub fn mobile() -> Self {
        Self {
            device_type: DeviceType::Mobile,
            max_concurrent: 4,
            budget_per_window: 500,
            p95_target_ms: 50,
            deep_target_max: 0.2,
            ..Default::default()
        }
    }
    
    /// Create config optimized for server
    pub fn server() -> Self {
        Self {
            device_type: DeviceType::Server,
            max_concurrent: 16,
            budget_per_window: 5000,
            p95_target_ms: 200,
            deep_target_max: 0.5,
            ..Default::default()
        }
    }
}

/// Processing result
#[derive(Debug, Clone)]
pub struct ProcessResult {
    /// Unique trace ID
    pub trace_id: Uuid,
    /// Route taken (FAST or DEEP)
    pub route: Route,
    /// Output data
    pub output: Vec<u8>,
    /// J-score (lower is better)
    pub j_score: f64,
    /// Competence metrics
    pub competence: CompetenceVector,
    /// Latency in microseconds
    pub latency_us: u64,
    /// Ethos validation status
    pub ethos_status: EthosStatus,
}

/// Competence vector
#[derive(Debug, Clone, Default)]
pub struct CompetenceVector {
    /// Objective competence [0,1]
    pub k_obj: f64,
    /// Semi-objective competence [0,1]
    pub k_semi: f64,
    /// Subjective competence [0,1]
    pub k_subj: f64,
}

/// Internal processing result (before ethos gate)
#[derive(Debug, Clone)]
pub struct InternalResult {
    /// Output data
    pub output: Vec<u8>,
    /// J-score
    pub j_score: f64,
    /// Competence metrics
    pub competence: CompetenceVector,
    /// Transform ID used
    pub phi_id: Uuid,
}

/// Engine state for monitoring
#[derive(Debug, Clone)]
pub struct EngineState {
    /// Current hormone levels
    pub hormones: Hormones,
    /// DEEP route rate
    pub deep_rate: f64,
    /// Current SBE budget
    pub sbe_budget: u64,
    /// Memory size
    pub memory_size: usize,
    /// Council size
    pub council_size: usize,
}

// ============================================================================
// MDL Module (inline for simplicity)
// ============================================================================

/// MDL (Minimum Description Length) computations
pub mod mdl {
    use super::*;
    
    /// Compute J-score: J(Φ) = ℓ(Φ) + λ·res(Φ,D)
    pub fn compute_j(data: &[u8], phi: &Transform, lambda: f64) -> f64 {
        let l_phi = phi.description_length();
        let residual = compute_residual(data, phi);
        
        l_phi + lambda * residual
    }
    
    /// Compute J-score with resource bounds
    pub fn compute_j_rb(
        data: &[u8],
        phi: &Transform,
        lambda: f64,
        time_budget_ms: u64,
        _memory_budget: usize,
    ) -> Result<f64, PxError> {
        let start = Instant::now();
        
        let l_phi = phi.description_length();
        
        // Check time budget
        if start.elapsed().as_millis() as u64 > time_budget_ms {
            return Err(PxError::BudgetExhausted);
        }
        
        let residual = compute_residual(data, phi);
        
        Ok(l_phi + lambda * residual)
    }
    
    /// Compute residual: res(Φ,D) = |D - Φ(D)|
    pub fn compute_residual(data: &[u8], phi: &Transform) -> f64 {
        let transformed = phi.apply(data);
        let diff = normalized_delta(data, &transformed);
        diff * data.len() as f64 * 8.0
    }
    
    /// Normalized delta between two byte sequences
    pub fn normalized_delta(a: &[u8], b: &[u8]) -> f64 {
        if a.is_empty() && b.is_empty() {
            return 0.0;
        }
        
        let max_len = a.len().max(b.len());
        let min_len = a.len().min(b.len());
        
        let mut diff = 0usize;
        for i in 0..min_len {
            diff += (a[i] as i32 - b[i] as i32).unsigned_abs() as usize;
        }
        
        // Account for length difference
        diff += (max_len - min_len) * 255;
        
        diff as f64 / (max_len * 255) as f64
    }
    
    /// Compute description length using codec committee
    pub fn description_length(data: &[u8]) -> f64 {
        if data.is_empty() {
            return 0.0;
        }
        
        // Use LZ4 as primary codec
        let compressed = lz4_flex::compress_prepend_size(data);
        let lz4_bits = compressed.len() as f64 * 8.0;
        
        // Use Zstd as secondary
        let zstd_compressed = zstd::encode_all(data, 3).unwrap_or_default();
        let zstd_bits = zstd_compressed.len() as f64 * 8.0;
        
        // Return median (with 2 codecs, this is average)
        (lz4_bits + zstd_bits) / 2.0
    }
    
    /// Compute compressibility: κ(D) = 1 - ℓ(D)/|D|
    pub fn compute_compressibility(data: &[u8]) -> f64 {
        if data.is_empty() {
            return 0.0;
        }
        
        let original_bits = data.len() as f64 * 8.0;
        let compressed_bits = description_length(data);
        
        (1.0 - compressed_bits / original_bits).clamp(0.0, 1.0)
    }
    
    /// Compute intensity of experience (A2)
    pub fn compute_x(data: &[u8], integrated: bool) -> f64 {
        let kappa = compute_compressibility(data);
        let integration_factor = if integrated { 1.0 } else { 0.5 };
        
        kappa * integration_factor
    }
    
    /// Compute contradiction level (A4)
    pub fn compute_contradiction(claims: &[&[u8]]) -> f64 {
        if claims.len() < 2 {
            return 0.0;
        }
        
        let mut total_delta = 0.0;
        let mut count = 0;
        
        for i in 0..claims.len() {
            for j in (i + 1)..claims.len() {
                total_delta += normalized_delta(claims[i], claims[j]);
                count += 1;
            }
        }
        
        if count > 0 {
            total_delta / count as f64
        } else {
            0.0
        }
    }
    
    /// Estimate entropy of data
    pub fn estimate_entropy(data: &[u8]) -> f64 {
        if data.is_empty() {
            return 0.0;
        }
        
        let mut counts = [0u64; 256];
        for &byte in data {
            counts[byte as usize] += 1;
        }
        
        let total = data.len() as f64;
        let mut entropy = 0.0;
        
        for &count in &counts {
            if count > 0 {
                let p = count as f64 / total;
                entropy -= p * p.log2();
            }
        }
        
        entropy / 8.0 // Normalize to [0,1]
    }
    
    /// Compute LZ complexity (normalized)
    pub fn lz_complexity(data: &[u8]) -> f64 {
        if data.is_empty() {
            return 0.0;
        }
        
        // Count LZ77-style phrases
        let mut phrases = 0;
        let mut i = 0;
        
        while i < data.len() {
            let mut best_len = 0;
            
            // Look for matches in previous data
            for j in 0..i {
                let mut len = 0;
                while i + len < data.len() && j + len < i && data[j + len] == data[i + len] {
                    len += 1;
                }
                best_len = best_len.max(len);
            }
            
            phrases += 1;
            i += best_len.max(1);
        }
        
        phrases as f64 / data.len() as f64
    }
}

// ============================================================================
// Main Engine
// ============================================================================

/// The main Px/Nix Engine
pub struct PxEngine {
    config: PxConfig,
    router: Router,
    council: Council,
    homeostasis: HomeostasisController,
    memory: MemoryManager,
    ledger: Ledger,
    sbe: SbeController,
    ethos: EthosGate,
    prism: PrismOperator,
}

impl PxEngine {
    /// Create engine with default configuration
    pub fn new() -> Self {
        Self::with_config(PxConfig::default())
    }
    
    /// Create engine with custom configuration
    pub fn with_config(config: PxConfig) -> Self {
        Self {
            router: Router::new(&config),
            council: Council::new(&config),
            homeostasis: HomeostasisController::new(&config),
            memory: MemoryManager::new(&config),
            ledger: Ledger::new(&config),
            sbe: SbeController::new(&config),
            ethos: EthosGate::new(&config),
            prism: PrismOperator::new(&config),
            config,
        }
    }
    
    /// Process input data through the full pipeline
    pub fn process(&mut self, input: &[u8]) -> Result<ProcessResult, PxError> {
        let start = Instant::now();
        let trace_id = Uuid::new_v4();
        
        // Validate input
        if input.is_empty() {
            return Err(PxError::InvalidInput("Empty input".into()));
        }
        
        // Step 1: Noise-First Analysis
        let noise_result = analyze_noise(input, &self.config);
        
        // Step 2: Routing Decision
        let route = self.router.decide(&noise_result, &self.homeostasis);
        self.router.record_route(route);
        
        // Step 3: Process based on route
        let internal_result = match route {
            Route::Fast => self.process_fast(input)?,
            Route::Deep => self.process_deep(input)?,
        };
        
        // Step 4: Ethos Gate
        let ethos_status = self.ethos.validate(&internal_result)?;
        
        // Step 5: Record metrics
        let latency_us = start.elapsed().as_micros() as u64;
        self.homeostasis.observe(latency_us, matches!(route, Route::Deep));
        
        // Step 6: SBE update
        self.sbe.update(internal_result.j_score, latency_us);
        
        // Step 7: Memory management (for DEEP results)
        if matches!(route, Route::Deep) {
            self.memory.consider_for_storage(&internal_result);
        }
        
        // Log to ledger
        let _ = self.ledger.append_event(ledger::Event::RouteDecision {
            trace_id,
            route,
            noise_score: noise_result.score,
            timestamp: utils::now_iso(),
        });
        
        Ok(ProcessResult {
            trace_id,
            route,
            output: internal_result.output,
            j_score: internal_result.j_score,
            competence: internal_result.competence,
            latency_us,
            ethos_status,
        })
    }
    
    /// FAST path: minimal processing
    fn process_fast(&self, input: &[u8]) -> Result<InternalResult, PxError> {
        // Identity transform - just compute metrics
        let j_score = mdl::description_length(input) * self.config.lambda;
        let k_obj = compute_k_obj(input, &self.config);
        
        Ok(InternalResult {
            output: input.to_vec(),
            j_score,
            competence: CompetenceVector {
                k_obj,
                k_semi: 0.0,
                k_subj: 0.0,
            },
            phi_id: Uuid::nil(),
        })
    }
    
    /// DEEP path: full processing pipeline
    fn process_deep(&mut self, input: &[u8]) -> Result<InternalResult, PxError> {
        // Step 1: Prisma decomposition
        let bands = self.prism.decompose(input);
        
        // Step 2: Find/synthesize best transform
        let phi = self.find_best_transform(input, &bands)?;
        
        // Step 3: Apply transform
        let output = phi.apply(input);
        
        // Step 4: Compute J-score
        let j_score = mdl::compute_j(input, &phi, self.config.lambda);
        
        // Step 5: Compute competence triplet
        let k_obj = compute_k_obj(input, &self.config);
        let k_semi = compute_k_semi(input, &output, &self.config);
        let k_subj = compute_k_subj(input, &output, &self.config);
        
        // Step 6: Council vote
        let decision = self.council.vote(&phi, input, &bands)?;
        
        // Handle council decision
        match decision.outcome {
            council::DecisionOutcome::Approved => {}
            council::DecisionOutcome::Rejected => {
                // Fall back to identity transform
                return self.process_fast(input);
            }
            council::DecisionOutcome::AskUser | council::DecisionOutcome::Inconclusive => {
                // Log for human review
                let _ = self.ledger.append_event(ledger::Event::CouncilDecision {
                    trace_id: Uuid::new_v4(),
                    outcome: format!("{:?}", decision.outcome),
                    votes_for: decision.votes.iter()
                        .filter(|v| matches!(v.decision, council::VoteDecision::Approve))
                        .count() as u32,
                    votes_against: decision.votes.iter()
                        .filter(|v| matches!(v.decision, council::VoteDecision::Reject))
                        .count() as u32,
                    timestamp: utils::now_iso(),
                });
            }
        }
        
        Ok(InternalResult {
            output,
            j_score,
            competence: CompetenceVector { k_obj, k_semi, k_subj },
            phi_id: phi.id(),
        })
    }
    
    /// Find best transform for data
    fn find_best_transform(&self, input: &[u8], bands: &[Band]) -> Result<Transform, PxError> {
        // Check memory for cached transforms
        if let Some(cached) = self.memory.find_similar_transform(input) {
            return Ok(cached);
        }
        
        // Synthesize new transform based on bands
        let transform = synthesis::synthesize_transform(input, bands, &self.config)?;
        
        Ok(transform)
    }
    
    /// Trigger homeostasis tick (call at ~2Hz)
    pub fn tick(&mut self) {
        let controls = self.homeostasis.tick();
        
        // Apply controls
        self.router.set_deep_target(controls.deep_target);
        self.sbe.set_budget_multiplier(controls.budget_multiplier);
        
        // Adjust council size based on performance mode
        match self.homeostasis.state().mode {
            OperatingMode::Emergency | OperatingMode::Degraded => {
                self.council.reduce_size(1);
            }
            _ => {}
        }
    }
    
    /// Get current engine state
    pub fn state(&self) -> EngineState {
        EngineState {
            hormones: self.homeostasis.hormones().clone(),
            deep_rate: self.router.deep_rate(),
            sbe_budget: self.sbe.current_budget(),
            memory_size: self.memory.size(),
            council_size: self.council.size(),
        }
    }
    
    /// Get configuration
    pub fn config(&self) -> &PxConfig {
        &self.config
    }
    
    /// Update configuration
    pub fn update_config(&mut self, config: PxConfig) {
        self.config = config;
    }
}

impl Default for PxEngine {
    fn default() -> Self {
        Self::new()
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_engine_creation() {
        let engine = PxEngine::new();
        assert!(engine.config.lambda > 0.0);
    }
    
    #[test]
    fn test_process_simple() {
        let mut engine = PxEngine::new();
        let input = b"Hello, World!";
        
        let result = engine.process(input).unwrap();
        
        assert!(result.j_score > 0.0);
        assert_eq!(result.output.len(), input.len());
    }
    
    #[test]
    fn test_mdl_compressibility() {
        let repetitive = vec![42u8; 1000];
        let random: Vec<u8> = (0..1000).map(|i| ((i * 17 + 31) ^ (i * 13)) as u8).collect();
        
        let k_rep = mdl::compute_compressibility(&repetitive);
        let k_rand = mdl::compute_compressibility(&random);
        
        // Repetitive data should be more compressible
        assert!(k_rep > k_rand);
    }
    
    #[test]
    fn test_config_profiles() {
        let mobile = PxConfig::mobile();
        let server = PxConfig::server();
        
        assert!(mobile.max_concurrent < server.max_concurrent);
        assert!(mobile.budget_per_window < server.budget_per_window);
    }
}
