//! # Homeostasis Controller
//! 
//! Autonomic regulation system using hormonal control with EWMA + hysteresis.
//! 
//! ## Hormones
//! - H_perf: Performance/stress (responds to latency, queue, CPU)
//! - H_quality: Quality/efficacy (responds to gains, outcomes)
//! - H_safety: Risk/errors (responds to failures, ambiguity)
//! 
//! ## Control Mechanisms
//! - Event-driven sensors (O(1))
//! - EWMA smoothing with hysteresis
//! - Circuit breakers for rapid response
//! - PID controller for steady-state

use crate::{PxConfig, router, sbe, council};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

/// Hormones (scalar control signals)
#[derive(Debug, Clone, Copy, Default)]
pub struct Hormones {
    /// Performance/stress hormone [0,1]
    pub h_perf: f64,
    /// Quality/efficacy hormone [0,1]
    pub h_quality: f64,
    /// Safety/risk hormone [0,1]
    pub h_safety: f64,
}

/// System vital signs
#[derive(Debug, Clone, Default)]
pub struct Vitals {
    /// P50 latency (microseconds)
    pub p50_us: u64,
    /// P95 latency (microseconds)
    pub p95_us: u64,
    /// P99 latency (microseconds)
    pub p99_us: u64,
    /// Queue length
    pub queue_len: u32,
    /// Error count
    pub error_count: u32,
    /// DEEP route percentage
    pub deep_rate: f64,
    /// Ambiguous classification rate
    pub ambiguous_rate: f64,
    /// CPU usage estimate [0,1]
    pub cpu_usage: f64,
    /// Memory usage (bytes)
    pub memory_bytes: u64,
    /// Temperature (optional, for mobile)
    pub temperature: Option<f64>,
    /// Battery level (optional, for mobile)
    pub battery_level: Option<f64>,
}

/// Homeostasis controller state
#[derive(Debug, Clone)]
pub struct HomeostasisState {
    pub hormones: Hormones,
    pub vitals: Vitals,
    pub mode: OperatingMode,
    pub circuit_breaker: CircuitBreakerState,
}

/// Operating mode
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OperatingMode {
    Normal,
    HighPerformance,
    EcoMode,
    Degraded,
    Emergency,
}

/// Circuit breaker state
#[derive(Debug, Clone, Copy)]
pub struct CircuitBreakerState {
    pub is_open: bool,
    pub failure_count: u32,
    pub last_failure: Option<Instant>,
    pub cooldown_until: Option<Instant>,
}

impl Default for CircuitBreakerState {
    fn default() -> Self {
        Self {
            is_open: false,
            failure_count: 0,
            last_failure: None,
            cooldown_until: None,
        }
    }
}

/// Homeostasis controller
pub struct HomeostasisController {
    /// Configuration
    config: PxConfig,
    /// Current hormones
    hormones: Hormones,
    /// System vitals
    vitals: Vitals,
    /// Operating mode
    mode: OperatingMode,
    /// Circuit breaker
    circuit_breaker: CircuitBreakerState,
    /// Latency histogram (HDR-like using atomic counters)
    latency_buckets: Vec<AtomicU64>,
    /// Error counter
    error_counter: AtomicU64,
    /// Request counter
    request_counter: AtomicU64,
    /// DEEP counter
    deep_counter: AtomicU64,
    /// Ambiguous counter
    ambiguous_counter: AtomicU64,
    /// Last tick time
    last_tick: Instant,
    /// PID controller state
    pid: PidController,
    /// Snapshots by context
    snapshots: hashbrown::HashMap<String, Snapshot>,
}

impl HomeostasisController {
    pub fn new(config: &PxConfig) -> Self {
        // Create latency buckets (logarithmic scale)
        let num_buckets = 64;
        let latency_buckets: Vec<AtomicU64> = (0..num_buckets)
            .map(|_| AtomicU64::new(0))
            .collect();
        
        Self {
            config: config.clone(),
            hormones: Hormones::default(),
            vitals: Vitals::default(),
            mode: OperatingMode::Normal,
            circuit_breaker: CircuitBreakerState::default(),
            latency_buckets,
            error_counter: AtomicU64::new(0),
            request_counter: AtomicU64::new(0),
            deep_counter: AtomicU64::new(0),
            ambiguous_counter: AtomicU64::new(0),
            last_tick: Instant::now(),
            pid: PidController::new(config.p95_target_ms as f64, 0.1, 0.01, 0.05),
            snapshots: hashbrown::HashMap::new(),
        }
    }
    
    /// Observe a request completion (O(1))
    pub fn observe(&mut self, latency_us: u64, route: &router::Route, result: &crate::InternalResult) {
        // Update latency histogram
        let bucket = latency_to_bucket(latency_us);
        if bucket < self.latency_buckets.len() {
            self.latency_buckets[bucket].fetch_add(1, Ordering::Relaxed);
        }
        
        // Update counters
        self.request_counter.fetch_add(1, Ordering::Relaxed);
        
        if matches!(route, router::Route::Deep) {
            self.deep_counter.fetch_add(1, Ordering::Relaxed);
        }
    }
    
    /// Record an error
    pub fn record_error(&mut self) {
        self.error_counter.fetch_add(1, Ordering::Relaxed);
        self.circuit_breaker.failure_count += 1;
        self.circuit_breaker.last_failure = Some(Instant::now());
        
        // Check circuit breaker threshold
        if self.circuit_breaker.failure_count >= 5 {
            self.trip_circuit_breaker();
        }
    }
    
    /// Record ambiguous classification
    pub fn record_ambiguous(&mut self) {
        self.ambiguous_counter.fetch_add(1, Ordering::Relaxed);
    }
    
    /// Periodic tick (~2Hz) - compute hormones and adjust knobs
    pub fn tick(
        &mut self, 
        router: &mut router::Router, 
        sbe: &mut sbe::SbeController,
        council: &mut council::Council,
    ) {
        let now = Instant::now();
        let elapsed = now.duration_since(self.last_tick);
        self.last_tick = now;
        
        // Update vitals
        self.update_vitals();
        
        // Update hormones (EWMA + hysteresis)
        self.update_hormones();
        
        // Check circuit breaker
        self.check_circuit_breaker();
        
        // Determine operating mode
        self.update_mode();
        
        // Apply control actions
        self.apply_controls(router, sbe, council);
        
        // Reset counters for next window
        self.reset_counters();
    }
    
    fn update_vitals(&mut self) {
        let total = self.request_counter.load(Ordering::Relaxed);
        let deep = self.deep_counter.load(Ordering::Relaxed);
        let errors = self.error_counter.load(Ordering::Relaxed);
        let ambiguous = self.ambiguous_counter.load(Ordering::Relaxed);
        
        // Compute percentiles from histogram
        let (p50, p95, p99) = self.compute_percentiles();
        
        self.vitals = Vitals {
            p50_us: p50,
            p95_us: p95,
            p99_us: p99,
            queue_len: 0, // TODO: integrate with actual queue
            error_count: errors as u32,
            deep_rate: if total > 0 { deep as f64 / total as f64 } else { 0.0 },
            ambiguous_rate: if total > 0 { ambiguous as f64 / total as f64 } else { 0.0 },
            cpu_usage: estimate_cpu_usage(),
            memory_bytes: estimate_memory_usage(),
            temperature: get_temperature(),
            battery_level: get_battery_level(),
        };
    }
    
    fn compute_percentiles(&self) -> (u64, u64, u64) {
        let mut total: u64 = 0;
        let mut cumulative = Vec::with_capacity(self.latency_buckets.len());
        
        for bucket in &self.latency_buckets {
            total += bucket.load(Ordering::Relaxed);
            cumulative.push(total);
        }
        
        if total == 0 {
            return (0, 0, 0);
        }
        
        let p50_target = total / 2;
        let p95_target = total * 95 / 100;
        let p99_target = total * 99 / 100;
        
        let mut p50 = 0;
        let mut p95 = 0;
        let mut p99 = 0;
        
        for (i, &cum) in cumulative.iter().enumerate() {
            if p50 == 0 && cum >= p50_target {
                p50 = bucket_to_latency(i);
            }
            if p95 == 0 && cum >= p95_target {
                p95 = bucket_to_latency(i);
            }
            if p99 == 0 && cum >= p99_target {
                p99 = bucket_to_latency(i);
            }
        }
        
        (p50, p95, p99)
    }
    
    fn update_hormones(&mut self) {
        let alpha = self.config.ewma_alpha;
        
        // H_perf: stress from latency, queue, CPU
        let p95_stress = normalize_latency(self.vitals.p95_us, self.config.p95_target_ms * 1000);
        let queue_stress = normalize_queue(self.vitals.queue_len, 100);
        let cpu_stress = self.vitals.cpu_usage;
        let perf_stress = (p95_stress + queue_stress + cpu_stress) / 3.0;
        
        // H_quality: inverse of error rate, plus gain metrics
        let error_rate = self.vitals.error_count as f64 / 
            self.request_counter.load(Ordering::Relaxed).max(1) as f64;
        let quality = 1.0 - error_rate.min(1.0);
        
        // H_safety: errors + ambiguous + circuit breaker
        let safety_concern = error_rate + self.vitals.ambiguous_rate 
            + if self.circuit_breaker.is_open { 0.5 } else { 0.0 };
        
        // EWMA with hysteresis
        self.hormones.h_perf = ewma_with_hysteresis(
            self.hormones.h_perf, 
            perf_stress, 
            alpha, 
            self.config.hysteresis_band
        );
        
        self.hormones.h_quality = ewma_with_hysteresis(
            self.hormones.h_quality, 
            quality, 
            alpha, 
            self.config.hysteresis_band
        );
        
        self.hormones.h_safety = ewma_with_hysteresis(
            self.hormones.h_safety, 
            safety_concern.min(1.0), 
            alpha, 
            self.config.hysteresis_band
        );
    }
    
    fn update_mode(&mut self) {
        // Determine operating mode based on hormones and environmental factors
        
        if self.circuit_breaker.is_open {
            self.mode = OperatingMode::Emergency;
            return;
        }
        
        // Check battery/temperature for mobile
        if let Some(battery) = self.vitals.battery_level {
            if battery < 0.15 {
                self.mode = OperatingMode::EcoMode;
                return;
            }
        }
        
        if let Some(temp) = self.vitals.temperature {
            if temp > 40.0 {
                self.mode = OperatingMode::EcoMode;
                return;
            }
        }
        
        // Hormone-based mode selection
        if self.hormones.h_safety > 0.7 {
            self.mode = OperatingMode::Degraded;
        } else if self.hormones.h_perf > 0.7 {
            self.mode = OperatingMode::HighPerformance;
        } else if self.hormones.h_perf < 0.3 && self.hormones.h_quality > 0.8 {
            self.mode = OperatingMode::Normal;
        } else {
            // Keep current mode (hysteresis)
        }
    }
    
    fn apply_controls(
        &mut self, 
        router: &mut router::Router, 
        sbe: &mut sbe::SbeController,
        council: &mut council::Council,
    ) {
        match self.mode {
            OperatingMode::Normal => {
                // Standard operation
                router.set_deep_target(self.config.deep_target_max);
                sbe.set_budget_multiplier(1.0);
            }
            OperatingMode::HighPerformance => {
                // Reduce DEEP, increase speed
                router.set_deep_target(self.config.deep_target_max * 0.5);
                sbe.set_budget_multiplier(0.7);
                council.reduce_size(1);
            }
            OperatingMode::EcoMode => {
                // Minimize compute
                router.set_deep_target(self.config.deep_target_max * 0.2);
                sbe.set_budget_multiplier(0.3);
                council.reduce_size(2);
            }
            OperatingMode::Degraded => {
                // Conservative operation
                router.set_deep_target(self.config.deep_target_max * 0.3);
                sbe.set_budget_multiplier(0.5);
            }
            OperatingMode::Emergency => {
                // Minimal operation, circuit breaker active
                router.force_fast_only();
                sbe.set_budget_multiplier(0.1);
            }
        }
        
        // PID control for P95 latency
        let p95_error = self.vitals.p95_us as f64 / 1000.0 - self.config.p95_target_ms as f64;
        let pid_output = self.pid.update(p95_error);
        
        // Apply PID output to DEEP target
        let adjusted_deep = (router.deep_target() - pid_output * 0.01).clamp(0.05, self.config.deep_target_max);
        router.set_deep_target(adjusted_deep);
    }
    
    fn trip_circuit_breaker(&mut self) {
        self.circuit_breaker.is_open = true;
        self.circuit_breaker.cooldown_until = Some(Instant::now() + Duration::from_secs(30));
        self.mode = OperatingMode::Emergency;
    }
    
    fn check_circuit_breaker(&mut self) {
        if self.circuit_breaker.is_open {
            if let Some(cooldown) = self.circuit_breaker.cooldown_until {
                if Instant::now() >= cooldown {
                    // Try to close circuit breaker
                    self.circuit_breaker.is_open = false;
                    self.circuit_breaker.failure_count = 0;
                    self.circuit_breaker.cooldown_until = None;
                }
            }
        } else {
            // Decay failure count over time
            if let Some(last) = self.circuit_breaker.last_failure {
                if last.elapsed() > Duration::from_secs(60) {
                    self.circuit_breaker.failure_count = self.circuit_breaker.failure_count.saturating_sub(1);
                }
            }
        }
    }
    
    fn reset_counters(&mut self) {
        // Reset per-window counters
        for bucket in &self.latency_buckets {
            bucket.store(0, Ordering::Relaxed);
        }
        self.error_counter.store(0, Ordering::Relaxed);
        self.request_counter.store(0, Ordering::Relaxed);
        self.deep_counter.store(0, Ordering::Relaxed);
        self.ambiguous_counter.store(0, Ordering::Relaxed);
    }
    
    /// Get current state
    pub fn state(&self) -> HomeostasisState {
        HomeostasisState {
            hormones: self.hormones,
            vitals: self.vitals.clone(),
            mode: self.mode,
            circuit_breaker: self.circuit_breaker,
        }
    }
    
    /// Get current hormones
    pub fn hormones(&self) -> Hormones {
        self.hormones
    }
    
    /// Create snapshot for context
    pub fn create_snapshot(&mut self, context: &str) -> Snapshot {
        let snap = Snapshot {
            hormones: self.hormones,
            mode: self.mode,
            timestamp: Instant::now(),
        };
        self.snapshots.insert(context.to_string(), snap.clone());
        snap
    }
    
    /// Restore from snapshot
    pub fn restore_snapshot(&mut self, context: &str) -> Option<()> {
        let snap = self.snapshots.get(context)?;
        self.hormones = snap.hormones;
        self.mode = snap.mode;
        Some(())
    }
}

/// Snapshot for rollback
#[derive(Debug, Clone)]
pub struct Snapshot {
    pub hormones: Hormones,
    pub mode: OperatingMode,
    pub timestamp: Instant,
}

/// PID Controller
struct PidController {
    setpoint: f64,
    kp: f64,
    ki: f64,
    kd: f64,
    integral: f64,
    prev_error: f64,
}

impl PidController {
    fn new(setpoint: f64, kp: f64, ki: f64, kd: f64) -> Self {
        Self {
            setpoint,
            kp,
            ki,
            kd,
            integral: 0.0,
            prev_error: 0.0,
        }
    }
    
    fn update(&mut self, error: f64) -> f64 {
        self.integral += error;
        self.integral = self.integral.clamp(-100.0, 100.0); // Anti-windup
        
        let derivative = error - self.prev_error;
        self.prev_error = error;
        
        self.kp * error + self.ki * self.integral + self.kd * derivative
    }
}

// Helper functions

fn latency_to_bucket(latency_us: u64) -> usize {
    // Logarithmic bucketing
    if latency_us == 0 {
        return 0;
    }
    let log = (latency_us as f64).log2().floor() as usize;
    log.min(63)
}

fn bucket_to_latency(bucket: usize) -> u64 {
    2u64.pow(bucket as u32)
}

fn ewma_with_hysteresis(current: f64, new: f64, alpha: f64, band: f64) -> f64 {
    let raw = alpha * new + (1.0 - alpha) * current;
    
    // Apply hysteresis
    if (raw - current).abs() < band {
        current // Don't change if within band
    } else {
        raw
    }
}

fn normalize_latency(actual_us: u64, target_us: u64) -> f64 {
    if target_us == 0 {
        return 0.0;
    }
    (actual_us as f64 / target_us as f64).min(2.0) / 2.0
}

fn normalize_queue(actual: u32, max: u32) -> f64 {
    if max == 0 {
        return 0.0;
    }
    (actual as f64 / max as f64).min(1.0)
}

fn estimate_cpu_usage() -> f64 {
    // Platform-specific implementation
    #[cfg(target_os = "linux")]
    {
        // Read from /proc/stat
        0.5 // Placeholder
    }
    #[cfg(not(target_os = "linux"))]
    {
        0.5 // Placeholder
    }
}

fn estimate_memory_usage() -> u64 {
    // Platform-specific implementation
    #[cfg(target_os = "linux")]
    {
        // Read from /proc/self/status
        0 // Placeholder
    }
    #[cfg(not(target_os = "linux"))]
    {
        0 // Placeholder
    }
}

fn get_temperature() -> Option<f64> {
    // Mobile-specific implementation
    None
}

fn get_battery_level() -> Option<f64> {
    // Mobile-specific implementation
    None
}

/// Lyapunov energy function for stability analysis
pub fn compute_lyapunov_energy(state: &HomeostasisState, config: &PxConfig) -> f64 {
    let p95_excess = (state.vitals.p95_us as f64 / 1000.0 - config.p95_target_ms as f64).max(0.0);
    let deep_excess = (state.vitals.deep_rate - config.deep_target_max).max(0.0);
    let error_term = state.vitals.error_count as f64;
    let ambiguous_term = state.vitals.ambiguous_rate;
    
    // Weighted sum
    0.4 * p95_excess 
    + 0.2 * deep_excess 
    + 0.3 * error_term 
    + 0.1 * ambiguous_term
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_homeostasis_creation() {
        let config = PxConfig::default();
        let controller = HomeostasisController::new(&config);
        
        assert_eq!(controller.hormones.h_perf, 0.0);
        assert_eq!(controller.mode, OperatingMode::Normal);
    }
    
    #[test]
    fn test_ewma_with_hysteresis() {
        let result = ewma_with_hysteresis(0.5, 0.51, 0.2, 0.1);
        assert_eq!(result, 0.5); // Within band, no change
        
        let result = ewma_with_hysteresis(0.5, 0.8, 0.2, 0.1);
        assert!(result > 0.5); // Outside band, changes
    }
    
    #[test]
    fn test_latency_bucketing() {
        assert_eq!(latency_to_bucket(0), 0);
        assert_eq!(latency_to_bucket(1), 0);
        assert_eq!(latency_to_bucket(2), 1);
        assert_eq!(latency_to_bucket(1024), 10);
    }
}
