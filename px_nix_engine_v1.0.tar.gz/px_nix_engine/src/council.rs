//! # Council Module (Sistema de Avatares)
//! 
//! Multi-avatar voting system with credibility-weighted consensus.
//! 
//! ## Avatars
//! - Aegis: Safety guardian
//! - DataQ: Data quality sentinel
//! - PKD: Domain knowledge expert
//! - Perf: Performance optimizer
//! - Risk: Risk assessor

use crate::{PxConfig, PxError, prism, synthesis::Transform};
use hashbrown::HashMap;
use uuid::Uuid;

/// Council for multi-avatar voting
pub struct Council {
    config: PxConfig,
    avatars: Vec<Avatar>,
    decision_history: Vec<CouncilDecision>,
    min_quorum: usize,
    ask_user_threshold: f64,
}

impl Council {
    pub fn new(config: &PxConfig) -> Self {
        let avatars = vec![
            Avatar::new("aegis", AvatarType::Safety, 1.0),
            Avatar::new("dataq", AvatarType::DataQuality, 1.0),
            Avatar::new("pkd", AvatarType::DomainKnowledge, 1.0),
            Avatar::new("perf", AvatarType::Performance, 1.0),
            Avatar::new("risk", AvatarType::Risk, 1.0),
        ];
        
        Self {
            config: config.clone(),
            avatars,
            decision_history: Vec::new(),
            min_quorum: 3,
            ask_user_threshold: 0.1,
        }
    }
    
    /// Vote on a transform
    pub fn vote(
        &mut self,
        phi: &Transform,
        data: &[u8],
        bands: &[prism::Band],
    ) -> Result<CouncilDecision, PxError> {
        let mut votes = Vec::new();
        let mut total_weight = 0.0;
        
        // Collect votes from each avatar
        for avatar in &self.avatars {
            let vote = avatar.evaluate(phi, data, bands, &self.config);
            total_weight += avatar.credibility;
            votes.push((avatar.id.clone(), vote, avatar.credibility));
        }
        
        // Compute weighted decision
        let mut approve_weight = 0.0;
        let mut reject_weight = 0.0;
        let mut abstain_weight = 0.0;
        
        for (_, vote, weight) in &votes {
            match vote.decision {
                VoteDecision::Approve => approve_weight += weight,
                VoteDecision::Reject => reject_weight += weight,
                VoteDecision::Abstain => abstain_weight += weight,
            }
        }
        
        // Determine final decision
        let final_decision = if total_weight == 0.0 {
            FinalDecision::Abstain
        } else {
            let approve_ratio = approve_weight / total_weight;
            let reject_ratio = reject_weight / total_weight;
            let margin = (approve_ratio - reject_ratio).abs();
            
            if margin < self.ask_user_threshold {
                // Too close - ask user
                FinalDecision::AskUser
            } else if approve_ratio > reject_ratio {
                FinalDecision::Approve
            } else {
                FinalDecision::Reject
            }
        };
        
        let decision = CouncilDecision {
            id: Uuid::new_v4(),
            phi_id: phi.id,
            votes: votes.into_iter().map(|(id, v, w)| AvatarVote { avatar_id: id, vote: v, weight: w }).collect(),
            final_decision,
            approve_ratio: approve_weight / total_weight.max(0.001),
            timestamp: crate::utils::now_iso(),
        };
        
        self.decision_history.push(decision.clone());
        
        Ok(decision)
    }
    
    /// Update avatar credibility based on outcome
    pub fn update_credibility(&mut self, decision_id: Uuid, actual_outcome: Outcome) {
        if let Some(decision) = self.decision_history.iter().find(|d| d.id == decision_id) {
            let was_correct = match (&decision.final_decision, &actual_outcome) {
                (FinalDecision::Approve, Outcome::Success) => true,
                (FinalDecision::Reject, Outcome::Failure) => true,
                _ => false,
            };
            
            // Update each avatar's credibility
            for avatar_vote in &decision.votes {
                if let Some(avatar) = self.avatars.iter_mut().find(|a| a.id == avatar_vote.avatar_id) {
                    let vote_correct = match (&avatar_vote.vote.decision, &actual_outcome) {
                        (VoteDecision::Approve, Outcome::Success) => true,
                        (VoteDecision::Reject, Outcome::Failure) => true,
                        _ => false,
                    };
                    
                    // EWMA update
                    let alpha = 0.1;
                    let reward = if vote_correct { 1.0 } else { 0.0 };
                    avatar.credibility = avatar.credibility * (1.0 - alpha) + reward * alpha;
                    avatar.credibility = avatar.credibility.clamp(0.1, 1.0);
                }
            }
        }
    }
    
    /// Get council size
    pub fn size(&self) -> usize {
        self.avatars.len()
    }
    
    /// Reduce council size (for performance)
    pub fn reduce_size(&mut self, by: usize) {
        // Temporarily disable lowest-credibility avatars
        let mut sorted: Vec<_> = self.avatars.iter_mut().collect();
        sorted.sort_by(|a, b| a.credibility.partial_cmp(&b.credibility).unwrap_or(std::cmp::Ordering::Equal));
        
        for avatar in sorted.iter_mut().take(by) {
            avatar.active = false;
        }
    }
    
    /// Restore council size
    pub fn restore_size(&mut self) {
        for avatar in &mut self.avatars {
            avatar.active = true;
        }
    }
    
    /// Get avatar by ID
    pub fn get_avatar(&self, id: &str) -> Option<&Avatar> {
        self.avatars.iter().find(|a| a.id == id)
    }
}

/// Avatar in the council
#[derive(Debug, Clone)]
pub struct Avatar {
    pub id: String,
    pub avatar_type: AvatarType,
    pub credibility: f64,
    pub expertise: HashMap<String, f64>,
    pub active: bool,
}

impl Avatar {
    pub fn new(id: &str, avatar_type: AvatarType, initial_credibility: f64) -> Self {
        Self {
            id: id.to_string(),
            avatar_type,
            credibility: initial_credibility,
            expertise: HashMap::new(),
            active: true,
        }
    }
    
    /// Evaluate a transform from this avatar's perspective
    pub fn evaluate(
        &self,
        phi: &Transform,
        data: &[u8],
        bands: &[prism::Band],
        config: &PxConfig,
    ) -> Vote {
        if !self.active {
            return Vote {
                decision: VoteDecision::Abstain,
                confidence: 0.0,
                reasons: vec!["Avatar inactive".into()],
            };
        }
        
        match self.avatar_type {
            AvatarType::Safety => self.evaluate_safety(phi, data, config),
            AvatarType::DataQuality => self.evaluate_data_quality(phi, data, bands, config),
            AvatarType::DomainKnowledge => self.evaluate_domain(phi, data, config),
            AvatarType::Performance => self.evaluate_performance(phi, data, config),
            AvatarType::Risk => self.evaluate_risk(phi, data, config),
        }
    }
    
    fn evaluate_safety(&self, phi: &Transform, _data: &[u8], config: &PxConfig) -> Vote {
        let mut reasons = Vec::new();
        let mut score = 1.0;
        
        // Check transform complexity
        let l_phi = phi.description_length();
        if l_phi > 10000.0 {
            score -= 0.3;
            reasons.push("High complexity transform".into());
        }
        
        // Check for dangerous patterns
        if phi.has_external_calls() {
            score -= 0.5;
            reasons.push("External calls detected".into());
        }
        
        let decision = if score > 0.6 {
            VoteDecision::Approve
        } else if score < 0.4 {
            VoteDecision::Reject
        } else {
            VoteDecision::Abstain
        };
        
        Vote { decision, confidence: score.abs(), reasons }
    }
    
    fn evaluate_data_quality(&self, phi: &Transform, data: &[u8], bands: &[prism::Band], config: &PxConfig) -> Vote {
        let mut reasons = Vec::new();
        let mut score = 1.0;
        
        // Check data coverage
        let total_covered: usize = bands.iter().map(|b| b.coefficients.len()).sum();
        let coverage = total_covered as f64 / data.len().max(1) as f64;
        
        if coverage < 0.5 {
            score -= 0.3;
            reasons.push(format!("Low data coverage: {:.1}%", coverage * 100.0));
        }
        
        // Check coherence
        let avg_coherence: f64 = bands.iter().map(|b| b.coherence_index).sum::<f64>() / bands.len().max(1) as f64;
        if avg_coherence < 0.5 {
            score -= 0.2;
            reasons.push(format!("Low coherence: {:.2}", avg_coherence));
        }
        
        let decision = if score > 0.6 {
            VoteDecision::Approve
        } else if score < 0.4 {
            VoteDecision::Reject
        } else {
            VoteDecision::Abstain
        };
        
        Vote { decision, confidence: score.abs(), reasons }
    }
    
    fn evaluate_domain(&self, phi: &Transform, data: &[u8], config: &PxConfig) -> Vote {
        // Domain knowledge evaluation
        let mut reasons = Vec::new();
        let mut score = 0.7; // Neutral by default
        
        // Check if domain expertise exists
        if let Some(domain) = phi.domain() {
            if let Some(&expertise) = self.expertise.get(domain) {
                score = expertise;
                reasons.push(format!("Domain expertise: {}", domain));
            }
        }
        
        let decision = if score > 0.6 {
            VoteDecision::Approve
        } else if score < 0.4 {
            VoteDecision::Reject
        } else {
            VoteDecision::Abstain
        };
        
        Vote { decision, confidence: score.abs(), reasons }
    }
    
    fn evaluate_performance(&self, phi: &Transform, data: &[u8], config: &PxConfig) -> Vote {
        let mut reasons = Vec::new();
        let mut score = 1.0;
        
        // Check estimated cost
        let estimated_cost = phi.estimated_cost(data.len());
        let budget = config.budget_per_window;
        
        if estimated_cost > budget * 2 {
            score -= 0.5;
            reasons.push(format!("High cost: {} > 2×budget", estimated_cost));
        } else if estimated_cost > budget {
            score -= 0.2;
            reasons.push(format!("Above budget: {} > {}", estimated_cost, budget));
        }
        
        let decision = if score > 0.6 {
            VoteDecision::Approve
        } else if score < 0.4 {
            VoteDecision::Reject
        } else {
            VoteDecision::Abstain
        };
        
        Vote { decision, confidence: score.abs(), reasons }
    }
    
    fn evaluate_risk(&self, phi: &Transform, data: &[u8], config: &PxConfig) -> Vote {
        let mut reasons = Vec::new();
        let mut risk_score = 0.0;
        
        // Complexity risk
        let l_phi = phi.description_length();
        risk_score += (l_phi / 10000.0).min(0.3);
        
        // Data sensitivity risk
        let has_patterns = check_sensitive_patterns(data);
        if has_patterns {
            risk_score += 0.3;
            reasons.push("Sensitive data patterns detected".into());
        }
        
        // Novelty risk (untested transforms)
        if phi.is_novel() {
            risk_score += 0.2;
            reasons.push("Novel transform".into());
        }
        
        let score = 1.0 - risk_score;
        let decision = if score > 0.6 {
            VoteDecision::Approve
        } else if score < 0.4 {
            VoteDecision::Reject
        } else {
            VoteDecision::Abstain
        };
        
        Vote { decision, confidence: (1.0 - score).abs(), reasons }
    }
}

/// Avatar types
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AvatarType {
    Safety,
    DataQuality,
    DomainKnowledge,
    Performance,
    Risk,
}

/// Vote from an avatar
#[derive(Debug, Clone)]
pub struct Vote {
    pub decision: VoteDecision,
    pub confidence: f64,
    pub reasons: Vec<String>,
}

/// Vote decision
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VoteDecision {
    Approve,
    Reject,
    Abstain,
}

/// Final council decision
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FinalDecision {
    Approve,
    Reject,
    Abstain,
    AskUser,
}

/// Outcome for credibility update
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Outcome {
    Success,
    Failure,
    Unknown,
}

/// Vote with avatar info
#[derive(Debug, Clone)]
pub struct AvatarVote {
    pub avatar_id: String,
    pub vote: Vote,
    pub weight: f64,
}

/// Council decision record
#[derive(Debug, Clone)]
pub struct CouncilDecision {
    pub id: Uuid,
    pub phi_id: Uuid,
    pub votes: Vec<AvatarVote>,
    pub final_decision: FinalDecision,
    pub approve_ratio: f64,
    pub timestamp: String,
}

fn check_sensitive_patterns(data: &[u8]) -> bool {
    // Check for patterns that might indicate sensitive data
    let patterns: &[&[u8]] = &[
        b"password",
        b"secret",
        b"api_key",
        b"token",
        b"credit",
        b"ssn",
    ];
    
    if let Ok(text) = std::str::from_utf8(data) {
        let lower = text.to_lowercase();
        patterns.iter().any(|p| {
            std::str::from_utf8(p)
                .map(|s| lower.contains(s))
                .unwrap_or(false)
        })
    } else {
        // Binary data - check for high entropy regions
        let entropy = crate::noise::analyze_noise(data, &PxConfig::default()).metrics.n2_entropy;
        entropy > 0.95 // High entropy might indicate encrypted/sensitive data
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_council_creation() {
        let config = PxConfig::default();
        let council = Council::new(&config);
        
        assert_eq!(council.size(), 5);
    }
    
    #[test]
    fn test_avatar_credibility() {
        let mut avatar = Avatar::new("test", AvatarType::Safety, 1.0);
        assert_eq!(avatar.credibility, 1.0);
        
        // Simulate credibility decay
        avatar.credibility = avatar.credibility * 0.9 + 0.0 * 0.1;
        assert!(avatar.credibility < 1.0);
    }
}
