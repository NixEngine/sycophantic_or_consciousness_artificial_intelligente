//! # DSL Module (DSL-Stair)
//! 
//! Manages the DSL hierarchy with climb/fall criteria.
//! 
//! ## Climb Criterion
//! climb(k→k+1) ⟺ ΔJ(D; M_k→M_{k+1}) < -τ_climb ∧ budget > cost(M_{k+1})
//! 
//! ## Fall Criterion  
//! fall(k→k-1) ⟺ ΔJ(D; M_k→M_{k-1}) > τ_fall ∨ timeout(M_k)

use crate::{PxConfig, PxError, synthesis::DslLevel};
use std::time::{Duration, Instant};

/// DSL Stair controller
pub struct DslStair {
    /// Current level
    current_level: DslLevel,
    /// Maximum allowed level
    max_level: DslLevel,
    /// Climb threshold (τ_climb)
    tau_climb: f64,
    /// Fall threshold (τ_fall)
    tau_fall: f64,
    /// Level statistics
    level_stats: [LevelStats; 4],
    /// Budget per level (ms)
    level_budgets: [u64; 4],
    /// Last J score per level
    last_j: [Option<f64>; 4],
}

/// Statistics for a DSL level
#[derive(Debug, Clone, Default)]
struct LevelStats {
    /// Number of times used
    uses: u64,
    /// Total time spent (ms)
    total_time_ms: u64,
    /// Average J improvement
    avg_j_improvement: f64,
    /// Success rate
    success_rate: f64,
}

impl DslStair {
    pub fn new(config: &PxConfig) -> Self {
        Self {
            current_level: DslLevel::Linear,
            max_level: DslLevel::Functional,
            tau_climb: config.tau_j,
            tau_fall: config.tau_j * 0.5,
            level_stats: Default::default(),
            level_budgets: [50, 100, 200, 500], // ms per level
            last_j: [None; 4],
        }
    }
    
    /// Check if should climb to next level
    pub fn should_climb(&self, delta_j: f64, available_budget: u64) -> bool {
        let next_level = self.next_level();
        if next_level.is_none() {
            return false;
        }
        
        let next_idx = next_level.unwrap() as usize;
        let cost = self.level_budgets[next_idx];
        
        // Climb if: ΔJ < -τ_climb AND budget > cost
        delta_j < -self.tau_climb && available_budget > cost
    }
    
    /// Check if should fall to previous level
    pub fn should_fall(&self, delta_j: f64, timed_out: bool) -> bool {
        // Fall if: ΔJ > τ_fall OR timeout
        delta_j > self.tau_fall || timed_out
    }
    
    /// Climb to next level
    pub fn climb(&mut self) -> Option<DslLevel> {
        if let Some(next) = self.next_level() {
            self.current_level = next;
            Some(next)
        } else {
            None
        }
    }
    
    /// Fall to previous level
    pub fn fall(&mut self) -> Option<DslLevel> {
        if let Some(prev) = self.prev_level() {
            self.current_level = prev;
            Some(prev)
        } else {
            None
        }
    }
    
    /// Get next level (if any)
    fn next_level(&self) -> Option<DslLevel> {
        match self.current_level {
            DslLevel::Linear => Some(DslLevel::Regular),
            DslLevel::Regular => Some(DslLevel::Symbolic),
            DslLevel::Symbolic => {
                if self.max_level >= DslLevel::Functional {
                    Some(DslLevel::Functional)
                } else {
                    None
                }
            }
            DslLevel::Functional => None,
        }
    }
    
    /// Get previous level (if any)
    fn prev_level(&self) -> Option<DslLevel> {
        match self.current_level {
            DslLevel::Linear => None,
            DslLevel::Regular => Some(DslLevel::Linear),
            DslLevel::Symbolic => Some(DslLevel::Regular),
            DslLevel::Functional => Some(DslLevel::Symbolic),
        }
    }
    
    /// Get current level
    pub fn current(&self) -> DslLevel {
        self.current_level
    }
    
    /// Get budget for current level
    pub fn current_budget(&self) -> u64 {
        self.level_budgets[self.current_level as usize]
    }
    
    /// Record synthesis result
    pub fn record_result(&mut self, level: DslLevel, j_before: f64, j_after: f64, time_ms: u64) {
        let idx = level as usize;
        let stats = &mut self.level_stats[idx];
        
        stats.uses += 1;
        stats.total_time_ms += time_ms;
        
        let improvement = j_before - j_after;
        let alpha = 0.1;
        stats.avg_j_improvement = stats.avg_j_improvement * (1.0 - alpha) + improvement * alpha;
        
        if improvement > 0.0 {
            stats.success_rate = stats.success_rate * (1.0 - alpha) + 1.0 * alpha;
        } else {
            stats.success_rate = stats.success_rate * (1.0 - alpha);
        }
        
        self.last_j[idx] = Some(j_after);
    }
    
    /// Set maximum level
    pub fn set_max_level(&mut self, level: DslLevel) {
        self.max_level = level;
        if self.current_level > level {
            self.current_level = level;
        }
    }
    
    /// Get level statistics
    pub fn stats(&self, level: DslLevel) -> &LevelStats {
        &self.level_stats[level as usize]
    }
    
    /// Reset to initial state
    pub fn reset(&mut self) {
        self.current_level = DslLevel::Linear;
        self.last_j = [None; 4];
    }
}

/// Anytime synthesis with DSL stair
pub struct AnytimeSynthesizer {
    stair: DslStair,
    config: PxConfig,
    /// Best transform found so far
    best_transform: Option<crate::synthesis::Transform>,
    /// Best J score
    best_j: f64,
    /// Start time
    start_time: Option<Instant>,
    /// Total budget (ms)
    total_budget_ms: u64,
}

impl AnytimeSynthesizer {
    pub fn new(config: &PxConfig) -> Self {
        Self {
            stair: DslStair::new(config),
            config: config.clone(),
            best_transform: None,
            best_j: f64::INFINITY,
            start_time: None,
            total_budget_ms: config.budget_per_window,
        }
    }
    
    /// Start synthesis session
    pub fn start(&mut self, total_budget_ms: u64) {
        self.start_time = Some(Instant::now());
        self.total_budget_ms = total_budget_ms;
        self.best_transform = None;
        self.best_j = f64::INFINITY;
        self.stair.reset();
    }
    
    /// Check if time remaining
    pub fn has_time(&self) -> bool {
        self.remaining_ms() > 0
    }
    
    /// Get remaining time (ms)
    pub fn remaining_ms(&self) -> u64 {
        self.start_time
            .map(|t| {
                let elapsed = t.elapsed().as_millis() as u64;
                self.total_budget_ms.saturating_sub(elapsed)
            })
            .unwrap_or(0)
    }
    
    /// Get current level to try
    pub fn current_level(&self) -> DslLevel {
        self.stair.current()
    }
    
    /// Report result and get next action
    pub fn report(&mut self, transform: crate::synthesis::Transform, j_score: f64, time_ms: u64) -> SynthesisAction {
        let current_level = self.stair.current();
        let j_before = self.best_j;
        
        // Update best if improved
        if j_score < self.best_j {
            self.best_j = j_score;
            self.best_transform = Some(transform);
        }
        
        // Record stats
        self.stair.record_result(current_level, j_before, j_score, time_ms);
        
        // Decide next action
        let delta_j = j_score - j_before;
        let remaining = self.remaining_ms();
        
        if remaining == 0 {
            return SynthesisAction::Stop;
        }
        
        // Check for climb
        if self.stair.should_climb(delta_j, remaining) {
            if self.stair.climb().is_some() {
                return SynthesisAction::Continue(self.stair.current());
            }
        }
        
        // Check for fall
        let timed_out = time_ms > self.stair.current_budget() * 2;
        if self.stair.should_fall(delta_j, timed_out) {
            if self.stair.fall().is_some() {
                return SynthesisAction::Continue(self.stair.current());
            }
        }
        
        // Continue at current level if time permits
        if remaining > self.stair.current_budget() {
            SynthesisAction::Continue(current_level)
        } else {
            SynthesisAction::Stop
        }
    }
    
    /// Get best result
    pub fn best(&self) -> Option<(&crate::synthesis::Transform, f64)> {
        self.best_transform.as_ref().map(|t| (t, self.best_j))
    }
}

/// Synthesis action
#[derive(Debug, Clone, Copy)]
pub enum SynthesisAction {
    Continue(DslLevel),
    Stop,
}

/// Cost model for DSL levels
pub fn estimate_cost(level: DslLevel, input_size: usize) -> u64 {
    match level {
        DslLevel::Linear => input_size as u64 * 2,
        DslLevel::Regular => input_size as u64 * 10,
        DslLevel::Symbolic => input_size as u64 * 5,
        DslLevel::Functional => input_size as u64 * 20,
    }
}

/// Expressiveness score for DSL levels
pub fn expressiveness(level: DslLevel) -> f64 {
    match level {
        DslLevel::Linear => 0.2,
        DslLevel::Regular => 0.4,
        DslLevel::Symbolic => 0.6,
        DslLevel::Functional => 1.0,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_dsl_stair() {
        let config = PxConfig::default();
        let mut stair = DslStair::new(&config);
        
        assert_eq!(stair.current(), DslLevel::Linear);
        
        stair.climb();
        assert_eq!(stair.current(), DslLevel::Regular);
        
        stair.fall();
        assert_eq!(stair.current(), DslLevel::Linear);
    }
    
    #[test]
    fn test_climb_criteria() {
        let config = PxConfig::default();
        let stair = DslStair::new(&config);
        
        // Should climb: significant improvement, sufficient budget
        assert!(stair.should_climb(-0.1, 1000));
        
        // Should not climb: no improvement
        assert!(!stair.should_climb(0.1, 1000));
        
        // Should not climb: insufficient budget
        assert!(!stair.should_climb(-0.1, 10));
    }
}
