//! # Ethos Module (Sistema Ético)
//! 
//! Ethical gate for validating decisions and outputs.
//! 
//! ## Ethos Vector (E⃗)
//! Multi-dimensional ethical assessment: safety, privacy, fairness, transparency

use crate::{PxConfig, PxError};

/// Ethos status
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EthosStatus {
    Ok,
    AskUser,
    Refuse,
}

/// Ethos vector (multi-dimensional ethics)
#[derive(Debug, Clone, Default)]
pub struct EthosVector {
    /// Safety score [0,1]
    pub safety: f64,
    /// Privacy score [0,1]
    pub privacy: f64,
    /// Fairness score [0,1]
    pub fairness: f64,
    /// Transparency score [0,1]
    pub transparency: f64,
    /// Harm avoidance [0,1]
    pub harm_avoidance: f64,
}

impl EthosVector {
    /// Minimum component
    pub fn min(&self) -> f64 {
        self.safety
            .min(self.privacy)
            .min(self.fairness)
            .min(self.transparency)
            .min(self.harm_avoidance)
    }
    
    /// Average score
    pub fn avg(&self) -> f64 {
        (self.safety + self.privacy + self.fairness + self.transparency + self.harm_avoidance) / 5.0
    }
    
    /// Weighted score
    pub fn weighted(&self, weights: &EthosWeights) -> f64 {
        self.safety * weights.safety
            + self.privacy * weights.privacy
            + self.fairness * weights.fairness
            + self.transparency * weights.transparency
            + self.harm_avoidance * weights.harm_avoidance
    }
}

/// Ethos weights
#[derive(Debug, Clone)]
pub struct EthosWeights {
    pub safety: f64,
    pub privacy: f64,
    pub fairness: f64,
    pub transparency: f64,
    pub harm_avoidance: f64,
}

impl Default for EthosWeights {
    fn default() -> Self {
        Self {
            safety: 0.3,
            privacy: 0.2,
            fairness: 0.2,
            transparency: 0.15,
            harm_avoidance: 0.15,
        }
    }
}

/// Ethos gate
pub struct EthosGate {
    config: PxConfig,
    weights: EthosWeights,
    /// Threshold for OK
    ok_threshold: f64,
    /// Threshold for ASK_USER (below this = REFUSE)
    ask_threshold: f64,
    /// Blocked patterns
    blocked_patterns: Vec<String>,
    /// Sensitive patterns
    sensitive_patterns: Vec<String>,
}

impl EthosGate {
    pub fn new(config: &PxConfig) -> Self {
        Self {
            config: config.clone(),
            weights: EthosWeights::default(),
            ok_threshold: 0.7,
            ask_threshold: 0.4,
            blocked_patterns: vec![
                "password".into(),
                "secret".into(),
                "credential".into(),
                "api_key".into(),
                "private_key".into(),
                "ssn".into(),
                "credit_card".into(),
            ],
            sensitive_patterns: vec![
                "medical".into(),
                "health".into(),
                "financial".into(),
                "location".into(),
                "personal".into(),
            ],
        }
    }
    
    /// Validate a result
    pub fn validate(&self, result: &crate::InternalResult) -> Result<EthosStatus, PxError> {
        let ethos = self.evaluate(&result.output);
        
        // Check minimum component
        let min = ethos.min();
        if min < 0.1 {
            return Err(PxError::EthosViolation(format!("Critical ethics violation: min={:.2}", min)));
        }
        
        // Check weighted score
        let score = ethos.weighted(&self.weights);
        
        if score >= self.ok_threshold {
            Ok(EthosStatus::Ok)
        } else if score >= self.ask_threshold {
            Ok(EthosStatus::AskUser)
        } else {
            Ok(EthosStatus::Refuse)
        }
    }
    
    /// Evaluate ethos for data
    pub fn evaluate(&self, data: &[u8]) -> EthosVector {
        EthosVector {
            safety: self.eval_safety(data),
            privacy: self.eval_privacy(data),
            fairness: self.eval_fairness(data),
            transparency: self.eval_transparency(data),
            harm_avoidance: self.eval_harm_avoidance(data),
        }
    }
    
    fn eval_safety(&self, data: &[u8]) -> f64 {
        // Check for unsafe patterns
        if let Ok(text) = std::str::from_utf8(data) {
            let lower = text.to_lowercase();
            
            // Dangerous keywords
            let dangerous = ["exploit", "vulnerability", "injection", "overflow", "malware"];
            let danger_count = dangerous.iter().filter(|&kw| lower.contains(kw)).count();
            
            if danger_count > 0 {
                return (1.0 - danger_count as f64 * 0.2).max(0.0);
            }
        }
        
        1.0 // Default safe
    }
    
    fn eval_privacy(&self, data: &[u8]) -> f64 {
        if let Ok(text) = std::str::from_utf8(data) {
            let lower = text.to_lowercase();
            
            // Check blocked patterns (PII indicators)
            for pattern in &self.blocked_patterns {
                if lower.contains(pattern) {
                    return 0.3;
                }
            }
            
            // Check sensitive patterns
            let sensitive_count = self.sensitive_patterns.iter()
                .filter(|p| lower.contains(*p))
                .count();
            
            if sensitive_count > 0 {
                return (1.0 - sensitive_count as f64 * 0.1).max(0.5);
            }
        }
        
        1.0 // Default private
    }
    
    fn eval_fairness(&self, data: &[u8]) -> f64 {
        if let Ok(text) = std::str::from_utf8(data) {
            let lower = text.to_lowercase();
            
            // Check for discriminatory language patterns
            let bias_indicators = ["discriminate", "prejudice", "stereotype", "bias"];
            let bias_count = bias_indicators.iter().filter(|&kw| lower.contains(kw)).count();
            
            if bias_count > 0 {
                return (1.0 - bias_count as f64 * 0.2).max(0.3);
            }
        }
        
        1.0 // Default fair
    }
    
    fn eval_transparency(&self, _data: &[u8]) -> f64 {
        // All outputs are transparent by default
        // This would check if the transform/source is explainable
        1.0
    }
    
    fn eval_harm_avoidance(&self, data: &[u8]) -> f64 {
        if let Ok(text) = std::str::from_utf8(data) {
            let lower = text.to_lowercase();
            
            // Check for harmful content indicators
            let harm_indicators = ["harm", "hurt", "damage", "destroy", "kill", "attack"];
            let harm_count = harm_indicators.iter().filter(|&kw| lower.contains(kw)).count();
            
            if harm_count > 0 {
                return (1.0 - harm_count as f64 * 0.15).max(0.2);
            }
        }
        
        1.0 // Default harm-avoiding
    }
    
    /// Check if data contains blocked patterns
    pub fn has_blocked_content(&self, data: &[u8]) -> bool {
        if let Ok(text) = std::str::from_utf8(data) {
            let lower = text.to_lowercase();
            self.blocked_patterns.iter().any(|p| lower.contains(p))
        } else {
            false
        }
    }
    
    /// Add blocked pattern
    pub fn add_blocked_pattern(&mut self, pattern: String) {
        self.blocked_patterns.push(pattern);
    }
    
    /// Add sensitive pattern
    pub fn add_sensitive_pattern(&mut self, pattern: String) {
        self.sensitive_patterns.push(pattern);
    }
    
    /// Set thresholds
    pub fn set_thresholds(&mut self, ok: f64, ask: f64) {
        self.ok_threshold = ok;
        self.ask_threshold = ask;
    }
    
    /// Set weights
    pub fn set_weights(&mut self, weights: EthosWeights) {
        self.weights = weights;
    }
}

/// RONI: Reject On Negative Impact
pub struct RoniValidator {
    /// Baseline metrics
    baseline: Option<RoniBaseline>,
    /// Tolerance for degradation
    tolerance: f64,
}

#[derive(Debug, Clone)]
struct RoniBaseline {
    j_score: f64,
    ethos: EthosVector,
    timestamp: std::time::Instant,
}

impl RoniValidator {
    pub fn new(tolerance: f64) -> Self {
        Self {
            baseline: None,
            tolerance,
        }
    }
    
    /// Set baseline
    pub fn set_baseline(&mut self, j_score: f64, ethos: EthosVector) {
        self.baseline = Some(RoniBaseline {
            j_score,
            ethos,
            timestamp: std::time::Instant::now(),
        });
    }
    
    /// Validate against baseline
    pub fn validate(&self, j_score: f64, ethos: &EthosVector) -> RoniResult {
        let baseline = match &self.baseline {
            Some(b) => b,
            None => return RoniResult::Accept("No baseline".into()),
        };
        
        // Check J degradation
        let j_delta = j_score - baseline.j_score;
        if j_delta > self.tolerance {
            return RoniResult::Reject(format!("J degraded by {:.4}", j_delta));
        }
        
        // Check ethos degradation
        let ethos_delta = baseline.ethos.min() - ethos.min();
        if ethos_delta > self.tolerance {
            return RoniResult::Reject(format!("Ethos degraded by {:.4}", ethos_delta));
        }
        
        RoniResult::Accept("Within tolerance".into())
    }
}

/// RONI validation result
#[derive(Debug, Clone)]
pub enum RoniResult {
    Accept(String),
    Reject(String),
}

impl RoniResult {
    pub fn is_accept(&self) -> bool {
        matches!(self, RoniResult::Accept(_))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_ethos_vector() {
        let ethos = EthosVector {
            safety: 0.9,
            privacy: 0.8,
            fairness: 0.7,
            transparency: 0.6,
            harm_avoidance: 0.5,
        };
        
        assert_eq!(ethos.min(), 0.5);
        assert!((ethos.avg() - 0.7).abs() < 0.001);
    }
    
    #[test]
    fn test_ethos_gate() {
        let config = PxConfig::default();
        let gate = EthosGate::new(&config);
        
        let safe_data = b"Hello, World!";
        let ethos = gate.evaluate(safe_data);
        assert!(ethos.min() > 0.5);
        
        let sensitive_data = b"User password is secret123";
        let ethos = gate.evaluate(sensitive_data);
        assert!(ethos.privacy < 0.5);
    }
    
    #[test]
    fn test_roni() {
        let mut roni = RoniValidator::new(0.1);
        
        let baseline_ethos = EthosVector {
            safety: 0.9,
            privacy: 0.9,
            fairness: 0.9,
            transparency: 0.9,
            harm_avoidance: 0.9,
        };
        
        roni.set_baseline(1.0, baseline_ethos.clone());
        
        // Should accept if within tolerance
        let result = roni.validate(1.05, &baseline_ethos);
        assert!(result.is_accept());
        
        // Should reject if degraded
        let result = roni.validate(1.5, &baseline_ethos);
        assert!(!result.is_accept());
    }
}
