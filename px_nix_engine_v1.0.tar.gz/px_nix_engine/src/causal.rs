//! # Causal Module
//! 
//! Causal reasoning and do-calculus implementation.
//! 
//! ## Key Concepts
//! - Causal Graph: DAG of causal relationships
//! - do-calculus: P(Y | do(X=x)) ≠ P(Y | X=x)
//! - Counterfactual analysis

use crate::{PxConfig, PxError};
use hashbrown::{HashMap, HashSet};
use uuid::Uuid;

/// Causal node
#[derive(Debug, Clone)]
pub struct CausalNode {
    pub id: Uuid,
    pub name: String,
    pub node_type: NodeType,
    pub distribution: Option<Distribution>,
}

/// Node type in causal graph
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NodeType {
    Observable,
    Latent,
    Intervention,
}

/// Distribution type
#[derive(Debug, Clone)]
pub enum Distribution {
    Bernoulli(f64),
    Normal { mean: f64, std: f64 },
    Categorical(Vec<f64>),
    Deterministic(f64),
}

/// Causal edge
#[derive(Debug, Clone)]
pub struct CausalEdge {
    pub from: Uuid,
    pub to: Uuid,
    pub strength: f64,
    pub uncertainty: f64,
    pub edge_type: EdgeType,
}

/// Edge type
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EdgeType {
    Direct,
    Confounding,
    Mediating,
}

/// Intervention
#[derive(Debug, Clone)]
pub struct Intervention {
    pub target: Uuid,
    pub value: f64,
    pub query: Uuid,
}

/// Causal graph
pub struct CausalGraph {
    /// Nodes by ID
    nodes: HashMap<Uuid, CausalNode>,
    /// Edges (from -> [(to, edge)])
    edges: HashMap<Uuid, Vec<CausalEdge>>,
    /// Reverse edges (to -> [from])
    reverse_edges: HashMap<Uuid, Vec<Uuid>>,
    /// Intervention log
    interventions_log: Vec<InterventionRecord>,
}

#[derive(Debug, Clone)]
struct InterventionRecord {
    intervention: Intervention,
    result: f64,
    timestamp: String,
}

impl CausalGraph {
    pub fn new() -> Self {
        Self {
            nodes: HashMap::new(),
            edges: HashMap::new(),
            reverse_edges: HashMap::new(),
            interventions_log: Vec::new(),
        }
    }
    
    /// Add node
    pub fn add_node(&mut self, name: &str, node_type: NodeType) -> Uuid {
        let id = Uuid::new_v4();
        let node = CausalNode {
            id,
            name: name.to_string(),
            node_type,
            distribution: None,
        };
        self.nodes.insert(id, node);
        id
    }
    
    /// Add edge
    pub fn add_edge(&mut self, from: Uuid, to: Uuid, strength: f64, edge_type: EdgeType) {
        let edge = CausalEdge {
            from,
            to,
            strength,
            uncertainty: 0.1,
            edge_type,
        };
        
        self.edges.entry(from).or_default().push(edge);
        self.reverse_edges.entry(to).or_default().push(from);
    }
    
    /// Get parents of node
    pub fn parents(&self, node: Uuid) -> Vec<Uuid> {
        self.reverse_edges.get(&node).cloned().unwrap_or_default()
    }
    
    /// Get children of node
    pub fn children(&self, node: Uuid) -> Vec<Uuid> {
        self.edges.get(&node)
            .map(|edges| edges.iter().map(|e| e.to).collect())
            .unwrap_or_default()
    }
    
    /// Get ancestors of node
    pub fn ancestors(&self, node: Uuid) -> HashSet<Uuid> {
        let mut ancestors = HashSet::new();
        let mut queue = vec![node];
        
        while let Some(current) = queue.pop() {
            for parent in self.parents(current) {
                if ancestors.insert(parent) {
                    queue.push(parent);
                }
            }
        }
        
        ancestors
    }
    
    /// Get descendants of node
    pub fn descendants(&self, node: Uuid) -> HashSet<Uuid> {
        let mut descendants = HashSet::new();
        let mut queue = vec![node];
        
        while let Some(current) = queue.pop() {
            for child in self.children(current) {
                if descendants.insert(child) {
                    queue.push(child);
                }
            }
        }
        
        descendants
    }
    
    /// do-calculus: compute P(Y | do(X=x))
    pub fn do_calculus(&self, intervention: &Intervention) -> DoCalculusResult {
        // 1. Mutilate graph (remove edges into intervention target)
        let mutilated = self.mutilate(intervention.target);
        
        // 2. Compute causal effect in mutilated graph
        let effect = mutilated.compute_effect(intervention);
        
        // 3. Record intervention
        // (Cannot mutate self here, would need separate method)
        
        DoCalculusResult {
            intervention: intervention.clone(),
            causal_effect: effect,
            confounders: self.find_confounders(intervention.target, intervention.query),
            adjustment_set: self.find_adjustment_set(intervention.target, intervention.query),
        }
    }
    
    /// Mutilate graph (remove edges into target)
    fn mutilate(&self, target: Uuid) -> Self {
        let mut mutilated = Self {
            nodes: self.nodes.clone(),
            edges: HashMap::new(),
            reverse_edges: HashMap::new(),
            interventions_log: Vec::new(),
        };
        
        // Copy edges except those into target
        for (from, edges) in &self.edges {
            let filtered: Vec<CausalEdge> = edges.iter()
                .filter(|e| e.to != target)
                .cloned()
                .collect();
            
            if !filtered.is_empty() {
                for edge in &filtered {
                    mutilated.reverse_edges.entry(edge.to).or_default().push(*from);
                }
                mutilated.edges.insert(*from, filtered);
            }
        }
        
        mutilated
    }
    
    /// Compute causal effect
    fn compute_effect(&self, intervention: &Intervention) -> f64 {
        // Simplified: sum of path coefficients
        let paths = self.find_paths(intervention.target, intervention.query);
        
        let mut total_effect = 0.0;
        for path in paths {
            let mut path_effect = intervention.value;
            for i in 0..path.len() - 1 {
                let from = path[i];
                let to = path[i + 1];
                
                if let Some(edges) = self.edges.get(&from) {
                    if let Some(edge) = edges.iter().find(|e| e.to == to) {
                        path_effect *= edge.strength;
                    }
                }
            }
            total_effect += path_effect;
        }
        
        total_effect
    }
    
    /// Find all directed paths between two nodes
    fn find_paths(&self, from: Uuid, to: Uuid) -> Vec<Vec<Uuid>> {
        let mut paths = Vec::new();
        let mut current_path = vec![from];
        let mut visited = HashSet::new();
        
        self.find_paths_dfs(from, to, &mut current_path, &mut visited, &mut paths);
        
        paths
    }
    
    fn find_paths_dfs(
        &self,
        current: Uuid,
        target: Uuid,
        path: &mut Vec<Uuid>,
        visited: &mut HashSet<Uuid>,
        paths: &mut Vec<Vec<Uuid>>,
    ) {
        if current == target {
            paths.push(path.clone());
            return;
        }
        
        if visited.contains(&current) {
            return;
        }
        
        visited.insert(current);
        
        for child in self.children(current) {
            path.push(child);
            self.find_paths_dfs(child, target, path, visited, paths);
            path.pop();
        }
        
        visited.remove(&current);
    }
    
    /// Find confounders between two nodes
    fn find_confounders(&self, x: Uuid, y: Uuid) -> Vec<Uuid> {
        let x_ancestors = self.ancestors(x);
        let y_ancestors = self.ancestors(y);
        
        // Common ancestors are potential confounders
        x_ancestors.intersection(&y_ancestors).copied().collect()
    }
    
    /// Find adjustment set (backdoor criterion)
    fn find_adjustment_set(&self, x: Uuid, y: Uuid) -> Vec<Uuid> {
        // Simplified: return all confounders
        // Full implementation would check backdoor criterion
        self.find_confounders(x, y)
    }
    
    /// Counterfactual query: P(Y_x | X=x', Y=y)
    pub fn counterfactual(&self, intervention: &Intervention, observation: (Uuid, f64)) -> f64 {
        // 1. Abduction: update beliefs based on observation
        // 2. Action: apply intervention
        // 3. Prediction: compute counterfactual outcome
        
        // Simplified implementation
        let causal_effect = self.do_calculus(intervention).causal_effect;
        let (obs_node, obs_value) = observation;
        
        // Adjust for observation
        if obs_node == intervention.query {
            obs_value + causal_effect
        } else {
            causal_effect
        }
    }
    
    /// Log intervention
    pub fn log_intervention(&mut self, intervention: Intervention, result: f64) {
        self.interventions_log.push(InterventionRecord {
            intervention,
            result,
            timestamp: crate::utils::now_iso(),
        });
    }
    
    /// Update edge strength from data
    pub fn update_from_data(&mut self, from: Uuid, to: Uuid, observed_strength: f64, confidence: f64) {
        if let Some(edges) = self.edges.get_mut(&from) {
            if let Some(edge) = edges.iter_mut().find(|e| e.to == to) {
                // Bayesian update with confidence weighting
                let alpha = confidence * 0.1;
                edge.strength = edge.strength * (1.0 - alpha) + observed_strength * alpha;
                edge.uncertainty = edge.uncertainty * (1.0 - alpha * 0.5);
            }
        }
    }
    
    /// Get causal competence score
    pub fn causal_competence(&self) -> f64 {
        if self.interventions_log.is_empty() {
            return 0.0;
        }
        
        // Compute accuracy of causal predictions
        let mut correct = 0.0;
        let mut total = 0.0;
        
        for record in &self.interventions_log {
            let predicted = self.do_calculus(&record.intervention).causal_effect;
            let error = (predicted - record.result).abs();
            
            if error < 0.1 {
                correct += 1.0;
            }
            total += 1.0;
        }
        
        if total > 0.0 { correct / total } else { 0.0 }
    }
}

impl Default for CausalGraph {
    fn default() -> Self {
        Self::new()
    }
}

/// Result of do-calculus
#[derive(Debug, Clone)]
pub struct DoCalculusResult {
    pub intervention: Intervention,
    pub causal_effect: f64,
    pub confounders: Vec<Uuid>,
    pub adjustment_set: Vec<Uuid>,
}

/// Causal discovery from data
pub struct CausalDiscovery {
    config: PxConfig,
}

impl CausalDiscovery {
    pub fn new(config: &PxConfig) -> Self {
        Self { config: config.clone() }
    }
    
    /// Discover causal structure from correlation data
    pub fn discover(&self, correlations: &[(Uuid, Uuid, f64)]) -> CausalGraph {
        let mut graph = CausalGraph::new();
        
        // Add nodes
        let mut nodes = HashSet::new();
        for (a, b, _) in correlations {
            nodes.insert(*a);
            nodes.insert(*b);
        }
        
        for &node in &nodes {
            graph.nodes.insert(node, CausalNode {
                id: node,
                name: format!("Node_{}", node),
                node_type: NodeType::Observable,
                distribution: None,
            });
        }
        
        // Add edges based on correlations (simplified: stronger correlation = more likely causal)
        for (a, b, corr) in correlations {
            if *corr > 0.3 {
                graph.add_edge(*a, *b, *corr, EdgeType::Direct);
            }
        }
        
        graph
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_causal_graph() {
        let mut graph = CausalGraph::new();
        
        let x = graph.add_node("X", NodeType::Observable);
        let y = graph.add_node("Y", NodeType::Observable);
        let z = graph.add_node("Z", NodeType::Observable);
        
        graph.add_edge(x, y, 0.5, EdgeType::Direct);
        graph.add_edge(z, x, 0.3, EdgeType::Direct);
        graph.add_edge(z, y, 0.4, EdgeType::Direct);
        
        let parents = graph.parents(y);
        assert!(parents.contains(&x));
        assert!(parents.contains(&z));
        
        let confounders = graph.find_confounders(x, y);
        assert!(confounders.contains(&z));
    }
    
    #[test]
    fn test_do_calculus() {
        let mut graph = CausalGraph::new();
        
        let x = graph.add_node("X", NodeType::Observable);
        let y = graph.add_node("Y", NodeType::Observable);
        
        graph.add_edge(x, y, 0.8, EdgeType::Direct);
        
        let intervention = Intervention {
            target: x,
            value: 1.0,
            query: y,
        };
        
        let result = graph.do_calculus(&intervention);
        assert!((result.causal_effect - 0.8).abs() < 0.001);
    }
}
