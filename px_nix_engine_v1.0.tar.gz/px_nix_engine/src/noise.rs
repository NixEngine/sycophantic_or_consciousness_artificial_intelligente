//! # Noise-First Analysis Module
//! 
//! Cascading noise detection (N1-N6) with early-exit for efficient routing.
//! 
//! ## Noise Metrics
//! - N1: Compressibility (expensive, on-demand)
//! - N2: Entropy (rolling histogram, O(n))
//! - N3: LZ-hint (rolling hash, O(n))
//! - N4: Syndrome (Hamming/BCH, O(1) per block)
//! - N5: Format signatures (magic bytes, O(1))
//! - N6: Spectral flatness (Goertzel/Hadamard, O(n))

use crate::PxConfig;
use std::collections::VecDeque;

/// Result of noise analysis
#[derive(Debug, Clone)]
pub struct NoiseResult {
    /// Aggregated noise score [0,1] (1 = pure noise)
    pub score: f64,
    /// Individual metric scores
    pub metrics: NoiseMetrics,
    /// Decision: FAST or DEEP
    pub decision: NoiseDecision,
    /// Reason for decision
    pub reason: String,
    /// Spans with their classifications
    pub spans: Vec<NoiseSpan>,
}

/// Individual noise metrics
#[derive(Debug, Clone, Default)]
pub struct NoiseMetrics {
    /// N1: Compressibility (1 - compression_ratio)
    pub n1_compress: Option<f64>,
    /// N2: Normalized entropy
    pub n2_entropy: f64,
    /// N3: LZ complexity (normalized)
    pub n3_lz_hint: f64,
    /// N4: Syndrome failure rate
    pub n4_syndrome: f64,
    /// N5: Format adherence (0 = valid format)
    pub n5_format: f64,
    /// N6: Spectral flatness
    pub n6_spectral: Option<f64>,
}

/// Noise decision
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NoiseDecision {
    Fast,  // High noise, skip deep processing
    Deep,  // Low noise, worth processing
    Ambiguous,  // Needs more analysis
}

/// Span classification
#[derive(Debug, Clone)]
pub struct NoiseSpan {
    pub start: usize,
    pub end: usize,
    pub score: f64,
    pub decision: NoiseDecision,
}

/// Analyze noise in data using cascading metrics
pub fn analyze_noise(data: &[u8], config: &PxConfig) -> NoiseResult {
    if data.is_empty() {
        return NoiseResult {
            score: 1.0,
            metrics: NoiseMetrics::default(),
            decision: NoiseDecision::Fast,
            reason: "empty input".into(),
            spans: vec![],
        };
    }
    
    let mut metrics = NoiseMetrics::default();
    let mut early_exit_count = 0;
    
    // Stage 1: Cheap metrics (O(n))
    
    // N2: Entropy
    metrics.n2_entropy = compute_n2_entropy(data);
    if metrics.n2_entropy > 0.95 {
        early_exit_count += 1;
    }
    
    // N5: Format signatures
    metrics.n5_format = compute_n5_format(data);
    if metrics.n5_format > 0.9 {
        early_exit_count += 1;
    }
    
    // N3: LZ-hint
    metrics.n3_lz_hint = compute_n3_lz_hint(data);
    if metrics.n3_lz_hint > 0.8 {
        early_exit_count += 1;
    }
    
    // Early exit: 2+ indicators suggest noise
    if early_exit_count >= 2 {
        let score = robust_median(&[metrics.n2_entropy, metrics.n5_format, metrics.n3_lz_hint]);
        return NoiseResult {
            score,
            metrics,
            decision: NoiseDecision::Fast,
            reason: "early-exit: multiple noise indicators".into(),
            spans: vec![NoiseSpan { start: 0, end: data.len(), score, decision: NoiseDecision::Fast }],
        };
    }
    
    // Stage 2: Medium cost metrics
    
    // N4: Syndrome
    metrics.n4_syndrome = compute_n4_syndrome(data);
    
    // N6: Spectral flatness (only if borderline)
    let interim_score = robust_median(&[
        metrics.n2_entropy, 
        metrics.n3_lz_hint, 
        metrics.n4_syndrome,
        metrics.n5_format,
    ]);
    
    if (interim_score - config.tau_noise).abs() < config.hysteresis_band {
        // Borderline - compute N6
        metrics.n6_spectral = Some(compute_n6_spectral(data));
    }
    
    // Stage 3: Expensive metrics (only if still ambiguous)
    let all_metrics: Vec<f64> = vec![
        metrics.n2_entropy,
        metrics.n3_lz_hint,
        metrics.n4_syndrome,
        metrics.n5_format,
    ]
    .into_iter()
    .chain(metrics.n6_spectral.into_iter())
    .collect();
    
    let score = robust_median(&all_metrics);
    
    // Check if we need N1 (compression)
    if (score - config.tau_noise).abs() < config.hysteresis_band * 0.5 {
        metrics.n1_compress = Some(compute_n1_compress(data));
        let final_metrics: Vec<f64> = all_metrics.into_iter()
            .chain(metrics.n1_compress.into_iter())
            .collect();
        let final_score = robust_median(&final_metrics);
        
        let decision = decide(final_score, config.tau_noise, config.hysteresis_band);
        return NoiseResult {
            score: final_score,
            metrics,
            decision,
            reason: format!("full cascade: N1-N6 evaluated"),
            spans: segment_data(data, config),
        };
    }
    
    let decision = decide(score, config.tau_noise, config.hysteresis_band);
    NoiseResult {
        score,
        metrics,
        decision,
        reason: format!("partial cascade: N2-N6 evaluated"),
        spans: segment_data(data, config),
    }
}

/// N1: Compressibility (expensive)
fn compute_n1_compress(data: &[u8]) -> f64 {
    let original_len = data.len() as f64;
    if original_len == 0.0 {
        return 1.0;
    }
    
    let compressed = lz4_flex::compress_prepend_size(data);
    let ratio = compressed.len() as f64 / original_len;
    
    // Normalize: ratio close to 1 = noise
    ratio.min(1.0)
}

/// N2: Entropy estimation (cheap, rolling)
fn compute_n2_entropy(data: &[u8]) -> f64 {
    if data.is_empty() {
        return 1.0;
    }
    
    // Histogram
    let mut counts = [0u64; 256];
    for &byte in data {
        counts[byte as usize] += 1;
    }
    
    // Shannon entropy
    let total = data.len() as f64;
    let mut entropy = 0.0;
    
    for &count in &counts {
        if count > 0 {
            let p = count as f64 / total;
            entropy -= p * p.log2();
        }
    }
    
    // Normalize to [0, 1] (max entropy = 8 bits)
    entropy / 8.0
}

/// N3: LZ-hint using rolling hash
fn compute_n3_lz_hint(data: &[u8]) -> f64 {
    if data.len() < 16 {
        return 1.0;
    }
    
    // Rolling hash for match detection
    const WINDOW: usize = 8;
    const PRIME: u64 = 31;
    const MOD: u64 = 1_000_000_007;
    
    let mut seen: hashbrown::HashSet<u64> = hashbrown::HashSet::with_capacity(data.len() / WINDOW);
    let mut unique_hashes = 0u64;
    let mut total_windows = 0u64;
    
    if data.len() < WINDOW {
        return 1.0;
    }
    
    // Compute initial hash
    let mut hash = 0u64;
    let mut pow = 1u64;
    
    for i in 0..WINDOW {
        hash = (hash * PRIME + data[i] as u64) % MOD;
        if i < WINDOW - 1 {
            pow = (pow * PRIME) % MOD;
        }
    }
    
    if !seen.contains(&hash) {
        seen.insert(hash);
        unique_hashes += 1;
    }
    total_windows += 1;
    
    // Rolling hash
    for i in WINDOW..data.len() {
        hash = (hash + MOD - (data[i - WINDOW] as u64 * pow) % MOD) % MOD;
        hash = (hash * PRIME + data[i] as u64) % MOD;
        
        if !seen.contains(&hash) {
            seen.insert(hash);
            unique_hashes += 1;
        }
        total_windows += 1;
    }
    
    // High ratio of unique hashes = noise-like
    unique_hashes as f64 / total_windows as f64
}

/// N4: Syndrome-based detection (ECC parity checks)
fn compute_n4_syndrome(data: &[u8]) -> f64 {
    if data.is_empty() {
        return 1.0;
    }
    
    // Hamming(7,4) check on blocks
    // For real data, many blocks should have valid parity
    // For random noise, ~50% parity failures expected
    
    let mut valid_parities = 0u64;
    let mut total_checks = 0u64;
    
    for chunk in data.chunks(4) {
        if chunk.len() < 4 {
            continue;
        }
        
        // Simple parity check (XOR of bits)
        let parity = chunk.iter().fold(0u8, |acc, &b| acc ^ b);
        let ones = parity.count_ones();
        
        // Even parity = valid structure signal
        if ones % 2 == 0 {
            valid_parities += 1;
        }
        total_checks += 1;
    }
    
    if total_checks == 0 {
        return 1.0;
    }
    
    // More failed parities = more noise
    1.0 - (valid_parities as f64 / total_checks as f64)
}

/// N5: Format signature detection
fn compute_n5_format(data: &[u8]) -> f64 {
    if data.len() < 4 {
        return 1.0;
    }
    
    // Check for known magic bytes
    let magic_detected = check_magic_bytes(data);
    
    // Check for JSON/CBOR/text structure
    let structure_score = check_structure(data);
    
    // Combined: recognized format = low noise score
    let format_score = if magic_detected { 0.0 } else { 0.5 };
    
    (format_score + structure_score) / 2.0
}

fn check_magic_bytes(data: &[u8]) -> bool {
    let magics: &[&[u8]] = &[
        b"\x89PNG",      // PNG
        b"\xFF\xD8\xFF", // JPEG
        &[0x50, 0x4B, 0x03, 0x04], // ZIP
        b"PK",           // ZIP short
        b"{\x22",        // JSON
        b"[",            // JSON array
        b"{",            // JSON object
        &[0xBF],         // CBOR
        b"<!DOCTYPE",    // HTML
        b"<html",        // HTML
        b"<?xml",        // XML
        b"RIFF",         // WAV/AVI
        b"ftyp",         // MP4
        b"\x1F\x8B",     // GZIP
        b"BZ",           // BZIP2
        b"\xFD7zXZ",     // XZ
        b"SQLite",       // SQLite
    ];
    
    for magic in magics {
        if data.starts_with(magic) || data.get(4..4+magic.len()) == Some(magic) {
            return true;
        }
    }
    false
}

fn check_structure(data: &[u8]) -> f64 {
    // Check for ASCII/UTF-8 text
    let ascii_count = data.iter().filter(|&&b| b >= 32 && b < 127).count();
    let utf8_valid = std::str::from_utf8(data).is_ok();
    
    let text_ratio = ascii_count as f64 / data.len() as f64;
    
    if utf8_valid && text_ratio > 0.8 {
        return 0.1; // Likely text
    }
    
    // Check for binary structure patterns
    let zero_ratio = data.iter().filter(|&&b| b == 0).count() as f64 / data.len() as f64;
    
    if zero_ratio > 0.1 && zero_ratio < 0.5 {
        return 0.3; // Structured binary
    }
    
    0.7 // Unknown/noise-like
}

/// N6: Spectral flatness (Goertzel for selected frequencies)
fn compute_n6_spectral(data: &[u8]) -> f64 {
    if data.len() < 32 {
        return 1.0;
    }
    
    // Convert to f64 samples
    let samples: Vec<f64> = data.iter().map(|&b| b as f64 - 128.0).collect();
    
    // Compute power at selected frequencies using Goertzel
    let n = samples.len();
    let num_bins = 16.min(n / 2);
    let mut powers = Vec::with_capacity(num_bins);
    
    for k in 1..=num_bins {
        let power = goertzel(&samples, k as f64 / n as f64);
        powers.push(power);
    }
    
    // Spectral flatness = geometric_mean / arithmetic_mean
    let geo_mean = powers.iter()
        .map(|&p| (p + 1e-10).ln())
        .sum::<f64>()
        .exp()
        / powers.len() as f64;
    
    let arith_mean = powers.iter().sum::<f64>() / powers.len() as f64;
    
    if arith_mean < 1e-10 {
        return 1.0;
    }
    
    // Flatness close to 1 = white noise
    (geo_mean / arith_mean).min(1.0)
}

/// Goertzel algorithm for single frequency power
fn goertzel(samples: &[f64], freq: f64) -> f64 {
    let n = samples.len();
    let k = (freq * n as f64).round() as usize;
    let w = 2.0 * std::f64::consts::PI * k as f64 / n as f64;
    let coeff = 2.0 * w.cos();
    
    let mut s0 = 0.0;
    let mut s1 = 0.0;
    let mut s2 = 0.0;
    
    for &sample in samples {
        s0 = sample + coeff * s1 - s2;
        s2 = s1;
        s1 = s0;
    }
    
    // Power
    s1 * s1 + s2 * s2 - coeff * s1 * s2
}

/// Decision with hysteresis
fn decide(score: f64, tau: f64, band: f64) -> NoiseDecision {
    if score > tau + band / 2.0 {
        NoiseDecision::Fast
    } else if score < tau - band / 2.0 {
        NoiseDecision::Deep
    } else {
        NoiseDecision::Ambiguous
    }
}

/// Segment data into spans
fn segment_data(data: &[u8], config: &PxConfig) -> Vec<NoiseSpan> {
    let window_size = 2048.min(data.len());
    let step = window_size * 3 / 4;
    
    let mut spans = Vec::new();
    let mut pos = 0;
    
    while pos < data.len() {
        let end = (pos + window_size).min(data.len());
        let window = &data[pos..end];
        
        let n2 = compute_n2_entropy(window);
        let n3 = compute_n3_lz_hint(window);
        let n5 = compute_n5_format(window);
        
        let score = robust_median(&[n2, n3, n5]);
        let decision = decide(score, config.tau_noise, config.hysteresis_band);
        
        spans.push(NoiseSpan {
            start: pos,
            end,
            score,
            decision,
        });
        
        pos += step;
    }
    
    // Merge adjacent spans with same decision
    merge_spans(spans)
}

fn merge_spans(spans: Vec<NoiseSpan>) -> Vec<NoiseSpan> {
    if spans.is_empty() {
        return spans;
    }
    
    let mut merged = Vec::new();
    let mut current = spans[0].clone();
    
    for span in spans.into_iter().skip(1) {
        if span.decision == current.decision && span.start <= current.end {
            current.end = span.end;
            current.score = (current.score + span.score) / 2.0;
        } else {
            merged.push(current);
            current = span;
        }
    }
    merged.push(current);
    
    merged
}

fn robust_median(values: &[f64]) -> f64 {
    if values.is_empty() {
        return 0.0;
    }
    
    let mut sorted = values.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    
    let mid = sorted.len() / 2;
    if sorted.len() % 2 == 0 {
        (sorted[mid - 1] + sorted[mid]) / 2.0
    } else {
        sorted[mid]
    }
}

/// Rolling noise analyzer for streaming
pub struct RollingNoiseAnalyzer {
    /// Rolling entropy histogram
    histogram: [u64; 256],
    /// Total samples
    total: u64,
    /// Rolling hash state
    hash_state: RollingHash,
    /// Window buffer
    buffer: VecDeque<u8>,
    /// Window size
    window_size: usize,
    /// Configuration
    config: PxConfig,
}

struct RollingHash {
    hash: u64,
    pow: u64,
}

impl RollingNoiseAnalyzer {
    pub fn new(window_size: usize, config: PxConfig) -> Self {
        Self {
            histogram: [0; 256],
            total: 0,
            hash_state: RollingHash { hash: 0, pow: 1 },
            buffer: VecDeque::with_capacity(window_size),
            window_size,
            config,
        }
    }
    
    /// Update with new byte, return current noise score
    pub fn update(&mut self, byte: u8) -> f64 {
        // Update histogram
        self.histogram[byte as usize] += 1;
        self.total += 1;
        
        // Add to buffer
        self.buffer.push_back(byte);
        
        // Remove old byte if window full
        if self.buffer.len() > self.window_size {
            if let Some(old) = self.buffer.pop_front() {
                if self.histogram[old as usize] > 0 {
                    self.histogram[old as usize] -= 1;
                    self.total -= 1;
                }
            }
        }
        
        // Compute current entropy
        self.current_entropy()
    }
    
    fn current_entropy(&self) -> f64 {
        if self.total == 0 {
            return 1.0;
        }
        
        let mut entropy = 0.0;
        for &count in &self.histogram {
            if count > 0 {
                let p = count as f64 / self.total as f64;
                entropy -= p * p.log2();
            }
        }
        
        entropy / 8.0
    }
    
    /// Get current decision
    pub fn decide(&self) -> NoiseDecision {
        let score = self.current_entropy();
        decide(score, self.config.tau_noise, self.config.hysteresis_band)
    }
    
    /// Reset state
    pub fn reset(&mut self) {
        self.histogram = [0; 256];
        self.total = 0;
        self.buffer.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_entropy() {
        let uniform: Vec<u8> = (0..=255).collect();
        let constant = vec![42u8; 256];
        
        let h_uniform = compute_n2_entropy(&uniform);
        let h_constant = compute_n2_entropy(&constant);
        
        assert!(h_uniform > 0.9); // High entropy
        assert!(h_constant < 0.1); // Low entropy
    }
    
    #[test]
    fn test_format_detection() {
        let json = b"{\"key\": \"value\"}";
        let random: Vec<u8> = (0..100).map(|i| (i * 17 + 31) as u8).collect();
        
        let f_json = compute_n5_format(json);
        let f_random = compute_n5_format(&random);
        
        assert!(f_json < f_random);
    }
    
    #[test]
    fn test_analyze_noise() {
        let config = PxConfig::default();
        
        // Structured data
        let json = b"{\"name\": \"test\", \"value\": 42}";
        let result = analyze_noise(json, &config);
        assert!(result.score < 0.7);
        
        // Random-like data
        let random: Vec<u8> = (0..1000).map(|i| ((i * 17 + 31) ^ (i * 13)) as u8).collect();
        let result = analyze_noise(&random, &config);
        assert!(result.score > 0.5);
    }
    
    #[test]
    fn test_rolling_analyzer() {
        let config = PxConfig::default();
        let mut analyzer = RollingNoiseAnalyzer::new(256, config);
        
        // Feed constant data
        for _ in 0..256 {
            analyzer.update(42);
        }
        
        let decision = analyzer.decide();
        assert_eq!(decision, NoiseDecision::Deep); // Constant = not noise
    }
}
