//! # SBE (Stochastic Budget Exploration) Module
//! 
//! Self-limiting budget allocation based on marginal gain.
//! Implements the "grow while it pays" philosophy.

use crate::PxConfig;
use std::time::{Duration, Instant};

/// SBE Controller
pub struct SbeController {
    config: PxConfig,
    /// Current budget (tokens/ms)
    current_budget: u64,
    /// Base budget
    base_budget: u64,
    /// Budget multiplier (from homeostasis)
    multiplier: f64,
    /// Gain history (for bandit learning)
    gain_history: Vec<GainSample>,
    /// Current τ_climb threshold
    tau_climb: f64,
    /// Current τ_fall threshold
    tau_fall: f64,
    /// Bandit state for threshold learning
    bandit: ThresholdBandit,
    /// Last J value for gain computation
    last_j: f64,
    /// Last timestamp
    last_time: Instant,
    /// Cumulative gain
    cumulative_gain: f64,
    /// Rollback point
    rollback_phi_id: Option<uuid::Uuid>,
}

#[derive(Debug, Clone)]
struct GainSample {
    gain: f64,
    delta_t: Duration,
    budget_used: u64,
    timestamp: Instant,
}

impl SbeController {
    pub fn new(config: &PxConfig) -> Self {
        Self {
            base_budget: config.budget_per_window,
            current_budget: config.budget_per_window,
            multiplier: 1.0,
            gain_history: Vec::with_capacity(100),
            tau_climb: config.tau_j,
            tau_fall: config.tau_j * 0.5,
            bandit: ThresholdBandit::new(),
            last_j: 0.0,
            last_time: Instant::now(),
            cumulative_gain: 0.0,
            rollback_phi_id: None,
            config: config.clone(),
        }
    }
    
    /// Update with new result
    pub fn update(&mut self, result: &crate::InternalResult) {
        let now = Instant::now();
        let delta_t = now.duration_since(self.last_time);
        
        // Compute gain
        let gain = if self.last_j > 0.0 {
            (self.last_j - result.j_score) / delta_t.as_secs_f64().max(0.001)
        } else {
            0.0
        };
        
        // Record sample
        self.gain_history.push(GainSample {
            gain,
            delta_t,
            budget_used: self.current_budget,
            timestamp: now,
        });
        
        // Trim old history
        if self.gain_history.len() > 100 {
            self.gain_history.remove(0);
        }
        
        // Update bandit
        self.bandit.update(gain, self.tau_climb);
        
        // Update thresholds
        let (new_climb, new_fall) = self.bandit.suggest_thresholds();
        self.tau_climb = new_climb.clamp(0.001, 0.1);
        self.tau_fall = new_fall.clamp(0.0005, 0.05);
        
        // Decide whether to widen or contract budget
        if gain >= self.tau_climb && self.should_widen() {
            self.widen_budget();
        } else if gain < self.tau_fall {
            self.contract_budget();
        }
        
        self.last_j = result.j_score;
        self.last_time = now;
        self.cumulative_gain += gain.max(0.0);
    }
    
    /// Check if widening is safe
    fn should_widen(&self) -> bool {
        // Check recent trend
        if self.gain_history.len() < 3 {
            return true;
        }
        
        let recent: Vec<_> = self.gain_history.iter().rev().take(3).collect();
        let avg_gain: f64 = recent.iter().map(|s| s.gain).sum::<f64>() / recent.len() as f64;
        
        // Only widen if recent gains are positive
        avg_gain > 0.0
    }
    
    /// Increase budget
    fn widen_budget(&mut self) {
        let growth = 1.2;
        self.current_budget = ((self.current_budget as f64 * growth) as u64)
            .min(self.base_budget * 10);
    }
    
    /// Decrease budget
    fn contract_budget(&mut self) {
        let shrink = 0.9;
        self.current_budget = ((self.current_budget as f64 * shrink) as u64)
            .max(self.base_budget / 10);
    }
    
    /// Get current budget
    pub fn current_budget(&self) -> u64 {
        (self.current_budget as f64 * self.multiplier) as u64
    }
    
    /// Set budget multiplier (from homeostasis)
    pub fn set_budget_multiplier(&mut self, multiplier: f64) {
        self.multiplier = multiplier.clamp(0.1, 2.0);
    }
    
    /// Get τ_climb threshold
    pub fn tau_climb(&self) -> f64 {
        self.tau_climb
    }
    
    /// Get τ_fall threshold
    pub fn tau_fall(&self) -> f64 {
        self.tau_fall
    }
    
    /// Get median gain
    pub fn median_gain(&self) -> f64 {
        if self.gain_history.is_empty() {
            return 0.0;
        }
        
        let mut gains: Vec<f64> = self.gain_history.iter().map(|s| s.gain).collect();
        gains.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        
        let mid = gains.len() / 2;
        if gains.len() % 2 == 0 {
            (gains[mid - 1] + gains[mid]) / 2.0
        } else {
            gains[mid]
        }
    }
    
    /// Reset to base budget
    pub fn reset(&mut self) {
        self.current_budget = self.base_budget;
        self.multiplier = 1.0;
        self.gain_history.clear();
        self.cumulative_gain = 0.0;
    }
    
    /// Set rollback point
    pub fn set_rollback(&mut self, phi_id: uuid::Uuid) {
        self.rollback_phi_id = Some(phi_id);
    }
    
    /// Get rollback point
    pub fn rollback_phi_id(&self) -> Option<uuid::Uuid> {
        self.rollback_phi_id
    }
}

/// Bandit for threshold learning
struct ThresholdBandit {
    /// Arms: different threshold values
    arms: Vec<ThresholdArm>,
    /// Current best arm index
    best_arm: usize,
    /// Exploration parameter
    epsilon: f64,
}

struct ThresholdArm {
    tau_climb: f64,
    tau_fall: f64,
    reward_sum: f64,
    pull_count: u32,
}

impl ThresholdBandit {
    fn new() -> Self {
        // Initialize with different threshold pairs
        let arms = vec![
            ThresholdArm { tau_climb: 0.005, tau_fall: 0.002, reward_sum: 0.0, pull_count: 0 },
            ThresholdArm { tau_climb: 0.01, tau_fall: 0.005, reward_sum: 0.0, pull_count: 0 },
            ThresholdArm { tau_climb: 0.02, tau_fall: 0.01, reward_sum: 0.0, pull_count: 0 },
            ThresholdArm { tau_climb: 0.05, tau_fall: 0.02, reward_sum: 0.0, pull_count: 0 },
        ];
        
        Self {
            arms,
            best_arm: 1, // Start with middle option
            epsilon: 0.1,
        }
    }
    
    fn update(&mut self, gain: f64, _current_tau: f64) {
        // Update current arm
        let arm = &mut self.arms[self.best_arm];
        arm.reward_sum += gain;
        arm.pull_count += 1;
        
        // Find best arm (UCB1)
        let total_pulls: u32 = self.arms.iter().map(|a| a.pull_count).sum();
        
        if total_pulls > 0 {
            let mut best_ucb = f64::NEG_INFINITY;
            
            for (i, arm) in self.arms.iter().enumerate() {
                if arm.pull_count == 0 {
                    self.best_arm = i;
                    return;
                }
                
                let avg = arm.reward_sum / arm.pull_count as f64;
                let exploration = (2.0 * (total_pulls as f64).ln() / arm.pull_count as f64).sqrt();
                let ucb = avg + exploration;
                
                if ucb > best_ucb {
                    best_ucb = ucb;
                    self.best_arm = i;
                }
            }
        }
    }
    
    fn suggest_thresholds(&self) -> (f64, f64) {
        let arm = &self.arms[self.best_arm];
        (arm.tau_climb, arm.tau_fall)
    }
}

/// Budget allocation result
#[derive(Debug, Clone)]
pub struct BudgetAllocation {
    pub budget_ms: u64,
    pub expected_gain: f64,
    pub confidence: f64,
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_sbe_creation() {
        let config = PxConfig::default();
        let sbe = SbeController::new(&config);
        
        assert_eq!(sbe.current_budget(), config.budget_per_window);
    }
    
    #[test]
    fn test_budget_multiplier() {
        let config = PxConfig::default();
        let mut sbe = SbeController::new(&config);
        
        sbe.set_budget_multiplier(0.5);
        assert_eq!(sbe.current_budget(), config.budget_per_window / 2);
    }
}
