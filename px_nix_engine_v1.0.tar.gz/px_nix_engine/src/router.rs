//! # Router Module
//! 
//! Routes requests between FAST and DEEP paths based on noise analysis,
//! homeostasis state, and SBE recommendations.

use crate::{PxConfig, noise, homeostasis};
use std::sync::atomic::{AtomicU64, Ordering};

/// Route decision
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Route {
    Fast,
    Deep,
}

/// Router for FAST/DEEP path selection
pub struct Router {
    config: PxConfig,
    /// Target percentage of DEEP routes
    deep_target: f64,
    /// Current DEEP percentage
    deep_rate: f64,
    /// Total requests
    total_count: AtomicU64,
    /// DEEP requests
    deep_count: AtomicU64,
    /// Force FAST only mode
    fast_only: bool,
    /// Keywords that force DEEP
    force_deep_keywords: Vec<String>,
    /// Length threshold for DEEP
    len_threshold: usize,
    /// Similarity threshold for FAST
    fast_similarity: f64,
}

impl Router {
    pub fn new(config: &PxConfig) -> Self {
        Self {
            config: config.clone(),
            deep_target: config.deep_target_max,
            deep_rate: 0.0,
            total_count: AtomicU64::new(0),
            deep_count: AtomicU64::new(0),
            fast_only: false,
            force_deep_keywords: vec![
                "strategic".into(),
                "impact".into(),
                "audit".into(),
                "policy".into(),
            ],
            len_threshold: 220,
            fast_similarity: 0.6,
        }
    }
    
    /// Decide route based on input and state
    pub fn decide(
        &mut self, 
        input: &[u8], 
        noise_result: &noise::NoiseResult,
        homeostasis: &homeostasis::HomeostasisState,
    ) -> Route {
        // Emergency mode: force FAST
        if self.fast_only {
            return Route::Fast;
        }
        
        // Circuit breaker open: force FAST
        if homeostasis.circuit_breaker.is_open {
            return Route::Fast;
        }
        
        // Noise-first decision
        match noise_result.decision {
            noise::NoiseDecision::Fast => return Route::Fast,
            noise::NoiseDecision::Deep => {}
            noise::NoiseDecision::Ambiguous => {
                // Use additional heuristics for ambiguous cases
                if self.should_go_deep_ambiguous(input, homeostasis) {
                    // Continue to DEEP checks
                } else {
                    return Route::Fast;
                }
            }
        }
        
        // Check if we're over budget for DEEP
        if self.deep_rate > self.deep_target * 1.2 {
            return Route::Fast;
        }
        
        // Check for force-DEEP keywords
        if self.has_force_deep_keywords(input) {
            return self.record_route(Route::Deep);
        }
        
        // Check length threshold
        if input.len() >= self.len_threshold {
            return self.record_route(Route::Deep);
        }
        
        // High hormone stress: prefer FAST
        if homeostasis.hormones.h_perf > 0.7 {
            return Route::Fast;
        }
        
        // Default: based on noise score
        if noise_result.score < self.config.tau_noise - self.config.hysteresis_band {
            self.record_route(Route::Deep)
        } else {
            Route::Fast
        }
    }
    
    fn should_go_deep_ambiguous(&self, input: &[u8], homeostasis: &homeostasis::HomeostasisState) -> bool {
        // In ambiguous cases, lean toward DEEP if:
        // 1. System is not stressed
        // 2. Input is long enough
        // 3. We're under DEEP budget
        
        homeostasis.hormones.h_perf < 0.5 
            && input.len() >= self.len_threshold / 2
            && self.deep_rate < self.deep_target
    }
    
    fn has_force_deep_keywords(&self, input: &[u8]) -> bool {
        if let Ok(text) = std::str::from_utf8(input) {
            let lower = text.to_lowercase();
            self.force_deep_keywords.iter().any(|kw| lower.contains(kw))
        } else {
            false
        }
    }
    
    fn record_route(&mut self, route: Route) -> Route {
        self.total_count.fetch_add(1, Ordering::Relaxed);
        
        if matches!(route, Route::Deep) {
            self.deep_count.fetch_add(1, Ordering::Relaxed);
        }
        
        // Update rate
        let total = self.total_count.load(Ordering::Relaxed);
        let deep = self.deep_count.load(Ordering::Relaxed);
        
        if total > 0 {
            self.deep_rate = deep as f64 / total as f64;
        }
        
        route
    }
    
    /// Get current DEEP target
    pub fn deep_target(&self) -> f64 {
        self.deep_target
    }
    
    /// Set DEEP target
    pub fn set_deep_target(&mut self, target: f64) {
        self.deep_target = target.clamp(0.05, 1.0);
    }
    
    /// Get current DEEP rate
    pub fn deep_rate(&self) -> f64 {
        self.deep_rate
    }
    
    /// Force FAST only mode
    pub fn force_fast_only(&mut self) {
        self.fast_only = true;
    }
    
    /// Release from FAST only mode
    pub fn release_fast_only(&mut self) {
        self.fast_only = false;
    }
    
    /// Reset counters
    pub fn reset_counters(&mut self) {
        self.total_count.store(0, Ordering::Relaxed);
        self.deep_count.store(0, Ordering::Relaxed);
        self.deep_rate = 0.0;
    }
    
    /// Add force-DEEP keyword
    pub fn add_force_keyword(&mut self, keyword: String) {
        self.force_deep_keywords.push(keyword);
    }
}

/// Route decision with explanation
#[derive(Debug, Clone)]
pub struct RouteDecision {
    pub route: Route,
    pub reason: Vec<String>,
    pub noise_score: f64,
    pub deep_target: f64,
    pub deep_rate: f64,
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_router_creation() {
        let config = PxConfig::default();
        let router = Router::new(&config);
        
        assert!(router.deep_target > 0.0);
        assert!(!router.fast_only);
    }
}
