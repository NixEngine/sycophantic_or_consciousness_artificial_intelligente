//! # Ledger Module (WORM Audit Log)
//! 
//! Immutable, append-only ledger for auditability.
//! Hash-chained entries with cryptographic integrity.

use crate::{PxConfig, PxError, router, sbe, homeostasis};
use blake3::Hasher;
use uuid::Uuid;
use std::fs::{File, OpenOptions};
use std::io::{Write, BufWriter, BufRead, BufReader};
use std::path::PathBuf;

/// Ledger event
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub enum Event {
    RouteDecision {
        trace_id: Uuid,
        route: router::Route,
        noise_score: f64,
        timestamp: String,
    },
    SbeUpdate {
        trace_id: Uuid,
        budget_before: u64,
        budget_after: u64,
        gain: f64,
        timestamp: String,
    },
    HomeostasisTick {
        hormones: SerializableHormones,
        mode: String,
        timestamp: String,
    },
    TransformApplied {
        trace_id: Uuid,
        phi_id: Uuid,
        j_before: f64,
        j_after: f64,
        timestamp: String,
    },
    CouncilDecision {
        trace_id: Uuid,
        decision_id: Uuid,
        final_decision: String,
        approve_ratio: f64,
        timestamp: String,
    },
    MemoryPromotion {
        trace_id: Uuid,
        item_id: Uuid,
        roi: f32,
        timestamp: String,
    },
    EthosCheck {
        trace_id: Uuid,
        status: String,
        ethos_min: f64,
        timestamp: String,
    },
    SnapshotCreated {
        snapshot_id: String,
        context: String,
        timestamp: String,
    },
    Error {
        trace_id: Option<Uuid>,
        error: String,
        timestamp: String,
    },
    Custom {
        kind: String,
        data: serde_json::Value,
        timestamp: String,
    },
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct SerializableHormones {
    pub h_perf: f64,
    pub h_quality: f64,
    pub h_safety: f64,
}

impl From<homeostasis::Hormones> for SerializableHormones {
    fn from(h: homeostasis::Hormones) -> Self {
        Self {
            h_perf: h.h_perf,
            h_quality: h.h_quality,
            h_safety: h.h_safety,
        }
    }
}

/// Ledger entry (hash-chained)
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct LedgerEntry {
    pub sequence: u64,
    pub event: Event,
    pub prev_hash: String,
    pub hash: String,
    pub timestamp: String,
}

/// WORM Ledger
pub struct Ledger {
    config: PxConfig,
    /// File path
    path: PathBuf,
    /// Current sequence number
    sequence: u64,
    /// Previous hash
    prev_hash: String,
    /// Writer (buffered)
    writer: Option<BufWriter<File>>,
    /// In-memory buffer for fast queries
    recent_entries: std::collections::VecDeque<LedgerEntry>,
    /// Max recent entries
    max_recent: usize,
    /// Rotation size (bytes)
    rotate_bytes: u64,
    /// Current file size
    current_size: u64,
    /// Snapshots
    snapshots: hashbrown::HashMap<String, LedgerSnapshot>,
}

impl Ledger {
    pub fn new(config: &PxConfig) -> Self {
        let path = PathBuf::from("./data/ledger.jsonl");
        
        // Ensure directory exists
        if let Some(parent) = path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        
        // Open or create file
        let (writer, sequence, prev_hash, current_size) = match OpenOptions::new()
            .create(true)
            .append(true)
            .open(&path) 
        {
            Ok(file) => {
                let size = file.metadata().map(|m| m.len()).unwrap_or(0);
                let (seq, hash) = Self::read_last_entry(&path).unwrap_or((0, "GENESIS".into()));
                (Some(BufWriter::new(file)), seq, hash, size)
            }
            Err(_) => (None, 0, "GENESIS".into(), 0),
        };
        
        Self {
            config: config.clone(),
            path,
            sequence,
            prev_hash,
            writer,
            recent_entries: std::collections::VecDeque::with_capacity(1000),
            max_recent: 1000,
            rotate_bytes: 20 * 1024 * 1024, // 20MB
            current_size,
            snapshots: hashbrown::HashMap::new(),
        }
    }
    
    /// Read last entry from file
    fn read_last_entry(path: &PathBuf) -> Option<(u64, String)> {
        let file = File::open(path).ok()?;
        let reader = BufReader::new(file);
        let mut last_line = None;
        
        for line in reader.lines().flatten() {
            if !line.trim().is_empty() {
                last_line = Some(line);
            }
        }
        
        let line = last_line?;
        let entry: LedgerEntry = serde_json::from_str(&line).ok()?;
        Some((entry.sequence, entry.hash))
    }
    
    /// Append event
    pub fn append_event(&mut self, event: Event) -> LedgerEntry {
        self.sequence += 1;
        
        let timestamp = crate::utils::now_iso();
        
        // Compute hash
        let mut hasher = Hasher::new();
        hasher.update(self.sequence.to_le_bytes().as_slice());
        hasher.update(self.prev_hash.as_bytes());
        hasher.update(serde_json::to_string(&event).unwrap_or_default().as_bytes());
        let hash = hasher.finalize().to_hex().to_string();
        
        let entry = LedgerEntry {
            sequence: self.sequence,
            event,
            prev_hash: self.prev_hash.clone(),
            hash: hash.clone(),
            timestamp,
        };
        
        // Write to file
        if let Some(writer) = &mut self.writer {
            let json = serde_json::to_string(&entry).unwrap_or_default();
            let bytes = format!("{}\n", json);
            let _ = writer.write_all(bytes.as_bytes());
            let _ = writer.flush();
            self.current_size += bytes.len() as u64;
            
            // Check rotation
            if self.current_size >= self.rotate_bytes {
                self.rotate();
            }
        }
        
        // Update state
        self.prev_hash = hash;
        
        // Add to recent
        self.recent_entries.push_back(entry.clone());
        if self.recent_entries.len() > self.max_recent {
            self.recent_entries.pop_front();
        }
        
        entry
    }
    
    /// Rotate log file
    fn rotate(&mut self) {
        if let Some(mut writer) = self.writer.take() {
            let _ = writer.flush();
        }
        
        // Rename current file
        let timestamp = crate::utils::now_iso().replace([':', '.'], "-");
        let rotated_path = self.path.with_extension(format!("{}.rotated", timestamp));
        let _ = std::fs::rename(&self.path, &rotated_path);
        
        // Create new file
        if let Ok(file) = OpenOptions::new()
            .create(true)
            .append(true)
            .open(&self.path) 
        {
            self.writer = Some(BufWriter::new(file));
            self.current_size = 0;
        }
    }
    
    /// Get recent entries
    pub fn recent(&self, count: usize) -> Vec<&LedgerEntry> {
        self.recent_entries.iter()
            .rev()
            .take(count)
            .collect()
    }
    
    /// Query entries by trace_id
    pub fn query_trace(&self, trace_id: Uuid) -> Vec<&LedgerEntry> {
        self.recent_entries.iter()
            .filter(|e| match &e.event {
                Event::RouteDecision { trace_id: tid, .. } => *tid == trace_id,
                Event::SbeUpdate { trace_id: tid, .. } => *tid == trace_id,
                Event::TransformApplied { trace_id: tid, .. } => *tid == trace_id,
                Event::CouncilDecision { trace_id: tid, .. } => *tid == trace_id,
                Event::MemoryPromotion { trace_id: tid, .. } => *tid == trace_id,
                Event::EthosCheck { trace_id: tid, .. } => *tid == trace_id,
                Event::Error { trace_id: Some(tid), .. } => *tid == trace_id,
                _ => false,
            })
            .collect()
    }
    
    /// Verify integrity
    pub fn verify_integrity(&self) -> Result<(), String> {
        let mut prev_hash = "GENESIS".to_string();
        let mut prev_seq = 0u64;
        
        let file = File::open(&self.path).map_err(|e| e.to_string())?;
        let reader = BufReader::new(file);
        
        for line in reader.lines() {
            let line = line.map_err(|e| e.to_string())?;
            if line.trim().is_empty() {
                continue;
            }
            
            let entry: LedgerEntry = serde_json::from_str(&line)
                .map_err(|e| format!("Parse error: {}", e))?;
            
            // Check sequence
            if entry.sequence != prev_seq + 1 {
                return Err(format!("Sequence gap: {} -> {}", prev_seq, entry.sequence));
            }
            
            // Check prev_hash
            if entry.prev_hash != prev_hash {
                return Err(format!("Hash chain broken at {}", entry.sequence));
            }
            
            // Verify hash
            let mut hasher = Hasher::new();
            hasher.update(entry.sequence.to_le_bytes().as_slice());
            hasher.update(entry.prev_hash.as_bytes());
            hasher.update(serde_json::to_string(&entry.event).unwrap_or_default().as_bytes());
            let computed_hash = hasher.finalize().to_hex().to_string();
            
            if entry.hash != computed_hash {
                return Err(format!("Hash mismatch at {}", entry.sequence));
            }
            
            prev_hash = entry.hash;
            prev_seq = entry.sequence;
        }
        
        Ok(())
    }
    
    /// Create snapshot
    pub fn create_snapshot(&mut self, snapshot_id: &str, context: &str) {
        let snapshot = LedgerSnapshot {
            id: snapshot_id.to_string(),
            sequence: self.sequence,
            prev_hash: self.prev_hash.clone(),
            context: context.to_string(),
            timestamp: crate::utils::now_iso(),
        };
        
        self.snapshots.insert(snapshot_id.to_string(), snapshot.clone());
        
        self.append_event(Event::SnapshotCreated {
            snapshot_id: snapshot_id.to_string(),
            context: context.to_string(),
            timestamp: crate::utils::now_iso(),
        });
    }
    
    /// Restore from snapshot (rollback to state)
    pub fn restore_snapshot(
        &mut self, 
        snapshot_id: &str,
        router: &mut router::Router,
        sbe: &mut sbe::SbeController,
        homeostasis: &mut homeostasis::HomeostasisController,
    ) -> Result<(), PxError> {
        let snapshot = self.snapshots.get(snapshot_id)
            .ok_or_else(|| PxError::InvalidInput(format!("Snapshot not found: {}", snapshot_id)))?
            .clone();
        
        // Restore context-based settings
        if let Some(context) = snapshot.context.split(':').next() {
            homeostasis.restore_snapshot(context);
        }
        
        // Log restoration
        self.append_event(Event::Custom {
            kind: "snapshot_restored".into(),
            data: serde_json::json!({
                "snapshot_id": snapshot_id,
                "restored_sequence": snapshot.sequence,
            }),
            timestamp: crate::utils::now_iso(),
        });
        
        Ok(())
    }
    
    /// Get stats
    pub fn stats(&self) -> LedgerStats {
        LedgerStats {
            total_entries: self.sequence,
            file_size_bytes: self.current_size,
            recent_count: self.recent_entries.len(),
            snapshot_count: self.snapshots.len(),
        }
    }
}

/// Ledger snapshot
#[derive(Debug, Clone)]
struct LedgerSnapshot {
    id: String,
    sequence: u64,
    prev_hash: String,
    context: String,
    timestamp: String,
}

/// Ledger statistics
#[derive(Debug, Clone)]
pub struct LedgerStats {
    pub total_entries: u64,
    pub file_size_bytes: u64,
    pub recent_count: usize,
    pub snapshot_count: usize,
}

/// Export format for auditing
#[derive(Debug, serde::Serialize)]
pub struct AuditExport {
    pub entries: Vec<LedgerEntry>,
    pub stats: LedgerStats,
    pub integrity_verified: bool,
    pub export_timestamp: String,
}

impl Ledger {
    /// Export for audit
    pub fn export_audit(&self, max_entries: usize) -> AuditExport {
        let entries: Vec<LedgerEntry> = self.recent_entries.iter()
            .rev()
            .take(max_entries)
            .cloned()
            .collect();
        
        let integrity_verified = self.verify_integrity().is_ok();
        
        AuditExport {
            entries,
            stats: self.stats(),
            integrity_verified,
            export_timestamp: crate::utils::now_iso(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_ledger_append() {
        let config = PxConfig::default();
        let mut ledger = Ledger::new(&config);
        
        let entry = ledger.append_event(Event::Custom {
            kind: "test".into(),
            data: serde_json::json!({"foo": "bar"}),
            timestamp: crate::utils::now_iso(),
        });
        
        assert_eq!(entry.sequence, ledger.sequence);
        assert!(!entry.hash.is_empty());
    }
    
    #[test]
    fn test_hash_chain() {
        let config = PxConfig::default();
        let mut ledger = Ledger::new(&config);
        
        let e1 = ledger.append_event(Event::Custom {
            kind: "test1".into(),
            data: serde_json::json!({}),
            timestamp: crate::utils::now_iso(),
        });
        
        let e2 = ledger.append_event(Event::Custom {
            kind: "test2".into(),
            data: serde_json::json!({}),
            timestamp: crate::utils::now_iso(),
        });
        
        assert_eq!(e2.prev_hash, e1.hash);
    }
}
