//! # Android/JNI Module
//! 
//! JNI bindings for Android integration, optimized for Galaxy S25.
//! 
//! ## Features
//! - JNI bindings for Java/Kotlin interop
//! - NEON SIMD optimizations for ARM64
//! - Battery/thermal awareness
//! - Background processing support

#![cfg(feature = "android")]

use crate::{PxConfig, PxEngine, PxError, DeviceType, ProcessResult};
use jni::JNIEnv;
use jni::objects::{JClass, JObject, JString, JValue};
use jni::sys::{jlong, jbyteArray, jfloat, jint, jboolean, jobject};
use std::sync::Mutex;

/// Global engine instance (thread-safe)
static ENGINE: Mutex<Option<PxEngine>> = Mutex::new(None);

/// Initialize the Px/Nix Engine
/// 
/// JNI Signature: void nativeInit(long configPtr)
#[no_mangle]
pub extern "system" fn Java_com_pxnix_engine_PxNixEngine_nativeInit(
    mut env: JNIEnv,
    _class: JClass,
) {
    let config = PxConfig {
        device_type: DeviceType::Mobile,
        enable_simd: true,
        enable_parallel: true,
        max_concurrent: 4, // Galaxy S25 has multiple cores
        budget_per_window: 500, // Conservative for mobile
        p95_target_ms: 50, // Tighter target for mobile responsiveness
        ..PxConfig::default()
    };
    
    let engine = PxEngine::with_config(config);
    
    let mut guard = ENGINE.lock().unwrap();
    *guard = Some(engine);
}

/// Process input data
/// 
/// JNI Signature: ProcessResult nativeProcess(byte[] input)
#[no_mangle]
pub extern "system" fn Java_com_pxnix_engine_PxNixEngine_nativeProcess<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    input: jbyteArray,
) -> jobject {
    let input_bytes = match env.convert_byte_array(input) {
        Ok(bytes) => bytes,
        Err(_) => {
            throw_exception(&mut env, "Failed to convert input bytes");
            return std::ptr::null_mut();
        }
    };
    
    let mut guard = ENGINE.lock().unwrap();
    let engine = match guard.as_mut() {
        Some(e) => e,
        None => {
            throw_exception(&mut env, "Engine not initialized");
            return std::ptr::null_mut();
        }
    };
    
    match engine.process(&input_bytes) {
        Ok(result) => create_result_object(&mut env, &result),
        Err(e) => {
            throw_exception(&mut env, &format!("Processing error: {}", e));
            std::ptr::null_mut()
        }
    }
}

/// Get engine state
/// 
/// JNI Signature: EngineState nativeGetState()
#[no_mangle]
pub extern "system" fn Java_com_pxnix_engine_PxNixEngine_nativeGetState<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jobject {
    let guard = ENGINE.lock().unwrap();
    let engine = match guard.as_ref() {
        Some(e) => e,
        None => {
            throw_exception(&mut env, "Engine not initialized");
            return std::ptr::null_mut();
        }
    };
    
    let state = engine.state();
    create_state_object(&mut env, &state)
}

/// Trigger homeostasis tick
/// 
/// JNI Signature: void nativeTick()
#[no_mangle]
pub extern "system" fn Java_com_pxnix_engine_PxNixEngine_nativeTick(
    mut env: JNIEnv,
    _class: JClass,
) {
    let mut guard = ENGINE.lock().unwrap();
    if let Some(engine) = guard.as_mut() {
        engine.tick();
    }
}

/// Update thermal/battery state from Android
/// 
/// JNI Signature: void nativeUpdateEnvironment(float temperature, float batteryLevel)
#[no_mangle]
pub extern "system" fn Java_com_pxnix_engine_PxNixEngine_nativeUpdateEnvironment(
    _env: JNIEnv,
    _class: JClass,
    temperature: jfloat,
    battery_level: jfloat,
) {
    let mut guard = ENGINE.lock().unwrap();
    if let Some(_engine) = guard.as_mut() {
        // Update internal state based on environmental factors
        // This would trigger mode changes (Normal -> EcoMode, etc.)
        
        if battery_level < 0.15 || temperature > 40.0 {
            // Trigger eco mode
            // engine.set_mode(OperatingMode::EcoMode);
        }
    }
}

/// Shutdown the engine
/// 
/// JNI Signature: void nativeShutdown()
#[no_mangle]
pub extern "system" fn Java_com_pxnix_engine_PxNixEngine_nativeShutdown(
    _env: JNIEnv,
    _class: JClass,
) {
    let mut guard = ENGINE.lock().unwrap();
    *guard = None;
}

/// Get current J-score for quick queries
/// 
/// JNI Signature: float nativeQuickScore(byte[] input)
#[no_mangle]
pub extern "system" fn Java_com_pxnix_engine_PxNixEngine_nativeQuickScore(
    mut env: JNIEnv,
    _class: JClass,
    input: jbyteArray,
) -> jfloat {
    let input_bytes = match env.convert_byte_array(input) {
        Ok(bytes) => bytes,
        Err(_) => return -1.0,
    };
    
    // Quick J-score computation without full processing
    let l_data = input_bytes.len() as f64 * 8.0;
    let compressed = lz4_flex::compress_prepend_size(&input_bytes);
    let l_compressed = compressed.len() as f64 * 8.0;
    
    (l_compressed / l_data.max(1.0)) as jfloat
}

/// Check if input is likely noise (FAST path)
/// 
/// JNI Signature: boolean nativeIsNoise(byte[] input)
#[no_mangle]
pub extern "system" fn Java_com_pxnix_engine_PxNixEngine_nativeIsNoise(
    mut env: JNIEnv,
    _class: JClass,
    input: jbyteArray,
) -> jboolean {
    let input_bytes = match env.convert_byte_array(input) {
        Ok(bytes) => bytes,
        Err(_) => return 0,
    };
    
    // Quick noise detection
    let config = PxConfig::default();
    let result = crate::noise::analyze_noise(&input_bytes, &config);
    
    if result.score > config.tau_noise {
        1 // true
    } else {
        0 // false
    }
}

// Helper functions

fn throw_exception(env: &mut JNIEnv, message: &str) {
    let _ = env.throw_new("java/lang/RuntimeException", message);
}

fn create_result_object<'local>(env: &mut JNIEnv<'local>, result: &ProcessResult) -> jobject {
    // Create ProcessResult Java object
    let class = match env.find_class("com/pxnix/engine/ProcessResult") {
        Ok(c) => c,
        Err(_) => return std::ptr::null_mut(),
    };
    
    // Create trace_id string
    let trace_id = match env.new_string(result.trace_id.to_string()) {
        Ok(s) => s,
        Err(_) => return std::ptr::null_mut(),
    };
    
    // Create route string
    let route_str = match result.route {
        crate::router::Route::Fast => "FAST",
        crate::router::Route::Deep => "DEEP",
    };
    let route = match env.new_string(route_str) {
        Ok(s) => s,
        Err(_) => return std::ptr::null_mut(),
    };
    
    // Create output byte array
    let output = match env.byte_array_from_slice(&result.output) {
        Ok(a) => a,
        Err(_) => return std::ptr::null_mut(),
    };
    
    // Create ethos status string
    let ethos_str = format!("{:?}", result.ethos_status);
    let ethos = match env.new_string(&ethos_str) {
        Ok(s) => s,
        Err(_) => return std::ptr::null_mut(),
    };
    
    // Call constructor
    let result_obj = env.new_object(
        class,
        "(Ljava/lang/String;Ljava/lang/String;[BDDDDJLjava/lang/String;)V",
        &[
            JValue::Object(&trace_id),
            JValue::Object(&route),
            JValue::Object(&output),
            JValue::Double(result.j_score),
            JValue::Double(result.competence.k_obj),
            JValue::Double(result.competence.k_semi),
            JValue::Double(result.competence.k_subj),
            JValue::Long(result.latency_us as i64),
            JValue::Object(&ethos),
        ],
    );
    
    match result_obj {
        Ok(obj) => obj.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

fn create_state_object<'local>(env: &mut JNIEnv<'local>, state: &crate::EngineState) -> jobject {
    // Create EngineState Java object
    let class = match env.find_class("com/pxnix/engine/EngineState") {
        Ok(c) => c,
        Err(_) => return std::ptr::null_mut(),
    };
    
    let result_obj = env.new_object(
        class,
        "(DDDDJI)V",
        &[
            JValue::Double(state.hormones.h_perf),
            JValue::Double(state.hormones.h_quality),
            JValue::Double(state.hormones.h_safety),
            JValue::Double(state.deep_rate),
            JValue::Long(state.sbe_budget as i64),
            JValue::Int(state.council_size as i32),
        ],
    );
    
    match result_obj {
        Ok(obj) => obj.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

/// FFI C-compatible interface (alternative to JNI)
#[cfg(feature = "ffi")]
pub mod ffi {
    use super::*;
    use std::ffi::{CStr, CString};
    use std::os::raw::{c_char, c_void};
    
    /// Create new engine instance
    #[no_mangle]
    pub extern "C" fn px_engine_new() -> *mut c_void {
        let config = PxConfig {
            device_type: DeviceType::Mobile,
            ..PxConfig::default()
        };
        let engine = Box::new(PxEngine::with_config(config));
        Box::into_raw(engine) as *mut c_void
    }
    
    /// Destroy engine instance
    #[no_mangle]
    pub extern "C" fn px_engine_free(engine: *mut c_void) {
        if !engine.is_null() {
            unsafe {
                let _ = Box::from_raw(engine as *mut PxEngine);
            }
        }
    }
    
    /// Process data
    #[no_mangle]
    pub extern "C" fn px_engine_process(
        engine: *mut c_void,
        data: *const u8,
        len: usize,
        j_score: *mut f64,
        latency_us: *mut u64,
    ) -> i32 {
        if engine.is_null() || data.is_null() {
            return -1;
        }
        
        let engine = unsafe { &mut *(engine as *mut PxEngine) };
        let input = unsafe { std::slice::from_raw_parts(data, len) };
        
        match engine.process(input) {
            Ok(result) => {
                if !j_score.is_null() {
                    unsafe { *j_score = result.j_score };
                }
                if !latency_us.is_null() {
                    unsafe { *latency_us = result.latency_us };
                }
                0 // Success
            }
            Err(_) => -2,
        }
    }
    
    /// Trigger homeostasis tick
    #[no_mangle]
    pub extern "C" fn px_engine_tick(engine: *mut c_void) {
        if !engine.is_null() {
            let engine = unsafe { &mut *(engine as *mut PxEngine) };
            engine.tick();
        }
    }
    
    /// Get hormone values
    #[no_mangle]
    pub extern "C" fn px_engine_get_hormones(
        engine: *mut c_void,
        h_perf: *mut f64,
        h_quality: *mut f64,
        h_safety: *mut f64,
    ) {
        if engine.is_null() {
            return;
        }
        
        let engine = unsafe { &*(engine as *mut PxEngine) };
        let state = engine.state();
        
        if !h_perf.is_null() {
            unsafe { *h_perf = state.hormones.h_perf };
        }
        if !h_quality.is_null() {
            unsafe { *h_quality = state.hormones.h_quality };
        }
        if !h_safety.is_null() {
            unsafe { *h_safety = state.hormones.h_safety };
        }
    }
}

// Android-specific optimizations

/// NEON SIMD entropy computation (ARM64)
#[cfg(target_arch = "aarch64")]
pub fn neon_entropy(data: &[u8]) -> f64 {
    // Use NEON instructions for histogram computation
    // This is a placeholder - real implementation would use std::arch::aarch64
    
    let mut counts = [0u64; 256];
    for &byte in data {
        counts[byte as usize] += 1;
    }
    
    let total = data.len() as f64;
    let mut entropy = 0.0;
    
    for &count in &counts {
        if count > 0 {
            let p = count as f64 / total;
            entropy -= p * p.log2();
        }
    }
    
    entropy / 8.0
}

#[cfg(not(target_arch = "aarch64"))]
pub fn neon_entropy(data: &[u8]) -> f64 {
    crate::noise::compute_n2_entropy(data)
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_ffi_interface() {
        // This would test the FFI interface
        // Cannot test JNI without Android environment
    }
}
