//! # Px/Nix Engine CLI
//! 
//! Command-line interface for the Px/Nix Engine.

use px_nix::{PxEngine, PxConfig, DeviceType};
use std::io::{Read, Write};

fn main() {
    println!("╔══════════════════════════════════════════════════════════════╗");
    println!("║                     Px/Nix Engine v1.0                       ║");
    println!("║       Autonomous AI based on MDL (Minimum Description Length)║");
    println!("╚══════════════════════════════════════════════════════════════╝");
    println!();
    
    // Parse arguments
    let args: Vec<String> = std::env::args().collect();
    
    let config = if args.contains(&"--mobile".to_string()) {
        let mut cfg = PxConfig::default();
        cfg.device_type = DeviceType::Mobile;
        cfg.budget_per_window = 500;
        cfg.p95_target_ms = 50;
        cfg.max_concurrent = 2;
        cfg
    } else if args.contains(&"--server".to_string()) {
        let mut cfg = PxConfig::default();
        cfg.device_type = DeviceType::Server;
        cfg.budget_per_window = 5000;
        cfg.p95_target_ms = 500;
        cfg.max_concurrent = 16;
        cfg
    } else {
        PxConfig::default()
    };
    
    let mut engine = PxEngine::with_config(config);
    
    println!("Engine initialized. Configuration:");
    println!("  Device type: {:?}", engine.state().hormones.h_perf);
    println!("  Deep target: {:.1}%", engine.state().deep_rate * 100.0);
    println!("  SBE budget: {} tokens", engine.state().sbe_budget);
    println!();
    
    if args.len() > 1 && !args[1].starts_with("--") {
        // Process file
        let path = &args[1];
        match std::fs::read(path) {
            Ok(data) => {
                println!("Processing file: {} ({} bytes)", path, data.len());
                process_data(&mut engine, &data);
            }
            Err(e) => {
                eprintln!("Error reading file: {}", e);
                std::process::exit(1);
            }
        }
    } else if args.contains(&"--interactive".to_string()) {
        // Interactive mode
        interactive_mode(&mut engine);
    } else if args.contains(&"--benchmark".to_string()) {
        // Benchmark mode
        benchmark_mode(&mut engine);
    } else {
        // Read from stdin
        println!("Reading from stdin...");
        let mut data = Vec::new();
        std::io::stdin().read_to_end(&mut data).unwrap();
        
        if !data.is_empty() {
            process_data(&mut engine, &data);
        } else {
            print_help();
        }
    }
}

fn process_data(engine: &mut PxEngine, data: &[u8]) {
    let start = std::time::Instant::now();
    
    match engine.process(data) {
        Ok(result) => {
            let elapsed = start.elapsed();
            
            println!("\n╭─ Processing Result ─────────────────────────────────────────╮");
            println!("│ Trace ID:    {}                 │", result.trace_id);
            println!("│ Route:       {:?}                                         │", result.route);
            println!("│ J Score:     {:<10.6}                                   │", result.j_score);
            println!("│ Latency:     {} μs                                        │", result.latency_us);
            println!("│ Ethos:       {:?}                                      │", result.ethos_status);
            println!("╰──────────────────────────────────────────────────────────────╯");
            
            println!("\nCompetence Vector:");
            println!("  K_obj:  {:.4}", result.competence.k_obj);
            println!("  K_semi: {:.4}", result.competence.k_semi);
            println!("  K_subj: {:.4}", result.competence.k_subj);
            
            println!("\nOutput size: {} bytes", result.output.len());
            
            if data.len() > 0 {
                let compression = 1.0 - (result.output.len() as f64 / data.len() as f64);
                println!("Compression: {:.1}%", compression * 100.0);
            }
            
            println!("\nWall time: {:?}", elapsed);
        }
        Err(e) => {
            eprintln!("Error: {}", e);
        }
    }
    
    // Print engine state
    let state = engine.state();
    println!("\n╭─ Engine State ──────────────────────────────────────────────╮");
    println!("│ Hormones:                                                    │");
    println!("│   H_perf:    {:.4}                                           │", state.hormones.h_perf);
    println!("│   H_quality: {:.4}                                           │", state.hormones.h_quality);
    println!("│   H_safety:  {:.4}                                           │", state.hormones.h_safety);
    println!("│ Deep rate:   {:.2}%                                          │", state.deep_rate * 100.0);
    println!("│ Memory size: {}                                              │", state.memory_size);
    println!("│ Council:     {} avatars                                      │", state.council_size);
    println!("╰──────────────────────────────────────────────────────────────╯");
}

fn interactive_mode(engine: &mut PxEngine) {
    println!("Interactive mode. Type 'help' for commands, 'quit' to exit.");
    println!();
    
    let stdin = std::io::stdin();
    let mut stdout = std::io::stdout();
    
    loop {
        print!("px> ");
        stdout.flush().unwrap();
        
        let mut input = String::new();
        stdin.read_line(&mut input).unwrap();
        let input = input.trim();
        
        if input.is_empty() {
            continue;
        }
        
        match input {
            "quit" | "exit" | "q" => {
                println!("Goodbye!");
                break;
            }
            "help" | "h" | "?" => {
                print_interactive_help();
            }
            "state" | "s" => {
                let state = engine.state();
                println!("Engine State:");
                println!("  H_perf:    {:.4}", state.hormones.h_perf);
                println!("  H_quality: {:.4}", state.hormones.h_quality);
                println!("  H_safety:  {:.4}", state.hormones.h_safety);
                println!("  Deep rate: {:.2}%", state.deep_rate * 100.0);
                println!("  SBE budget: {}", state.sbe_budget);
                println!("  Memory: {} items", state.memory_size);
            }
            "tick" | "t" => {
                engine.tick();
                println!("Homeostasis tick executed.");
            }
            cmd if cmd.starts_with("process ") => {
                let text = cmd.strip_prefix("process ").unwrap();
                process_data(engine, text.as_bytes());
            }
            cmd if cmd.starts_with("file ") => {
                let path = cmd.strip_prefix("file ").unwrap();
                match std::fs::read(path) {
                    Ok(data) => process_data(engine, &data),
                    Err(e) => eprintln!("Error: {}", e),
                }
            }
            _ => {
                // Treat as data to process
                process_data(engine, input.as_bytes());
            }
        }
        
        println!();
    }
}

fn benchmark_mode(engine: &mut PxEngine) {
    println!("Running benchmarks...\n");
    
    // Generate test data
    let test_cases: Vec<(&str, Vec<u8>)> = vec![
        ("Empty", vec![]),
        ("Small text", b"Hello, World!".to_vec()),
        ("Medium text", b"The quick brown fox jumps over the lazy dog. ".repeat(100).to_vec()),
        ("Repetitive", vec![42u8; 10000]),
        ("Random-like", (0..10000u16).map(|i| ((i * 17 + 31) ^ (i * 13)) as u8).collect()),
        ("JSON", br#"{"name": "test", "value": 42, "nested": {"a": 1, "b": 2}}"#.repeat(50).to_vec()),
        ("Binary", (0..10000).map(|i| (i % 256) as u8).collect()),
    ];
    
    println!("╭─────────────────────┬────────┬────────────┬────────────┬─────────╮");
    println!("│ Test Case           │ Size   │ J Score    │ Latency    │ Route   │");
    println!("├─────────────────────┼────────┼────────────┼────────────┼─────────┤");
    
    for (name, data) in &test_cases {
        let start = std::time::Instant::now();
        
        match engine.process(data) {
            Ok(result) => {
                let elapsed = start.elapsed();
                println!(
                    "│ {:19} │ {:>6} │ {:>10.4} │ {:>8}μs │ {:?}    │",
                    name,
                    data.len(),
                    result.j_score,
                    result.latency_us,
                    result.route,
                );
            }
            Err(e) => {
                println!("│ {:19} │ {:>6} │ ERROR: {} │", name, data.len(), e);
            }
        }
    }
    
    println!("╰─────────────────────┴────────┴────────────┴────────────┴─────────╯");
    
    // Throughput test
    println!("\nThroughput test (1MB)...");
    let large_data = vec![42u8; 1_000_000];
    let iterations = 10;
    
    let start = std::time::Instant::now();
    for _ in 0..iterations {
        let _ = engine.process(&large_data);
    }
    let elapsed = start.elapsed();
    
    let throughput = (large_data.len() * iterations) as f64 / elapsed.as_secs_f64() / 1_000_000.0;
    println!("Throughput: {:.2} MB/s", throughput);
    
    println!("\nBenchmark complete.");
}

fn print_help() {
    println!("Px/Nix Engine - Autonomous AI based on MDL");
    println!();
    println!("Usage:");
    println!("  px_nix_cli [OPTIONS] [FILE]");
    println!("  px_nix_cli --interactive");
    println!("  echo 'data' | px_nix_cli");
    println!();
    println!("Options:");
    println!("  --interactive  Start interactive mode");
    println!("  --benchmark    Run benchmarks");
    println!("  --mobile       Use mobile-optimized settings");
    println!("  --server       Use server-optimized settings");
    println!("  --help         Show this help");
    println!();
    println!("Examples:");
    println!("  px_nix_cli data.txt");
    println!("  px_nix_cli --mobile --interactive");
    println!("  echo 'Hello, World!' | px_nix_cli");
}

fn print_interactive_help() {
    println!("Interactive Commands:");
    println!("  process <text>  Process the given text");
    println!("  file <path>     Process a file");
    println!("  state / s       Show engine state");
    println!("  tick / t        Execute homeostasis tick");
    println!("  help / h / ?    Show this help");
    println!("  quit / exit / q Exit");
    println!();
    println!("Or just type text to process it directly.");
}
