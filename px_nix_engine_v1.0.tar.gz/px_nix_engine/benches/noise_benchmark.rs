//! Noise Analysis Benchmarks for Px/Nix Engine

use criterion::{black_box, criterion_group, criterion_main, Criterion, BenchmarkId, Throughput};
use px_nix::{analyze_noise, PxConfig};

fn bench_noise_analysis(c: &mut Criterion) {
    let mut group = c.benchmark_group("noise_analysis");
    let config = PxConfig::default();
    
    // Different data sizes
    for size in [64, 256, 1024, 4096, 16384].iter() {
        let data: Vec<u8> = (0..*size).map(|i| (i % 256) as u8).collect();
        
        group.throughput(Throughput::Bytes(*size as u64));
        group.bench_with_input(BenchmarkId::new("sequential", size), &data, |b, data| {
            b.iter(|| analyze_noise(black_box(data), &config))
        });
    }
    
    group.finish();
}

fn bench_noise_types(c: &mut Criterion) {
    let mut group = c.benchmark_group("noise_types");
    let config = PxConfig::default();
    
    // Text data (should be signal)
    let text = b"The quick brown fox jumps over the lazy dog. This is a test message.";
    group.bench_function("text_signal", |b| {
        b.iter(|| analyze_noise(black_box(text.as_slice()), &config))
    });
    
    // JSON data (should be signal)
    let json = br#"{"name": "test", "value": 42, "items": [1, 2, 3, 4, 5]}"#;
    group.bench_function("json_signal", |b| {
        b.iter(|| analyze_noise(black_box(json.as_slice()), &config))
    });
    
    // Repetitive data (should be signal)
    let repetitive = vec![42u8; 1024];
    group.bench_function("repetitive_signal", |b| {
        b.iter(|| analyze_noise(black_box(&repetitive), &config))
    });
    
    // High entropy data (likely noise)
    let noise: Vec<u8> = (0..1024).map(|i| ((i * 17 + 31) ^ (i * 13) + (i * 7)) as u8).collect();
    group.bench_function("high_entropy_noise", |b| {
        b.iter(|| analyze_noise(black_box(&noise), &config))
    });
    
    // PNG header (should detect format)
    let mut png_like = vec![0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
    png_like.extend((0..1016).map(|i| (i % 256) as u8));
    group.bench_function("png_format", |b| {
        b.iter(|| analyze_noise(black_box(&png_like), &config))
    });
    
    group.finish();
}

fn bench_noise_cascade(c: &mut Criterion) {
    let mut group = c.benchmark_group("noise_cascade_stages");
    let config = PxConfig::default();
    
    // 4KB data for consistent comparison
    let data: Vec<u8> = (0..4096).map(|i| (i % 256) as u8).collect();
    
    // Benchmark N2 (entropy - should be fast)
    group.bench_function("n2_entropy", |b| {
        b.iter(|| px_nix::noise::compute_n2_entropy(black_box(&data)))
    });
    
    // Benchmark N3 (LZ hint)
    group.bench_function("n3_lz_hint", |b| {
        b.iter(|| px_nix::noise::compute_n3_lz_hint(black_box(&data)))
    });
    
    // Benchmark N5 (format detection - should be O(1))
    group.bench_function("n5_format", |b| {
        b.iter(|| px_nix::noise::compute_n5_format(black_box(&data)))
    });
    
    group.finish();
}

fn bench_early_exit(c: &mut Criterion) {
    let mut group = c.benchmark_group("early_exit");
    let config = PxConfig::default();
    
    // Data that should trigger early exit (clear signal)
    let json = br#"{"data": "this is clearly structured json data with lots of text"}"#;
    group.bench_function("json_early_exit", |b| {
        b.iter(|| analyze_noise(black_box(json.as_slice()), &config))
    });
    
    // Data that needs full cascade (ambiguous)
    let mixed: Vec<u8> = (0..1024)
        .map(|i| if i % 2 == 0 { b'A' } else { (i % 256) as u8 })
        .collect();
    group.bench_function("mixed_full_cascade", |b| {
        b.iter(|| analyze_noise(black_box(&mixed), &config))
    });
    
    group.finish();
}

criterion_group!(
    benches,
    bench_noise_analysis,
    bench_noise_types,
    bench_noise_cascade,
    bench_early_exit,
);
criterion_main!(benches);
