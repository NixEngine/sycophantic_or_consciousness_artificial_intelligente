//! MDL Benchmarks for Px/Nix Engine

use criterion::{black_box, criterion_group, criterion_main, Criterion, BenchmarkId, Throughput};
use px_nix::{mdl, PxConfig, PxEngine};

fn bench_description_length(c: &mut Criterion) {
    let mut group = c.benchmark_group("description_length");
    
    // Different data sizes
    for size in [64, 256, 1024, 4096, 16384].iter() {
        // Generate test data
        let data: Vec<u8> = (0..*size).map(|i| (i % 256) as u8).collect();
        
        group.throughput(Throughput::Bytes(*size as u64));
        group.bench_with_input(BenchmarkId::new("sequential", size), &data, |b, data| {
            b.iter(|| mdl::description_length(black_box(data)))
        });
    }
    
    // Repetitive data (highly compressible)
    let repetitive = vec![42u8; 4096];
    group.throughput(Throughput::Bytes(4096));
    group.bench_function("repetitive_4k", |b| {
        b.iter(|| mdl::description_length(black_box(&repetitive)))
    });
    
    // Random-like data (low compressibility)
    let random: Vec<u8> = (0..4096).map(|i| ((i * 17 + 31) ^ (i * 13)) as u8).collect();
    group.bench_function("random_4k", |b| {
        b.iter(|| mdl::description_length(black_box(&random)))
    });
    
    group.finish();
}

fn bench_compressibility(c: &mut Criterion) {
    let mut group = c.benchmark_group("compressibility");
    
    let data: Vec<u8> = (0..4096).map(|i| (i % 256) as u8).collect();
    
    group.bench_function("compute_compressibility", |b| {
        b.iter(|| mdl::compute_compressibility(black_box(&data)))
    });
    
    group.bench_function("estimate_entropy", |b| {
        b.iter(|| mdl::estimate_entropy(black_box(&data)))
    });
    
    group.bench_function("lz_complexity", |b| {
        b.iter(|| mdl::lz_complexity(black_box(&data)))
    });
    
    group.finish();
}

fn bench_j_score(c: &mut Criterion) {
    let config = PxConfig::default();
    let data: Vec<u8> = (0..1024).map(|i| (i % 256) as u8).collect();
    
    // Create a simple identity transform
    let phi = px_nix::synthesis::Transform::identity();
    
    c.bench_function("compute_j", |b| {
        b.iter(|| mdl::compute_j(black_box(&data), black_box(&phi), config.lambda))
    });
}

fn bench_engine_process(c: &mut Criterion) {
    let mut group = c.benchmark_group("engine_process");
    
    let mut engine = PxEngine::new();
    
    // Small input
    let small = b"Hello, World!";
    group.bench_function("small_13b", |b| {
        b.iter(|| engine.process(black_box(small)))
    });
    
    // Medium input
    let medium: Vec<u8> = (0..1024).map(|i| (i % 256) as u8).collect();
    group.throughput(Throughput::Bytes(1024));
    group.bench_function("medium_1k", |b| {
        b.iter(|| engine.process(black_box(&medium)))
    });
    
    // Large input
    let large: Vec<u8> = (0..16384).map(|i| (i % 256) as u8).collect();
    group.throughput(Throughput::Bytes(16384));
    group.bench_function("large_16k", |b| {
        b.iter(|| engine.process(black_box(&large)))
    });
    
    group.finish();
}

criterion_group!(
    benches,
    bench_description_length,
    bench_compressibility,
    bench_j_score,
    bench_engine_process,
);
criterion_main!(benches);
