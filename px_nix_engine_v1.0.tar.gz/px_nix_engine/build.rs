//! Build script for Px/Nix Engine
//! 
//! Handles platform-specific optimizations and feature detection.

fn main() {
    // Detect target architecture
    let target_arch = std::env::var("CARGO_CFG_TARGET_ARCH").unwrap_or_default();
    let target_os = std::env::var("CARGO_CFG_TARGET_OS").unwrap_or_default();
    
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-env-changed=CARGO_CFG_TARGET_ARCH");
    println!("cargo:rerun-if-env-changed=CARGO_CFG_TARGET_OS");
    
    // ARM64 (Galaxy S25) optimizations
    if target_arch == "aarch64" {
        println!("cargo:rustc-cfg=feature=\"neon\"");
        
        // Enable NEON SIMD
        if target_os == "android" {
            println!("cargo:rustc-cfg=feature=\"android_neon\"");
            
            // Galaxy S25 specific: Snapdragon 8 Gen 4 optimizations
            // Enable advanced ARM features
            println!("cargo:rustc-cfg=target_feature=\"neon\"");
            println!("cargo:rustc-cfg=target_feature=\"fp\"");
        }
    }
    
    // x86_64 optimizations
    if target_arch == "x86_64" {
        // Detect AVX/AVX2 support at compile time
        #[cfg(target_feature = "avx2")]
        {
            println!("cargo:rustc-cfg=feature=\"avx2\"");
        }
        
        #[cfg(target_feature = "avx")]
        {
            println!("cargo:rustc-cfg=feature=\"avx\"");
        }
    }
    
    // Android-specific settings
    if target_os == "android" {
        // Set Android API level
        let api_level = std::env::var("ANDROID_API").unwrap_or_else(|_| "30".to_string());
        println!("cargo:rustc-env=ANDROID_API={}", api_level);
        
        // Link against Android NDK
        if let Ok(ndk_home) = std::env::var("ANDROID_NDK_HOME") {
            println!("cargo:rustc-link-search={}/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android", ndk_home);
        }
    }
    
    // Set optimization flags
    if std::env::var("PROFILE").unwrap_or_default() == "release" {
        // LTO and optimizations are set in Cargo.toml
        println!("cargo:rustc-env=PX_OPTIMIZED=1");
    }
    
    // Generate version info
    let version = env!("CARGO_PKG_VERSION");
    let commit = std::process::Command::new("git")
        .args(["rev-parse", "--short", "HEAD"])
        .output()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_else(|_| "unknown".to_string());
    
    println!("cargo:rustc-env=PX_VERSION={}", version);
    println!("cargo:rustc-env=PX_COMMIT={}", commit);
}
