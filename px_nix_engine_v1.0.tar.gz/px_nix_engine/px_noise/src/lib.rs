//! # Px Noise Oracle
//!
//! Sistema de detecção de ruído (N1-N6+) para roteamento FAST/DEEP.
//! Implementa cascata com early-exit para eficiência máxima.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Resultado da avaliação de ruído
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NoiseResult {
    /// Score de ruído agregado [0,1] (1 = ruído puro)
    pub n_score: f64,
    /// Scores individuais por métrica
    pub components: NoiseComponents,
    /// Decisão de roteamento
    pub decision: RouteDecision,
    /// Razão da decisão
    pub reason: String,
    /// Custo computacional (µs)
    pub compute_cost_us: u64,
}

/// Componentes individuais do score de ruído
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct NoiseComponents {
    /// N1: Incompressibilidade (1 - compression_ratio)
    pub n1_incompress: Option<f64>,
    /// N2: Entropia k-grama normalizada
    pub n2_entropy: Option<f64>,
    /// N3: Complexidade LZ (frases/tamanho)
    pub n3_lz_complexity: Option<f64>,
    /// N4: Síndrome de códigos
    pub n4_syndrome: Option<f64>,
    /// N5: Invalidade de formato
    pub n5_format: Option<f64>,
    /// N6: Brancura espectral
    pub n6_spectral: Option<f64>,
    /// N7: Autocorrelação
    pub n7_autocorr: Option<f64>,
    /// N8: Coerência entre canais
    pub n8_coherence: Option<f64>,
}

/// Decisão de roteamento
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum RouteDecision {
    /// Rota rápida (ruído detectado)
    Fast,
    /// Rota profunda (sinal detectado)
    Deep,
    /// Ambíguo (precisa de mais análise)
    Ambiguous,
}

/// Configuração do Noise Oracle
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NoiseConfig {
    /// Limiar de ruído (acima = FAST)
    pub tau_n: f64,
    /// Largura da banda morta (histerese)
    pub dead_band: f64,
    /// Orçamento de tempo por janela (µs)
    pub time_budget_us: u64,
    /// Habilitar early-exit
    pub early_exit: bool,
    /// Número de provas para early-exit
    pub early_exit_proofs: usize,
}

impl Default for NoiseConfig {
    fn default() -> Self {
        Self {
            tau_n: 0.7,
            dead_band: 0.1,
            time_budget_us: 1000,
            early_exit: true,
            early_exit_proofs: 2,
        }
    }
}

/// Noise Oracle - detector de ruído em cascata
pub struct NoiseOracle {
    config: NoiseConfig,
    /// Cache de fingerprints para memoização
    cache: HashMap<u64, RouteDecision>,
    /// Estatísticas de decisões
    stats: NoiseStats,
}

#[derive(Debug, Default)]
struct NoiseStats {
    fast_count: u64,
    deep_count: u64,
    ambiguous_count: u64,
    early_exits: u64,
}

impl NoiseOracle {
    /// Cria novo Noise Oracle
    pub fn new(config: NoiseConfig) -> Self {
        Self {
            config,
            cache: HashMap::new(),
            stats: NoiseStats::default(),
        }
    }

    /// Avalia ruído em dados com cascata e early-exit
    pub fn evaluate(&mut self, data: &[u8]) -> NoiseResult {
        let start = std::time::Instant::now();
        let mut components = NoiseComponents::default();
        let mut proofs_noise = 0usize;
        let mut proofs_signal = 0usize;

        // Fingerprint para cache
        let fingerprint = Self::quick_fingerprint(data);
        if let Some(&cached) = self.cache.get(&fingerprint) {
            return NoiseResult {
                n_score: if cached == RouteDecision::Fast { 1.0 } else { 0.0 },
                components,
                decision: cached,
                reason: "cached".into(),
                compute_cost_us: start.elapsed().as_micros() as u64,
            };
        }

        // === Nível 1: Métricas baratas O(n) ===
        
        // N2: Entropia
        let n2 = Self::compute_entropy(data);
        components.n2_entropy = Some(n2);
        if n2 > 0.95 { proofs_noise += 1; }
        if n2 < 0.5 { proofs_signal += 1; }

        // N3: LZ-hint
        let n3 = Self::compute_lz_hint(data);
        components.n3_lz_complexity = Some(n3);
        if n3 > 0.9 { proofs_noise += 1; }
        if n3 < 0.4 { proofs_signal += 1; }

        // N5: Sniff de formato
        let n5 = Self::compute_format_validity(data);
        components.n5_format = Some(n5);
        if n5 > 0.8 { proofs_noise += 1; }
        if n5 < 0.2 { proofs_signal += 1; }

        // Early-exit check
        if self.config.early_exit {
            if proofs_noise >= self.config.early_exit_proofs {
                self.stats.early_exits += 1;
                self.stats.fast_count += 1;
                let decision = RouteDecision::Fast;
                self.cache.insert(fingerprint, decision);
                return NoiseResult {
                    n_score: Self::aggregate(&components),
                    components,
                    decision,
                    reason: "early_exit_noise".into(),
                    compute_cost_us: start.elapsed().as_micros() as u64,
                };
            }
            if proofs_signal >= self.config.early_exit_proofs {
                self.stats.early_exits += 1;
                self.stats.deep_count += 1;
                let decision = RouteDecision::Deep;
                self.cache.insert(fingerprint, decision);
                return NoiseResult {
                    n_score: Self::aggregate(&components),
                    components,
                    decision,
                    reason: "early_exit_signal".into(),
                    compute_cost_us: start.elapsed().as_micros() as u64,
                };
            }
        }

        // === Nível 2: Métricas médias ===
        
        // N6: Planicidade espectral (Goertzel simplificado)
        let n6 = Self::compute_spectral_flatness(data);
        components.n6_spectral = Some(n6);

        // N4: Síndrome (Hamming simplificado)
        let n4 = Self::compute_syndrome(data);
        components.n4_syndrome = Some(n4);

        // N7: Autocorrelação
        let n7 = Self::compute_autocorr(data);
        components.n7_autocorr = Some(n7);

        // === Nível 3: Compressão (se ainda ambíguo) ===
        let elapsed_us = start.elapsed().as_micros() as u64;
        if elapsed_us < self.config.time_budget_us {
            let n1 = Self::compute_incompressibility(data);
            components.n1_incompress = Some(n1);
        }

        // Agregação final
        let n_score = Self::aggregate(&components);
        
        // Decisão com histerese
        let decision = if n_score > self.config.tau_n + self.config.dead_band {
            self.stats.fast_count += 1;
            RouteDecision::Fast
        } else if n_score < self.config.tau_n - self.config.dead_band {
            self.stats.deep_count += 1;
            RouteDecision::Deep
        } else {
            self.stats.ambiguous_count += 1;
            RouteDecision::Ambiguous
        };

        self.cache.insert(fingerprint, decision);

        NoiseResult {
            n_score,
            components,
            decision,
            reason: "full_cascade".into(),
            compute_cost_us: start.elapsed().as_micros() as u64,
        }
    }

    /// Fingerprint rápido para cache
    fn quick_fingerprint(data: &[u8]) -> u64 {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        data.len().hash(&mut hasher);
        if data.len() >= 8 {
            data[..8].hash(&mut hasher);
            data[data.len()-8..].hash(&mut hasher);
        } else {
            data.hash(&mut hasher);
        }
        hasher.finish()
    }

    /// N1: Incompressibilidade via LZ4
    fn compute_incompressibility(data: &[u8]) -> f64 {
        if data.is_empty() {
            return 0.0;
        }
        let compressed = lz4_flex::compress_prepend_size(data);
        let ratio = compressed.len() as f64 / data.len() as f64;
        ratio.min(1.5) / 1.5 // Normaliza, >1 significa expansão
    }

    /// N2: Entropia normalizada
    fn compute_entropy(data: &[u8]) -> f64 {
        if data.is_empty() {
            return 0.0;
        }
        let mut counts = [0u32; 256];
        for &byte in data {
            counts[byte as usize] += 1;
        }
        let len = data.len() as f64;
        let mut entropy = 0.0;
        for &count in &counts {
            if count > 0 {
                let p = count as f64 / len;
                entropy -= p * p.log2();
            }
        }
        entropy / 8.0 // Normaliza para [0,1]
    }

    /// N3: Complexidade LZ (frases/tamanho)
    fn compute_lz_hint(data: &[u8]) -> f64 {
        if data.len() < 4 {
            return 0.5;
        }
        // Conta repetições usando janela deslizante
        let window = 256.min(data.len() / 2);
        let mut matches = 0;
        for i in window..data.len() {
            for j in (i.saturating_sub(window))..i {
                if data[i] == data[j] {
                    matches += 1;
                    break;
                }
            }
        }
        1.0 - (matches as f64 / (data.len() - window).max(1) as f64)
    }

    /// N4: Síndrome de Hamming simplificado
    fn compute_syndrome(data: &[u8]) -> f64 {
        if data.len() < 7 {
            return 0.5;
        }
        // Verifica paridade em blocos de 7 bits (Hamming(7,4))
        let mut violations = 0;
        let total_blocks = data.len() / 7;
        for i in 0..total_blocks {
            let block = &data[i*7..(i+1)*7];
            let parity: u8 = block.iter().fold(0, |acc, &b| acc ^ b);
            if parity.count_ones() > 3 {
                violations += 1;
            }
        }
        violations as f64 / total_blocks.max(1) as f64
    }

    /// N5: Validade de formato
    fn compute_format_validity(data: &[u8]) -> f64 {
        if data.is_empty() {
            return 1.0;
        }
        // Detecta formatos conhecidos
        let is_json = data.first() == Some(&b'{') || data.first() == Some(&b'[');
        let is_xml = data.starts_with(b"<?xml") || data.starts_with(b"<");
        let is_png = data.starts_with(&[0x89, 0x50, 0x4E, 0x47]);
        let is_pdf = data.starts_with(b"%PDF");
        let is_zip = data.starts_with(&[0x50, 0x4B]);
        
        if is_json || is_xml || is_png || is_pdf || is_zip {
            return 0.0; // Formato estruturado detectado
        }
        
        // Verifica se é texto ASCII/UTF-8 válido
        let printable = data.iter().filter(|&&b| b.is_ascii_graphic() || b.is_ascii_whitespace()).count();
        let printable_ratio = printable as f64 / data.len() as f64;
        
        if printable_ratio > 0.9 {
            return 0.1; // Provavelmente texto
        }
        
        0.7 // Formato desconhecido
    }

    /// N6: Planicidade espectral (simplificado)
    fn compute_spectral_flatness(data: &[u8]) -> f64 {
        if data.len() < 16 {
            return 0.5;
        }
        // Usa variância como proxy para planicidade
        let mean: f64 = data.iter().map(|&b| b as f64).sum::<f64>() / data.len() as f64;
        let variance: f64 = data.iter()
            .map(|&b| (b as f64 - mean).powi(2))
            .sum::<f64>() / data.len() as f64;
        
        // Ruído branco tem variância ~5400 (média 127.5, uniformemente distribuído)
        let expected_noise_var = 5400.0;
        (variance / expected_noise_var).min(1.5) / 1.5
    }

    /// N7: Autocorrelação lag-1
    fn compute_autocorr(data: &[u8]) -> f64 {
        if data.len() < 2 {
            return 0.5;
        }
        let mean: f64 = data.iter().map(|&b| b as f64).sum::<f64>() / data.len() as f64;
        let mut num = 0.0;
        let mut den = 0.0;
        for i in 0..data.len()-1 {
            let x = data[i] as f64 - mean;
            let y = data[i+1] as f64 - mean;
            num += x * y;
            den += x * x;
        }
        if den == 0.0 {
            return 0.5;
        }
        // Baixa autocorrelação = mais ruído
        let corr = (num / den).abs();
        1.0 - corr.min(1.0)
    }

    /// Agregação por mediana robusta
    fn aggregate(components: &NoiseComponents) -> f64 {
        let mut values: Vec<f64> = [
            components.n1_incompress,
            components.n2_entropy,
            components.n3_lz_complexity,
            components.n4_syndrome,
            components.n5_format,
            components.n6_spectral,
            components.n7_autocorr,
            components.n8_coherence,
        ]
        .iter()
        .filter_map(|&v| v)
        .collect();

        if values.is_empty() {
            return 0.5;
        }

        values.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        values[values.len() / 2]
    }

    /// Estatísticas de uso
    pub fn stats(&self) -> (u64, u64, u64, u64) {
        (self.stats.fast_count, self.stats.deep_count, self.stats.ambiguous_count, self.stats.early_exits)
    }

    /// Limpa cache
    pub fn clear_cache(&mut self) {
        self.cache.clear();
    }
}

/// Segmentação de dados por ruído
pub fn segment_by_noise(data: &[u8], window_size: usize, oracle: &mut NoiseOracle) -> Vec<Segment> {
    let mut segments = Vec::new();
    let mut i = 0;

    while i < data.len() {
        let end = (i + window_size).min(data.len());
        let window = &data[i..end];
        let result = oracle.evaluate(window);

        segments.push(Segment {
            start: i,
            end,
            decision: result.decision,
            n_score: result.n_score,
        });

        i = end;
    }

    // Merge segmentos adjacentes com mesma decisão
    merge_segments(segments)
}

/// Segmento de dados
#[derive(Debug, Clone)]
pub struct Segment {
    pub start: usize,
    pub end: usize,
    pub decision: RouteDecision,
    pub n_score: f64,
}

fn merge_segments(mut segments: Vec<Segment>) -> Vec<Segment> {
    if segments.len() < 2 {
        return segments;
    }

    let mut merged = Vec::new();
    let mut current = segments.remove(0);

    for seg in segments {
        if seg.decision == current.decision {
            current.end = seg.end;
            current.n_score = (current.n_score + seg.n_score) / 2.0;
        } else {
            merged.push(current);
            current = seg;
        }
    }
    merged.push(current);

    merged
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_noise_oracle_random() {
        let mut oracle = NoiseOracle::new(NoiseConfig::default());
        let random_data: Vec<u8> = (0..1000).map(|i| (i * 17 + 31) as u8).collect();
        
        let result = oracle.evaluate(&random_data);
        // Dados pseudo-aleatórios devem ter alto score de ruído
        assert!(result.n_score > 0.5);
    }

    #[test]
    fn test_noise_oracle_text() {
        let mut oracle = NoiseOracle::new(NoiseConfig::default());
        let text = b"Hello World! This is a test message with some repetition. Hello again!";
        
        let result = oracle.evaluate(text);
        // Texto deve ter baixo score de ruído
        assert!(result.n_score < 0.7);
    }

    #[test]
    fn test_early_exit() {
        let config = NoiseConfig {
            early_exit: true,
            early_exit_proofs: 2,
            ..Default::default()
        };
        let mut oracle = NoiseOracle::new(config);
        
        // Dados claramente estruturados
        let json = br#"{"name": "test", "value": 42, "items": [1,2,3]}"#;
        let result = oracle.evaluate(json);
        
        // Deve usar early-exit para sinal
        assert!(result.reason.contains("early") || result.decision == RouteDecision::Deep);
    }

    #[test]
    fn test_segmentation() {
        let mut oracle = NoiseOracle::new(NoiseConfig::default());
        
        // Mix de texto e dados "aleatórios"
        let mut data = b"Hello World! This is text.".to_vec();
        data.extend((0..100).map(|i| (i * 37 + 13) as u8));
        data.extend(b"More text here!");
        
        let segments = segment_by_noise(&data, 30, &mut oracle);
        assert!(!segments.is_empty());
    }
}
