//! # Px Metrics - Sistema de Métricas de Competência
//!
//! Implementa o vetor Pareto de competência K⃗ = (K_obj, K_semi, K_subj)
//! conforme especificado no núcleo Px.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

/// Vetor de Competência Pareto
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompetenceVector {
    /// K_obj: Competência objetiva (sem regras, sem conceitos)
    pub k_obj: f64,
    /// K_semi: Competência semi-objetiva (com regras, sem conceitos)
    pub k_semi: f64,
    /// K_subj: Competência subjetiva (com conceitos e regras)
    pub k_subj: f64,
    /// Consistência entre modos
    pub consistency: f64,
}

impl CompetenceVector {
    /// Cria vetor de competência
    pub fn new(k_obj: f64, k_semi: f64, k_subj: f64) -> Self {
        let consistency = 1.0 - [
            (k_obj - k_semi).abs(),
            (k_semi - k_subj).abs(),
            (k_obj - k_subj).abs(),
        ].iter().copied().fold(0.0_f64, f64::max);

        Self {
            k_obj: k_obj.clamp(0.0, 1.0),
            k_semi: k_semi.clamp(0.0, 1.0),
            k_subj: k_subj.clamp(0.0, 1.0),
            consistency: consistency.clamp(0.0, 1.0),
        }
    }

    /// Escore misto com pesos
    pub fn mixed_score(&self, w_obj: f64, w_semi: f64, w_subj: f64) -> f64 {
        let total = w_obj + w_semi + w_subj;
        if total == 0.0 {
            return 0.0;
        }
        (self.k_obj * w_obj + self.k_semi * w_semi + self.k_subj * w_subj) / total
    }

    /// Verifica se atinge limiares mínimos
    pub fn meets_thresholds(&self, min_obj: f64, min_semi: f64, min_subj: f64, min_cons: f64) -> bool {
        self.k_obj >= min_obj 
            && self.k_semi >= min_semi 
            && self.k_subj >= min_subj 
            && self.consistency >= min_cons
    }

    /// Verifica se deve abster (competência muito baixa)
    pub fn should_abstain(&self, threshold: f64) -> bool {
        self.k_obj < threshold || self.consistency < 0.3
    }
}

impl Default for CompetenceVector {
    fn default() -> Self {
        Self::new(0.5, 0.5, 0.5)
    }
}

/// Calculador de competência objetiva
/// K_obj(D) = (P_obj · X · R★ · (1-κ) · δ)^(1/5)
pub fn compute_k_obj(
    p_obj: f64,      // Pureza objetiva
    intensity: f64,  // Intensidade de experiência
    r_star: f64,     // Reprodutibilidade
    kappa: f64,      // Contradição
    delta: f64,      // Determinismo
) -> f64 {
    let product = p_obj * intensity * r_star * (1.0 - kappa) * delta;
    if product <= 0.0 {
        return 0.0;
    }
    product.powf(1.0 / 5.0)
}

/// Calculador de competência semi-objetiva
/// K_semi(D;R) = K_obj(R⊙D) · e^(-α·ℓ(R)) · (1 - β·χ(D;R))
pub fn compute_k_semi(
    k_obj_with_rules: f64,  // K_obj aplicado sobre R⊙D
    rule_length: f64,       // ℓ(R) em bits
    contamination: f64,     // χ(D;R) índice de contaminação
    alpha: f64,             // Parâmetro α (típico: 1e-3)
    beta: f64,              // Parâmetro β (típico: 0.5)
) -> f64 {
    k_obj_with_rules * (-alpha * rule_length).exp() * (1.0 - beta * contamination)
}

/// Calculador de competência subjetiva
/// K_subj(D;C,R) = ((1-res)·Ω·R★_C·(1-η))^(1/4) · e^(-γ·ℓ(C))
pub fn compute_k_subj(
    residue: f64,           // res(C⊙R⊙D, C)
    omega: f64,             // Ω(C) completude do conceito
    r_star_c: f64,          // R★ sob conceito
    eta: f64,               // η densidade de narrativa
    concept_length: f64,    // ℓ(C) em bits
    gamma: f64,             // Parâmetro γ (típico: 5e-4)
) -> f64 {
    let product = (1.0 - residue) * omega * r_star_c * (1.0 - eta);
    if product <= 0.0 {
        return 0.0;
    }
    product.powf(0.25) * (-gamma * concept_length).exp()
}

/// Índice de Competência Px (κ_Px)
/// Para bateria de tarefas com pesos
pub fn compute_kappa_px(results: &[(bool, f64)]) -> f64 {
    let total_weight: f64 = results.iter().map(|(_, w)| w).sum();
    if total_weight == 0.0 {
        return 0.0;
    }
    let solved_weight: f64 = results.iter()
        .filter(|(solved, _)| *solved)
        .map(|(_, w)| w)
        .sum();
    solved_weight / total_weight
}

/// Eficiência de Transdução η_Px
pub fn compute_eta_px(kappa_realized: f64, kappa_intrinsic: f64) -> f64 {
    if kappa_intrinsic == 0.0 {
        return 0.0;
    }
    (kappa_realized / kappa_intrinsic).clamp(0.0, 1.0)
}

/// Métricas de Autonomia (novas, conforme documento de melhorias)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AutonomyMetrics {
    /// K_meta: Competência meta-cognitiva
    pub k_meta: f64,
    /// K_causal: Competência causal
    pub k_causal: f64,
    /// A_goal: Autonomia de objetivos
    pub a_goal: f64,
    /// A_learn: Autonomia de aprendizado
    pub a_learn: f64,
    /// A_robust: Robustez autônoma
    pub a_robust: f64,
    /// Ω_auto: Índice de autonomia geral
    pub omega_auto: f64,
}

impl AutonomyMetrics {
    /// Calcula todas as métricas de autonomia
    pub fn compute(
        k_obj: f64,
        k_meta: f64,
        k_causal: f64,
        a_goal: f64,
        a_learn: f64,
        a_robust: f64,
    ) -> Self {
        // Ω_auto = (K_obj · K_meta · K_causal · A_goal · A_learn · A_robust)^(1/6)
        let product = k_obj * k_meta * k_causal * a_goal * a_learn * a_robust;
        let omega_auto = if product > 0.0 {
            product.powf(1.0 / 6.0)
        } else {
            0.0
        };

        Self {
            k_meta,
            k_causal,
            a_goal,
            a_learn,
            a_robust,
            omega_auto,
        }
    }
}

/// Calcula K_meta (competência meta-cognitiva)
/// K_meta = (coherence · efficiency · self_awareness · calibration)^(1/4)
pub fn compute_k_meta(
    coherence: f64,
    efficiency: f64,
    self_awareness: f64,
    calibration: f64,
) -> f64 {
    let product = coherence * efficiency * self_awareness * calibration;
    if product <= 0.0 {
        return 0.0;
    }
    product.powf(0.25)
}

/// Calcula K_causal (competência causal)
/// K_causal = (edge_accuracy · intervention_success · counterfactual_validity)^(1/3)
pub fn compute_k_causal(
    edge_accuracy: f64,
    intervention_success: f64,
    counterfactual_validity: f64,
) -> f64 {
    let product = edge_accuracy * intervention_success * counterfactual_validity;
    if product <= 0.0 {
        return 0.0;
    }
    product.powf(1.0 / 3.0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_competence_vector() {
        let k = CompetenceVector::new(0.8, 0.7, 0.6);
        assert!(k.consistency > 0.5);
        assert!(k.mixed_score(1.0, 1.0, 1.0) > 0.6);
    }

    #[test]
    fn test_k_obj() {
        let k = compute_k_obj(0.8, 0.9, 0.85, 0.1, 0.9);
        assert!(k > 0.7 && k < 1.0);
    }

    #[test]
    fn test_kappa_px() {
        let results = vec![(true, 1.0), (true, 1.0), (false, 1.0)];
        let kappa = compute_kappa_px(&results);
        assert!((kappa - 0.666).abs() < 0.01);
    }

    #[test]
    fn test_autonomy_metrics() {
        let metrics = AutonomyMetrics::compute(0.8, 0.7, 0.75, 0.6, 0.7, 0.8);
        assert!(metrics.omega_auto > 0.5);
    }
}
