//! # Arena de Alocação
//!
//! Implementa alocação por arenas com limites duros.
//! Garante memória-segura sem OOM caótico.

use parking_lot::Mutex;
use std::alloc::{alloc, dealloc, Layout};
use std::ptr::NonNull;

/// Arena de alocação com limite de memória
pub struct Arena {
    /// Capacidade total em bytes
    capacity: usize,
    /// Bytes usados
    used: Mutex<usize>,
    /// Blocos alocados (para dealloc no drop)
    blocks: Mutex<Vec<AllocBlock>>,
}

/// Bloco de alocação
struct AllocBlock {
    ptr: NonNull<u8>,
    layout: Layout,
}

// SAFETY: Arena gerencia memória internamente de forma thread-safe
unsafe impl Send for Arena {}
unsafe impl Sync for Arena {}

impl Arena {
    /// Cria nova arena com capacidade especificada
    pub fn new(capacity: usize) -> Self {
        Self {
            capacity,
            used: Mutex::new(0),
            blocks: Mutex::new(Vec::new()),
        }
    }

    /// Capacidade total
    pub fn capacity(&self) -> usize {
        self.capacity
    }

    /// Bytes usados atualmente
    pub fn used(&self) -> usize {
        *self.used.lock()
    }

    /// Bytes disponíveis
    pub fn available(&self) -> usize {
        self.capacity.saturating_sub(self.used())
    }

    /// Verifica se pode alocar n bytes
    pub fn can_allocate(&self, size: usize) -> bool {
        self.available() >= size
    }

    /// Taxa de uso (0.0 a 1.0)
    pub fn usage_ratio(&self) -> f64 {
        self.used() as f64 / self.capacity.max(1) as f64
    }

    /// Reseta arena (limpa tudo)
    pub fn reset(&self) {
        let mut blocks = self.blocks.lock();
        let mut used = self.used.lock();

        // Dealoca todos os blocos
        for block in blocks.drain(..) {
            // SAFETY: blocos foram alocados por nós com layout válido
            unsafe {
                dealloc(block.ptr.as_ptr(), block.layout);
            }
        }

        *used = 0;
    }
}

impl Drop for Arena {
    fn drop(&mut self) {
        self.reset();
    }
}

/// Buffer gerenciado pela arena
pub struct ArenaBuffer {
    data: Vec<u8>,
}

impl ArenaBuffer {
    /// Cria buffer vazio
    pub fn new() -> Self {
        Self { data: Vec::new() }
    }

    /// Cria buffer com capacidade
    pub fn with_capacity(capacity: usize) -> Self {
        Self {
            data: Vec::with_capacity(capacity),
        }
    }

    /// Cria buffer a partir de bytes
    pub fn from_bytes(bytes: &[u8]) -> Self {
        Self {
            data: bytes.to_vec(),
        }
    }

    /// Referência aos bytes
    pub fn as_slice(&self) -> &[u8] {
        &self.data
    }

    /// Referência mutável aos bytes
    pub fn as_mut_slice(&mut self) -> &mut [u8] {
        &mut self.data
    }

    /// Comprimento
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Verifica se está vazio
    pub fn is_empty(&self) -> bool {
        self.data.is_empty()
    }

    /// Adiciona bytes
    pub fn extend(&mut self, bytes: &[u8]) {
        self.data.extend_from_slice(bytes);
    }

    /// Limpa buffer
    pub fn clear(&mut self) {
        self.data.clear();
    }

    /// Converte para Vec
    pub fn into_vec(self) -> Vec<u8> {
        self.data
    }
}

impl Default for ArenaBuffer {
    fn default() -> Self {
        Self::new()
    }
}

impl AsRef<[u8]> for ArenaBuffer {
    fn as_ref(&self) -> &[u8] {
        &self.data
    }
}

impl AsMut<[u8]> for ArenaBuffer {
    fn as_mut(&mut self) -> &mut [u8] {
        &mut self.data
    }
}

/// Pool de buffers reutilizáveis
pub struct BufferPool {
    /// Buffers disponíveis por tamanho (potência de 2)
    pools: [Mutex<Vec<Vec<u8>>>; 16], // 1B a 32KB
    /// Tamanho máximo por pool
    max_per_pool: usize,
}

impl BufferPool {
    /// Cria novo pool de buffers
    pub fn new(max_per_pool: usize) -> Self {
        Self {
            pools: Default::default(),
            max_per_pool,
        }
    }

    /// Determina índice do pool para um tamanho
    fn pool_index(size: usize) -> usize {
        if size == 0 {
            return 0;
        }
        let log = (size.next_power_of_two().trailing_zeros() as usize).min(15);
        log
    }

    /// Obtém buffer do pool ou aloca novo
    pub fn get(&self, min_size: usize) -> Vec<u8> {
        let idx = Self::pool_index(min_size);
        let mut pool = self.pools[idx].lock();

        if let Some(mut buf) = pool.pop() {
            buf.clear();
            buf
        } else {
            Vec::with_capacity(1 << idx)
        }
    }

    /// Devolve buffer ao pool
    pub fn put(&self, buf: Vec<u8>) {
        let idx = Self::pool_index(buf.capacity());
        let mut pool = self.pools[idx].lock();

        if pool.len() < self.max_per_pool {
            pool.push(buf);
        }
        // Se pool cheio, buffer é dropado
    }

    /// Limpa todos os pools
    pub fn clear(&self) {
        for pool in &self.pools {
            pool.lock().clear();
        }
    }

    /// Total de buffers em cache
    pub fn cached_count(&self) -> usize {
        self.pools.iter().map(|p| p.lock().len()).sum()
    }
}

impl Default for BufferPool {
    fn default() -> Self {
        Self::new(64) // 64 buffers por tamanho
    }
}

/// Alocador com limites (wrapper seguro)
pub struct BoundedAllocator {
    arena: Arena,
    pool: BufferPool,
}

impl BoundedAllocator {
    /// Cria novo alocador com limite de memória
    pub fn new(capacity: usize) -> Self {
        Self {
            arena: Arena::new(capacity),
            pool: BufferPool::default(),
        }
    }

    /// Aloca buffer com tamanho especificado
    pub fn allocate(&self, size: usize) -> Option<Vec<u8>> {
        if !self.arena.can_allocate(size) {
            return None;
        }

        let buf = self.pool.get(size);
        *self.arena.used.lock() += buf.capacity();
        Some(buf)
    }

    /// Libera buffer (devolve ao pool)
    pub fn deallocate(&self, buf: Vec<u8>) {
        let cap = buf.capacity();
        self.pool.put(buf);
        let mut used = self.arena.used.lock();
        *used = used.saturating_sub(cap);
    }

    /// Bytes usados
    pub fn used(&self) -> usize {
        self.arena.used()
    }

    /// Bytes disponíveis
    pub fn available(&self) -> usize {
        self.arena.available()
    }

    /// Taxa de uso
    pub fn usage_ratio(&self) -> f64 {
        self.arena.usage_ratio()
    }

    /// Reseta alocador
    pub fn reset(&self) {
        self.pool.clear();
        self.arena.reset();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_arena_basic() {
        let arena = Arena::new(1024);
        assert_eq!(arena.capacity(), 1024);
        assert_eq!(arena.used(), 0);
        assert!(arena.can_allocate(512));
    }

    #[test]
    fn test_buffer_pool() {
        let pool = BufferPool::new(4);

        let buf1 = pool.get(100);
        assert!(buf1.capacity() >= 100);

        pool.put(buf1);
        assert_eq!(pool.cached_count(), 1);

        let buf2 = pool.get(100);
        assert!(buf2.capacity() >= 100);
        assert_eq!(pool.cached_count(), 0); // Reusou
    }

    #[test]
    fn test_bounded_allocator() {
        let alloc = BoundedAllocator::new(1024);

        let buf = alloc.allocate(256).unwrap();
        assert!(alloc.used() >= 256);

        alloc.deallocate(buf);
        // Memória volta ao pool
    }

    #[test]
    fn test_bounded_allocator_limit() {
        let alloc = BoundedAllocator::new(100);

        // Não deve conseguir alocar mais que o limite
        let result = alloc.allocate(200);
        assert!(result.is_none());
    }
}
