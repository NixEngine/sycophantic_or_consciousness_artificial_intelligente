//! # Px Core - Núcleo de Lógica Pura
//! 
//! Implementação do núcleo Px baseado em MDL (Minimum Description Length).
//! Este módulo contém os tipos fundamentais e operadores de transformação.
//! 
//! ## Princípios Fundamentais
//! - J(Φ) = ℓ(Φ) + res(Φ, D) - Função objetivo MDL
//! - Determinístico e puro (sem I/O direto, sem relógio de alta resolução)
//! - Memória-segura (sem unsafe no core)
//! - Modelo de capabilities

#![forbid(unsafe_code)]
#![warn(missing_docs)]

pub mod types;
pub mod mdl;
pub mod codec;
pub mod transform;
pub mod arena;

pub use types::*;
pub use mdl::*;
pub use codec::*;
pub use transform::*;
pub use arena::*;

use serde::{Deserialize, Serialize};
use std::time::Duration;

/// Resultado de uma operação Px
pub type PxResult<T> = Result<T, PxError>;

/// Erros do núcleo Px
#[derive(Debug, thiserror::Error)]
pub enum PxError {
    /// Erro de codificação
    #[error("Codec error: {0}")]
    Codec(String),
    /// Erro de transformação
    #[error("Transform error: {0}")]
    Transform(String),
    /// Orçamento excedido
    #[error("Budget exceeded: time={time:?}, memory={memory}")]
    BudgetExceeded { time: Duration, memory: usize },
    /// Dados inválidos
    #[error("Invalid data: {0}")]
    InvalidData(String),
    /// Invariante violado
    #[error("Invariant violation: {0}")]
    InvariantViolation(String),
}

/// Configuração do núcleo Px
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PxConfig {
    /// Lambda para penalização de complexidade
    pub lambda: f64,
    /// Orçamento de tempo máximo
    pub time_budget: Duration,
    /// Orçamento de memória máximo (bytes)
    pub memory_budget: usize,
    /// Tolerância delta para convergência
    pub delta_tolerance: f64,
    /// Seed para PRNG (determinismo)
    pub seed: u64,
}

impl Default for PxConfig {
    fn default() -> Self {
        Self {
            lambda: 1e-3,
            time_budget: Duration::from_millis(100),
            memory_budget: 64 * 1024 * 1024, // 64MB
            delta_tolerance: 1e-6,
            seed: 42,
        }
    }
}

/// Contexto de execução do núcleo Px
pub struct PxContext {
    config: PxConfig,
    arena: Arena,
    rng: rand_chacha::ChaCha8Rng,
}

impl PxContext {
    /// Cria novo contexto de execução
    pub fn new(config: PxConfig) -> Self {
        use rand::SeedableRng;
        Self {
            arena: Arena::new(config.memory_budget),
            rng: rand_chacha::ChaCha8Rng::seed_from_u64(config.seed),
            config,
        }
    }

    /// Obtém referência à configuração
    pub fn config(&self) -> &PxConfig {
        &self.config
    }

    /// Obtém referência à arena de alocação
    pub fn arena(&self) -> &Arena {
        &self.arena
    }

    /// Obtém referência mutável ao PRNG
    pub fn rng(&mut self) -> &mut rand_chacha::ChaCha8Rng {
        &mut self.rng
    }

    /// Verifica se orçamento de memória foi excedido
    pub fn check_memory_budget(&self) -> PxResult<()> {
        if self.arena.used() > self.config.memory_budget {
            return Err(PxError::BudgetExceeded {
                time: Duration::ZERO,
                memory: self.arena.used(),
            });
        }
        Ok(())
    }
}

/// Trait para transformadores Px (programas finitos)
pub trait Transformer: Send + Sync {
    /// Nome do transformador
    fn name(&self) -> &str;
    
    /// Aplica transformação aos dados
    fn transform(&self, data: &[u8], ctx: &mut PxContext) -> PxResult<Vec<u8>>;
    
    /// Comprimento descritivo do transformador (bits)
    fn description_length(&self) -> f64;
    
    /// Custo estimado de execução
    fn estimated_cost(&self) -> f64 {
        self.description_length() * 0.1
    }
}

/// Trait para codecs Px
pub trait PxCodec: Send + Sync {
    /// Nome do codec
    fn name(&self) -> &str;
    
    /// Comprime dados
    fn compress(&self, data: &[u8]) -> PxResult<Vec<u8>>;
    
    /// Descomprime dados
    fn decompress(&self, data: &[u8]) -> PxResult<Vec<u8>>;
    
    /// Comprimento do modelo do codec (bits)
    fn model_cost(&self) -> f64;
}

/// Versão do núcleo
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Hash do build para auditoria
pub fn build_hash() -> String {
    use std::hash::{Hash, Hasher};
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    VERSION.hash(&mut hasher);
    format!("{:016x}", hasher.finish())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_context_creation() {
        let ctx = PxContext::new(PxConfig::default());
        assert!(ctx.arena().used() < ctx.config().memory_budget);
    }

    #[test]
    fn test_determinism() {
        let mut ctx1 = PxContext::new(PxConfig { seed: 123, ..Default::default() });
        let mut ctx2 = PxContext::new(PxConfig { seed: 123, ..Default::default() });
        
        use rand::Rng;
        let v1: u64 = ctx1.rng().gen();
        let v2: u64 = ctx2.rng().gen();
        assert_eq!(v1, v2, "PRNG deve ser determinístico com mesma seed");
    }
}
