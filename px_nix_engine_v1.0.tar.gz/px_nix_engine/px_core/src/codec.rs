//! # Codecs Px
//!
//! Implementação do comitê de codecs para avaliação MDL robusta.
//! Usa múltiplos compressores para obter mediana estável de ℓ(·).

use crate::{PxCodec, PxError, PxResult};

/// Codec LZ4 (rápido, baixo overhead)
pub struct Lz4Codec;

impl PxCodec for Lz4Codec {
    fn name(&self) -> &str {
        "lz4"
    }

    fn compress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        Ok(lz4_flex::compress_prepend_size(data))
    }

    fn decompress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        lz4_flex::decompress_size_prepended(data)
            .map_err(|e| PxError::Codec(format!("LZ4 decompress error: {}", e)))
    }

    fn model_cost(&self) -> f64 {
        // LZ4 tem modelo muito simples: ~32 bits de overhead
        32.0
    }
}

/// Codec Zstd nível 1 (rápido com melhor compressão)
pub struct ZstdCodec {
    level: i32,
}

impl ZstdCodec {
    /// Cria codec Zstd com nível específico
    pub fn new(level: i32) -> Self {
        Self { level: level.clamp(1, 22) }
    }

    /// Codec Zstd rápido (nível 1)
    pub fn fast() -> Self {
        Self::new(1)
    }

    /// Codec Zstd balanceado (nível 3)
    pub fn balanced() -> Self {
        Self::new(3)
    }
}

impl Default for ZstdCodec {
    fn default() -> Self {
        Self::fast()
    }
}

impl PxCodec for ZstdCodec {
    fn name(&self) -> &str {
        "zstd"
    }

    fn compress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        zstd::encode_all(std::io::Cursor::new(data), self.level)
            .map_err(|e| PxError::Codec(format!("Zstd compress error: {}", e)))
    }

    fn decompress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        zstd::decode_all(std::io::Cursor::new(data))
            .map_err(|e| PxError::Codec(format!("Zstd decompress error: {}", e)))
    }

    fn model_cost(&self) -> f64 {
        // Zstd tem modelo mais complexo: ~128 bits base + nível * 16
        128.0 + (self.level as f64) * 16.0
    }
}

/// Codec de identidade (sem compressão)
pub struct IdentityCodec;

impl PxCodec for IdentityCodec {
    fn name(&self) -> &str {
        "identity"
    }

    fn compress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        Ok(data.to_vec())
    }

    fn decompress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        Ok(data.to_vec())
    }

    fn model_cost(&self) -> f64 {
        // Modelo mínimo: 1 bit
        1.0
    }
}

/// Codec RLE (Run-Length Encoding) simplificado
pub struct RleCodec;

impl PxCodec for RleCodec {
    fn name(&self) -> &str {
        "rle"
    }

    fn compress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        if data.is_empty() {
            return Ok(Vec::new());
        }

        let mut result = Vec::with_capacity(data.len());
        let mut current = data[0];
        let mut count: u8 = 1;

        for &byte in &data[1..] {
            if byte == current && count < 255 {
                count += 1;
            } else {
                result.push(count);
                result.push(current);
                current = byte;
                count = 1;
            }
        }
        result.push(count);
        result.push(current);

        Ok(result)
    }

    fn decompress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        if data.len() % 2 != 0 {
            return Err(PxError::Codec("Invalid RLE data length".into()));
        }

        let mut result = Vec::new();
        for chunk in data.chunks(2) {
            let count = chunk[0] as usize;
            let byte = chunk[1];
            result.extend(std::iter::repeat(byte).take(count));
        }

        Ok(result)
    }

    fn model_cost(&self) -> f64 {
        // RLE tem modelo muito simples: ~16 bits
        16.0
    }
}

/// Delta encoding (bom para dados sequenciais)
pub struct DeltaCodec;

impl PxCodec for DeltaCodec {
    fn name(&self) -> &str {
        "delta"
    }

    fn compress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        if data.is_empty() {
            return Ok(Vec::new());
        }

        let mut result = Vec::with_capacity(data.len());
        result.push(data[0]); // Primeiro byte literal

        for i in 1..data.len() {
            let delta = data[i].wrapping_sub(data[i - 1]);
            result.push(delta);
        }

        Ok(result)
    }

    fn decompress(&self, data: &[u8]) -> PxResult<Vec<u8>> {
        if data.is_empty() {
            return Ok(Vec::new());
        }

        let mut result = Vec::with_capacity(data.len());
        result.push(data[0]);

        for i in 1..data.len() {
            let value = result[i - 1].wrapping_add(data[i]);
            result.push(value);
        }

        Ok(result)
    }

    fn model_cost(&self) -> f64 {
        // Delta tem modelo simples: ~8 bits
        8.0
    }
}

/// Comitê de codecs para avaliação robusta
pub struct CodecCommittee {
    codecs: Vec<Box<dyn PxCodec>>,
}

impl CodecCommittee {
    /// Cria comitê vazio
    pub fn new() -> Self {
        Self { codecs: Vec::new() }
    }

    /// Cria comitê padrão com LZ4, Zstd e Identity
    pub fn default_committee() -> Self {
        let mut committee = Self::new();
        committee.add(Box::new(Lz4Codec));
        committee.add(Box::new(ZstdCodec::fast()));
        committee.add(Box::new(ZstdCodec::balanced()));
        committee.add(Box::new(IdentityCodec));
        committee
    }

    /// Adiciona codec ao comitê
    pub fn add(&mut self, codec: Box<dyn PxCodec>) {
        self.codecs.push(codec);
    }

    /// Número de codecs no comitê
    pub fn len(&self) -> usize {
        self.codecs.len()
    }

    /// Verifica se comitê está vazio
    pub fn is_empty(&self) -> bool {
        self.codecs.is_empty()
    }

    /// Avalia todos os codecs e retorna métricas
    pub fn evaluate(&self, data: &[u8]) -> Vec<CodecEvaluation> {
        self.codecs
            .iter()
            .filter_map(|codec| {
                let start = std::time::Instant::now();
                match codec.compress(data) {
                    Ok(compressed) => {
                        let time = start.elapsed();
                        Some(CodecEvaluation {
                            name: codec.name().to_string(),
                            original_size: data.len(),
                            compressed_size: compressed.len(),
                            model_cost: codec.model_cost(),
                            compress_time_us: time.as_micros() as u64,
                            ratio: compressed.len() as f64 / data.len().max(1) as f64,
                            j_score: (compressed.len() * 8) as f64 + codec.model_cost(),
                        })
                    }
                    Err(_) => None,
                }
            })
            .collect()
    }

    /// Retorna mediana robusta do J-score
    pub fn median_j_score(&self, data: &[u8]) -> f64 {
        let mut evals = self.evaluate(data);
        if evals.is_empty() {
            return (data.len() * 8) as f64;
        }

        evals.sort_by(|a, b| a.j_score.partial_cmp(&b.j_score).unwrap_or(std::cmp::Ordering::Equal));
        evals[evals.len() / 2].j_score
    }

    /// Retorna melhor codec para os dados
    pub fn best_codec(&self, data: &[u8]) -> Option<CodecEvaluation> {
        self.evaluate(data)
            .into_iter()
            .min_by(|a, b| a.j_score.partial_cmp(&b.j_score).unwrap_or(std::cmp::Ordering::Equal))
    }

    /// Iterador sobre codecs
    pub fn iter(&self) -> impl Iterator<Item = &dyn PxCodec> {
        self.codecs.iter().map(|c| c.as_ref())
    }
}

impl Default for CodecCommittee {
    fn default() -> Self {
        Self::default_committee()
    }
}

/// Resultado de avaliação de um codec
#[derive(Debug, Clone)]
pub struct CodecEvaluation {
    /// Nome do codec
    pub name: String,
    /// Tamanho original em bytes
    pub original_size: usize,
    /// Tamanho comprimido em bytes
    pub compressed_size: usize,
    /// Custo do modelo em bits
    pub model_cost: f64,
    /// Tempo de compressão em microsegundos
    pub compress_time_us: u64,
    /// Ratio de compressão (compressed/original)
    pub ratio: f64,
    /// J-score = compressed_bits + model_cost
    pub j_score: f64,
}

impl CodecEvaluation {
    /// Ganho de informação em bits
    pub fn information_gain(&self) -> f64 {
        ((self.original_size - self.compressed_size) * 8) as f64
    }

    /// Velocidade em MB/s
    pub fn speed_mbps(&self) -> f64 {
        if self.compress_time_us == 0 {
            return f64::INFINITY;
        }
        (self.original_size as f64 / 1_000_000.0) / (self.compress_time_us as f64 / 1_000_000.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_lz4_codec() {
        let codec = Lz4Codec;
        let data = b"hello world hello world hello";
        
        let compressed = codec.compress(data).unwrap();
        let decompressed = codec.decompress(&compressed).unwrap();
        
        assert_eq!(data.as_slice(), decompressed.as_slice());
    }

    #[test]
    fn test_zstd_codec() {
        let codec = ZstdCodec::fast();
        let data = b"test data with some repetition repetition repetition";
        
        let compressed = codec.compress(data).unwrap();
        let decompressed = codec.decompress(&compressed).unwrap();
        
        assert_eq!(data.as_slice(), decompressed.as_slice());
        assert!(compressed.len() < data.len());
    }

    #[test]
    fn test_delta_codec() {
        let codec = DeltaCodec;
        let data = vec![1, 2, 3, 4, 5, 6, 7, 8]; // Sequência linear
        
        let compressed = codec.compress(&data).unwrap();
        let decompressed = codec.decompress(&compressed).unwrap();
        
        assert_eq!(data, decompressed);
    }

    #[test]
    fn test_codec_committee() {
        let committee = CodecCommittee::default_committee();
        let data = b"test data for committee evaluation with repetition repetition";
        
        let evals = committee.evaluate(data);
        assert!(!evals.is_empty());
        
        let best = committee.best_codec(data).unwrap();
        assert!(best.ratio <= 1.0);
    }

    #[test]
    fn test_median_j_score() {
        let committee = CodecCommittee::default_committee();
        let data = b"repetitive data repetitive data repetitive data";
        
        let median = committee.median_j_score(data);
        assert!(median > 0.0);
        assert!(median < (data.len() * 8) as f64 * 2.0); // Não deve ser muito maior que original
    }
}
