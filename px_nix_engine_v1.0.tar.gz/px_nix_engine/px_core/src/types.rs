//! Tipos fundamentais do núcleo Px
//! 
//! Define os tipos base usados em todo o sistema Px/Nix.

use serde::{Deserialize, Serialize};
use smallvec::SmallVec;
use std::fmt;

/// Dados brutos - sequência de símbolos
#[derive(Clone, Default, Serialize, Deserialize)]
pub struct Data {
    /// Bytes brutos
    pub bytes: Vec<u8>,
    /// Metadados opcionais
    pub meta: DataMeta,
}

impl Data {
    /// Cria Data a partir de bytes
    pub fn from_bytes(bytes: impl Into<Vec<u8>>) -> Self {
        let bytes = bytes.into();
        Self {
            meta: DataMeta {
                size: bytes.len(),
                ..Default::default()
            },
            bytes,
        }
    }

    /// Comprimento em bytes
    pub fn len(&self) -> usize {
        self.bytes.len()
    }

    /// Verifica se está vazio
    pub fn is_empty(&self) -> bool {
        self.bytes.is_empty()
    }

    /// Calcula hash Blake3
    pub fn hash(&self) -> Hash256 {
        Hash256(blake3::hash(&self.bytes).into())
    }
}

impl AsRef<[u8]> for Data {
    fn as_ref(&self) -> &[u8] {
        &self.bytes
    }
}

impl fmt::Debug for Data {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Data")
            .field("len", &self.bytes.len())
            .field("hash", &self.hash())
            .finish()
    }
}

/// Metadados de dados
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct DataMeta {
    /// Tamanho original
    pub size: usize,
    /// Tipo MIME detectado
    pub mime: Option<String>,
    /// Origem dos dados
    pub provenance: Option<Provenance>,
    /// Timestamp de criação
    pub created_at: Option<i64>,
}

/// Proveniência de dados
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Provenance {
    /// Identificador da fonte
    pub source_id: String,
    /// Tipo de fonte
    pub source_type: SourceType,
    /// Chain of custody (hashes)
    pub chain: SmallVec<[Hash256; 4]>,
}

/// Tipo de fonte de dados
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SourceType {
    /// Entrada do usuário
    User,
    /// Sistema interno
    Internal,
    /// Conector externo
    External,
    /// Síntese/geração
    Synthetic,
    /// Desconhecido
    Unknown,
}

/// Hash de 256 bits (Blake3)
#[derive(Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct Hash256(pub [u8; 32]);

impl Hash256 {
    /// Hash zero
    pub const ZERO: Self = Self([0u8; 32]);

    /// Cria hash a partir de bytes
    pub fn from_bytes(data: &[u8]) -> Self {
        Self(blake3::hash(data).into())
    }

    /// Converte para hex string
    pub fn to_hex(&self) -> String {
        hex::encode(self.0)
    }
}

impl fmt::Debug for Hash256 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Hash256({}...)", &self.to_hex()[..8])
    }
}

impl fmt::Display for Hash256 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", &self.to_hex()[..16])
    }
}

/// Divergência normalizada entre objetos [0, 1]
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Divergence(f64);

impl Divergence {
    /// Divergência zero (objetos idênticos)
    pub const ZERO: Self = Self(0.0);
    
    /// Divergência máxima
    pub const MAX: Self = Self(1.0);

    /// Cria nova divergência, clampando ao intervalo [0, 1]
    pub fn new(value: f64) -> Self {
        Self(value.clamp(0.0, 1.0))
    }

    /// Valor interno
    pub fn value(&self) -> f64 {
        self.0
    }

    /// Calcula divergência entre dois conjuntos de bytes
    pub fn between(a: &[u8], b: &[u8]) -> Self {
        if a == b {
            return Self::ZERO;
        }
        if a.is_empty() && b.is_empty() {
            return Self::ZERO;
        }
        
        let max_len = a.len().max(b.len());
        let min_len = a.len().min(b.len());
        
        // Diferença de tamanho
        let size_diff = (a.len() as f64 - b.len() as f64).abs() / max_len as f64;
        
        // Diferença de conteúdo (Hamming normalizado)
        let content_diff: f64 = a.iter()
            .zip(b.iter())
            .map(|(x, y)| if x != y { 1.0 } else { 0.0 })
            .sum::<f64>() / min_len.max(1) as f64;
        
        Self::new((size_diff + content_diff) / 2.0)
    }
}

impl Default for Divergence {
    fn default() -> Self {
        Self::ZERO
    }
}

/// Escore normalizado [0, 1]
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize)]
pub struct Score(f64);

impl Score {
    /// Escore zero
    pub const ZERO: Self = Self(0.0);
    
    /// Escore máximo
    pub const MAX: Self = Self(1.0);

    /// Cria novo escore, clampando ao intervalo [0, 1]
    pub fn new(value: f64) -> Self {
        Self(value.clamp(0.0, 1.0))
    }

    /// Valor interno
    pub fn value(&self) -> f64 {
        self.0
    }

    /// Média geométrica de múltiplos scores
    pub fn geometric_mean(scores: &[Self]) -> Self {
        if scores.is_empty() {
            return Self::ZERO;
        }
        let product: f64 = scores.iter().map(|s| s.0).product();
        Self::new(product.powf(1.0 / scores.len() as f64))
    }

    /// Média ponderada
    pub fn weighted_mean(scores: &[(Self, f64)]) -> Self {
        let total_weight: f64 = scores.iter().map(|(_, w)| w).sum();
        if total_weight == 0.0 {
            return Self::ZERO;
        }
        let weighted_sum: f64 = scores.iter()
            .map(|(s, w)| s.0 * w)
            .sum();
        Self::new(weighted_sum / total_weight)
    }
}

impl Default for Score {
    fn default() -> Self {
        Self::ZERO
    }
}

impl std::ops::Mul for Score {
    type Output = Self;
    fn mul(self, rhs: Self) -> Self::Output {
        Self::new(self.0 * rhs.0)
    }
}

/// Resultado de uma decisão
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Decision {
    /// Identificador único
    pub id: uuid::Uuid,
    /// Tipo de decisão
    pub decision_type: DecisionType,
    /// Ação escolhida
    pub action: String,
    /// Confiança na decisão
    pub confidence: Score,
    /// Razões para a decisão
    pub reasons: Vec<String>,
    /// Timestamp
    pub timestamp: i64,
}

/// Tipo de decisão
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DecisionType {
    /// Ação permitida
    Allow,
    /// Ação bloqueada
    Block,
    /// Requer confirmação do usuário
    AskUser,
    /// Abstenção racional
    Abstain,
    /// Degradação graceful
    Degrade,
}

/// Capacidade do sistema
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Capability {
    /// Nome da capacidade
    pub name: String,
    /// Descrição
    pub description: String,
    /// Custo estimado
    pub cost: f64,
    /// Latência estimada (ms)
    pub latency_hint: u32,
    /// Escopo
    pub scope: CapabilityScope,
}

/// Escopo de capacidade
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CapabilityScope {
    /// Geral
    General,
    /// Debug apenas
    Debug,
    /// Rede
    Network,
    /// Sistema de arquivos
    Filesystem,
    /// Processamento numérico
    Numeric,
    /// NLP/Linguagem
    Nlp,
}

/// Span de tempo para medições
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct TimeSpan {
    /// Início (nanos desde epoch)
    pub start: u64,
    /// Duração (nanos)
    pub duration: u64,
}

impl TimeSpan {
    /// Cria novo span
    pub fn new(start: u64, duration: u64) -> Self {
        Self { start, duration }
    }

    /// Duração em milliseconds
    pub fn duration_ms(&self) -> f64 {
        self.duration as f64 / 1_000_000.0
    }
}

// Helper para hex encoding (minimalista, sem dep externa pesada)
mod hex {
    const HEX_CHARS: &[u8; 16] = b"0123456789abcdef";
    
    pub fn encode(bytes: &[u8]) -> String {
        let mut s = String::with_capacity(bytes.len() * 2);
        for &b in bytes {
            s.push(HEX_CHARS[(b >> 4) as usize] as char);
            s.push(HEX_CHARS[(b & 0xf) as usize] as char);
        }
        s
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_divergence() {
        let d = Divergence::between(b"hello", b"hello");
        assert_eq!(d, Divergence::ZERO);

        let d = Divergence::between(b"hello", b"world");
        assert!(d.value() > 0.0);
    }

    #[test]
    fn test_score_geometric_mean() {
        let scores = vec![
            Score::new(0.8),
            Score::new(0.9),
            Score::new(0.7),
        ];
        let mean = Score::geometric_mean(&scores);
        assert!(mean.value() > 0.7 && mean.value() < 0.9);
    }

    #[test]
    fn test_hash256() {
        let h1 = Hash256::from_bytes(b"test");
        let h2 = Hash256::from_bytes(b"test");
        assert_eq!(h1, h2);
        
        let h3 = Hash256::from_bytes(b"different");
        assert_ne!(h1, h3);
    }
}
