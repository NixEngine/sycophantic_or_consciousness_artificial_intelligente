//! # Transformadores Px
//!
//! Implementação de transformadores (programas finitos) que mapeiam D → D.
//! Cada transformador tem um comprimento descritivo ℓ(Φ) e custo estimado.

use crate::{PxContext, PxError, PxResult, Transformer};
use serde::{Deserialize, Serialize};

/// Transformador identidade (não faz nada)
pub struct IdentityTransform;

impl Transformer for IdentityTransform {
    fn name(&self) -> &str {
        "identity"
    }

    fn transform(&self, data: &[u8], _ctx: &mut PxContext) -> PxResult<Vec<u8>> {
        Ok(data.to_vec())
    }

    fn description_length(&self) -> f64 {
        1.0 // Transformador mais simples possível
    }
}

/// Transformador de normalização de bytes
pub struct NormalizeTransform {
    /// Valor mínimo para normalização
    pub min: u8,
    /// Valor máximo para normalização
    pub max: u8,
}

impl Default for NormalizeTransform {
    fn default() -> Self {
        Self { min: 0, max: 255 }
    }
}

impl Transformer for NormalizeTransform {
    fn name(&self) -> &str {
        "normalize"
    }

    fn transform(&self, data: &[u8], _ctx: &mut PxContext) -> PxResult<Vec<u8>> {
        if data.is_empty() {
            return Ok(Vec::new());
        }

        let actual_min = *data.iter().min().unwrap();
        let actual_max = *data.iter().max().unwrap();
        let range = actual_max.saturating_sub(actual_min) as f64;

        if range == 0.0 {
            return Ok(vec![128u8; data.len()]);
        }

        let target_range = (self.max - self.min) as f64;

        Ok(data
            .iter()
            .map(|&x| {
                let normalized = (x.saturating_sub(actual_min) as f64 / range) * target_range;
                self.min.saturating_add(normalized as u8)
            })
            .collect())
    }

    fn description_length(&self) -> f64 {
        24.0 // 2 bytes de parâmetros + overhead
    }
}

/// Transformador de diferenciação (delta encoding)
pub struct DiffTransform;

impl Transformer for DiffTransform {
    fn name(&self) -> &str {
        "diff"
    }

    fn transform(&self, data: &[u8], _ctx: &mut PxContext) -> PxResult<Vec<u8>> {
        if data.is_empty() {
            return Ok(Vec::new());
        }

        let mut result = Vec::with_capacity(data.len());
        result.push(data[0]);

        for i in 1..data.len() {
            result.push(data[i].wrapping_sub(data[i - 1]));
        }

        Ok(result)
    }

    fn description_length(&self) -> f64 {
        8.0 // Operação muito simples
    }
}

/// Transformador XOR com chave fixa
pub struct XorTransform {
    /// Chave XOR
    pub key: u8,
}

impl XorTransform {
    /// Cria transformador XOR com chave específica
    pub fn new(key: u8) -> Self {
        Self { key }
    }
}

impl Default for XorTransform {
    fn default() -> Self {
        Self { key: 0x55 }
    }
}

impl Transformer for XorTransform {
    fn name(&self) -> &str {
        "xor"
    }

    fn transform(&self, data: &[u8], _ctx: &mut PxContext) -> PxResult<Vec<u8>> {
        Ok(data.iter().map(|&x| x ^ self.key).collect())
    }

    fn description_length(&self) -> f64 {
        16.0 // 1 byte de chave + overhead
    }
}

/// Transformador de suavização (média móvel)
pub struct SmoothTransform {
    /// Tamanho da janela
    pub window_size: usize,
}

impl Default for SmoothTransform {
    fn default() -> Self {
        Self { window_size: 3 }
    }
}

impl Transformer for SmoothTransform {
    fn name(&self) -> &str {
        "smooth"
    }

    fn transform(&self, data: &[u8], _ctx: &mut PxContext) -> PxResult<Vec<u8>> {
        if data.len() < self.window_size {
            return Ok(data.to_vec());
        }

        let mut result = Vec::with_capacity(data.len());
        let half_window = self.window_size / 2;

        for i in 0..data.len() {
            let start = i.saturating_sub(half_window);
            let end = (i + half_window + 1).min(data.len());
            let sum: u32 = data[start..end].iter().map(|&x| x as u32).sum();
            let avg = (sum / (end - start) as u32) as u8;
            result.push(avg);
        }

        Ok(result)
    }

    fn description_length(&self) -> f64 {
        16.0 + (self.window_size as f64).log2() * 4.0
    }
}

/// Transformador de quantização
pub struct QuantizeTransform {
    /// Número de níveis de quantização
    pub levels: u8,
}

impl Default for QuantizeTransform {
    fn default() -> Self {
        Self { levels: 16 }
    }
}

impl Transformer for QuantizeTransform {
    fn name(&self) -> &str {
        "quantize"
    }

    fn transform(&self, data: &[u8], _ctx: &mut PxContext) -> PxResult<Vec<u8>> {
        if self.levels == 0 {
            return Err(PxError::InvalidData("Levels must be > 0".into()));
        }

        let step = 256 / self.levels as u16;

        Ok(data
            .iter()
            .map(|&x| {
                let level = (x as u16 / step).min(self.levels as u16 - 1);
                (level * step + step / 2) as u8
            })
            .collect())
    }

    fn description_length(&self) -> f64 {
        16.0 + (self.levels as f64).log2() * 8.0
    }
}

/// Transformador de remoção de zeros (run-length para zeros)
pub struct ZeroRemoveTransform;

impl Transformer for ZeroRemoveTransform {
    fn name(&self) -> &str {
        "zero_remove"
    }

    fn transform(&self, data: &[u8], _ctx: &mut PxContext) -> PxResult<Vec<u8>> {
        let mut result = Vec::new();
        let mut zero_count = 0u8;

        for &byte in data {
            if byte == 0 {
                zero_count = zero_count.saturating_add(1);
                if zero_count == 255 {
                    result.push(0);
                    result.push(255);
                    zero_count = 0;
                }
            } else {
                if zero_count > 0 {
                    result.push(0);
                    result.push(zero_count);
                    zero_count = 0;
                }
                result.push(byte);
            }
        }

        if zero_count > 0 {
            result.push(0);
            result.push(zero_count);
        }

        Ok(result)
    }

    fn description_length(&self) -> f64 {
        32.0 // Lógica de escape + contagem
    }
}

/// Composição de transformadores
pub struct ComposedTransform {
    transforms: Vec<Box<dyn Transformer>>,
    name: String,
}

impl ComposedTransform {
    /// Cria nova composição vazia
    pub fn new(name: impl Into<String>) -> Self {
        Self {
            transforms: Vec::new(),
            name: name.into(),
        }
    }

    /// Adiciona transformador à composição
    pub fn add(mut self, transform: Box<dyn Transformer>) -> Self {
        self.transforms.push(transform);
        self
    }

    /// Número de transformadores na composição
    pub fn len(&self) -> usize {
        self.transforms.len()
    }

    /// Verifica se está vazia
    pub fn is_empty(&self) -> bool {
        self.transforms.is_empty()
    }
}

impl Transformer for ComposedTransform {
    fn name(&self) -> &str {
        &self.name
    }

    fn transform(&self, data: &[u8], ctx: &mut PxContext) -> PxResult<Vec<u8>> {
        let mut current = data.to_vec();

        for transform in &self.transforms {
            current = transform.transform(&current, ctx)?;
            ctx.check_memory_budget()?;
        }

        Ok(current)
    }

    fn description_length(&self) -> f64 {
        let base: f64 = self.transforms.iter().map(|t| t.description_length()).sum();
        // Adiciona overhead de composição
        base + (self.transforms.len() as f64).log2() * 8.0
    }
}

/// Registro de transformadores disponíveis
#[derive(Default)]
pub struct TransformRegistry {
    transforms: Vec<Box<dyn Transformer>>,
}

impl TransformRegistry {
    /// Cria registro vazio
    pub fn new() -> Self {
        Self::default()
    }

    /// Cria registro com transformadores padrão
    pub fn default_registry() -> Self {
        let mut registry = Self::new();
        registry.register(Box::new(IdentityTransform));
        registry.register(Box::new(DiffTransform));
        registry.register(Box::new(NormalizeTransform::default()));
        registry.register(Box::new(SmoothTransform::default()));
        registry.register(Box::new(QuantizeTransform::default()));
        registry.register(Box::new(ZeroRemoveTransform));
        registry
    }

    /// Registra novo transformador
    pub fn register(&mut self, transform: Box<dyn Transformer>) {
        self.transforms.push(transform);
    }

    /// Busca transformador por nome
    pub fn get(&self, name: &str) -> Option<&dyn Transformer> {
        self.transforms.iter().find(|t| t.name() == name).map(|t| t.as_ref())
    }

    /// Lista todos os transformadores
    pub fn list(&self) -> Vec<TransformInfo> {
        self.transforms
            .iter()
            .map(|t| TransformInfo {
                name: t.name().to_string(),
                description_length: t.description_length(),
                estimated_cost: t.estimated_cost(),
            })
            .collect()
    }

    /// Itera sobre transformadores
    pub fn iter(&self) -> impl Iterator<Item = &dyn Transformer> {
        self.transforms.iter().map(|t| t.as_ref())
    }

    /// Número de transformadores registrados
    pub fn len(&self) -> usize {
        self.transforms.len()
    }

    /// Verifica se está vazio
    pub fn is_empty(&self) -> bool {
        self.transforms.is_empty()
    }
}

/// Informações sobre um transformador
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransformInfo {
    /// Nome do transformador
    pub name: String,
    /// Comprimento descritivo em bits
    pub description_length: f64,
    /// Custo estimado
    pub estimated_cost: f64,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::PxConfig;

    #[test]
    fn test_identity_transform() {
        let transform = IdentityTransform;
        let mut ctx = PxContext::new(PxConfig::default());
        let data = b"test data";

        let result = transform.transform(data, &mut ctx).unwrap();
        assert_eq!(data.as_slice(), result.as_slice());
    }

    #[test]
    fn test_diff_transform() {
        let transform = DiffTransform;
        let mut ctx = PxContext::new(PxConfig::default());
        let data = vec![1, 2, 3, 4, 5];

        let result = transform.transform(&data, &mut ctx).unwrap();
        assert_eq!(result, vec![1, 1, 1, 1, 1]); // Deltas
    }

    #[test]
    fn test_smooth_transform() {
        let transform = SmoothTransform { window_size: 3 };
        let mut ctx = PxContext::new(PxConfig::default());
        let data = vec![0, 10, 0, 10, 0];

        let result = transform.transform(&data, &mut ctx).unwrap();
        // Média móvel suaviza os picos
        assert!(result.iter().all(|&x| x > 0 && x < 10));
    }

    #[test]
    fn test_composed_transform() {
        let composed = ComposedTransform::new("diff_then_quantize")
            .add(Box::new(DiffTransform))
            .add(Box::new(QuantizeTransform { levels: 4 }));

        let mut ctx = PxContext::new(PxConfig::default());
        let data = vec![10, 20, 30, 40, 50];

        let result = composed.transform(&data, &mut ctx).unwrap();
        assert_eq!(result.len(), data.len());
    }

    #[test]
    fn test_transform_registry() {
        let registry = TransformRegistry::default_registry();
        
        assert!(registry.get("identity").is_some());
        assert!(registry.get("diff").is_some());
        assert!(registry.len() >= 6);
    }
}
