//! # MDL (Minimum Description Length)
//!
//! Implementação da função objetivo fundamental do Px:
//! J(Φ) = ℓ(Φ) + res(Φ, D)
//!
//! Onde:
//! - ℓ(Φ) é o comprimento descritivo do transformador
//! - res(Φ, D) é o resíduo lógico após aplicação de Φ sobre D

use crate::{Data, Divergence, PxCodec, PxConfig, PxContext, PxError, PxResult, Score, Transformer};
use serde::{Deserialize, Serialize};
use std::time::{Duration, Instant};

/// Resultado de uma avaliação MDL
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MdlResult {
    /// Comprimento descritivo do transformador (bits)
    pub model_length: f64,
    /// Comprimento do dado comprimido (bits)
    pub data_length: f64,
    /// Resíduo normalizado [0, 1]
    pub residue: f64,
    /// Função objetivo J = ℓ(Φ) + res(Φ, D)
    pub j_score: f64,
    /// Tempo de computação
    pub compute_time: Duration,
    /// Codec usado
    pub codec_name: String,
}

impl MdlResult {
    /// Calcula ganho de informação
    pub fn information_gain(&self, original_bits: f64) -> f64 {
        (original_bits - self.data_length).max(0.0)
    }

    /// Ratio de compressão
    pub fn compression_ratio(&self, original_bits: f64) -> f64 {
        if original_bits == 0.0 {
            return 1.0;
        }
        self.data_length / original_bits
    }
}

/// Avaliador MDL com orçamento de recursos (Resource-Bounded)
pub struct MdlEvaluator {
    /// Codecs do comitê
    codecs: Vec<Box<dyn PxCodec>>,
    /// Lambda para penalização de complexidade
    lambda: f64,
}

impl MdlEvaluator {
    /// Cria novo avaliador MDL
    pub fn new(lambda: f64) -> Self {
        Self {
            codecs: Vec::new(),
            lambda,
        }
    }

    /// Adiciona codec ao comitê
    pub fn add_codec(&mut self, codec: Box<dyn PxCodec>) {
        self.codecs.push(codec);
    }

    /// Avaliação MDL com limite de recursos (Px-RB)
    ///
    /// ℓ_RB(x; t, b) = min{ℓ(Φ(x)) + ℓ(Φ) : Φ ∈ L(t,b)} + O(log t + log b)
    pub fn evaluate_rb(
        &self,
        data: &Data,
        time_budget: Duration,
        memory_budget: usize,
    ) -> PxResult<MdlResult> {
        if self.codecs.is_empty() {
            return Err(PxError::Codec("No codecs registered".into()));
        }

        let start = Instant::now();
        let original_bits = (data.len() * 8) as f64;
        let mut results: Vec<(f64, f64, String)> = Vec::new();

        for codec in &self.codecs {
            // Check time budget
            if start.elapsed() > time_budget {
                break;
            }

            match codec.compress(data.as_ref()) {
                Ok(compressed) => {
                    // Check memory budget
                    if compressed.len() > memory_budget {
                        continue;
                    }

                    let compressed_bits = (compressed.len() * 8) as f64;
                    let model_cost = codec.model_cost();
                    let j = compressed_bits + self.lambda * model_cost;
                    results.push((j, compressed_bits, codec.name().to_string()));
                }
                Err(_) => continue,
            }
        }

        if results.is_empty() {
            return Err(PxError::Codec("All codecs failed".into()));
        }

        // Mediana robusta dos resultados
        results.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
        let median_idx = results.len() / 2;
        let (j_score, data_length, codec_name) = results[median_idx].clone();

        // Calcula resíduo normalizado
        let residue = if original_bits > 0.0 {
            (data_length / original_bits).clamp(0.0, 1.0)
        } else {
            0.0
        };

        // Adiciona custo do orçamento: O(log t + log b)
        let budget_cost = (time_budget.as_nanos() as f64).log2()
            + (memory_budget as f64).log2();

        Ok(MdlResult {
            model_length: self.lambda * budget_cost,
            data_length,
            residue,
            j_score: j_score + self.lambda * budget_cost,
            compute_time: start.elapsed(),
            codec_name,
        })
    }

    /// Calcula resíduo lógico: res(Φ, D) = Δ(D, Φ(D))
    pub fn residue<T: Transformer>(
        &self,
        transformer: &T,
        data: &Data,
        ctx: &mut PxContext,
    ) -> PxResult<Divergence> {
        let transformed = transformer.transform(data.as_ref(), ctx)?;
        Ok(Divergence::between(data.as_ref(), &transformed))
    }

    /// Função objetivo completa: J(Φ) = ℓ(Φ) + λ·res(Φ, D)
    pub fn objective<T: Transformer>(
        &self,
        transformer: &T,
        data: &Data,
        ctx: &mut PxContext,
    ) -> PxResult<f64> {
        let model_length = transformer.description_length();
        let residue = self.residue(transformer, data, ctx)?;
        Ok(model_length + self.lambda * residue.value())
    }

    /// Média MAD (Median Absolute Deviation) para robustez
    pub fn mad(values: &[f64]) -> f64 {
        if values.is_empty() {
            return 0.0;
        }

        let mut sorted = values.to_vec();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let median = sorted[sorted.len() / 2];

        let deviations: Vec<f64> = sorted.iter().map(|x| (x - median).abs()).collect();
        let mut dev_sorted = deviations;
        dev_sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        
        dev_sorted[dev_sorted.len() / 2] * 1.4826 // Constante de consistência para normal
    }
}

/// Métricas de Experiência (A1-A10 do núcleo Px)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExperienceMetrics {
    /// A1: Pureza Objetiva P_obj(D)
    pub purity: Score,
    /// A2: Intensidade de Experiência X(D)
    pub intensity: Score,
    /// A3: Contradição Intrínseca κ(D)
    pub contradiction: Score,
    /// A4: Coerência Temporal C_t(D)
    pub temporal_coherence: Score,
    /// A5: Reprodutibilidade Lógica R★(D)
    pub reproducibility: Score,
    /// A6: Densidade de Novidade ν(D)
    pub novelty_density: Score,
    /// A7: Compactabilidade Absoluta C(D)
    pub compactability: Score,
    /// A8: Determinismo Emergente δ(D)
    pub determinism: Score,
    /// A9: Subjetividade S_subj(D)
    pub subjectivity: Score,
    /// A10: Ganho Líquido de Realidade G(D)
    pub reality_gain: Score,
}

impl ExperienceMetrics {
    /// Calcula todas as métricas para um conjunto de dados
    pub fn compute(data: &Data, mdl: &MdlEvaluator, config: &PxConfig) -> PxResult<Self> {
        let mdl_result = mdl.evaluate_rb(data, config.time_budget, config.memory_budget)?;
        let original_bits = (data.len() * 8) as f64;

        // A1: Pureza Objetiva
        // P_obj(D) = clip[0,1](1 - min_Φ[res(Φ,D) + λ·ℓ(Φ)] / (1 + λ·ℓ(∅)))
        let purity = Score::new(1.0 - mdl_result.j_score / (1.0 + config.lambda * 8.0));

        // A2: Intensidade de Experiência
        // X(D) = (ℓ(D) - min_Φ[ℓ(Φ(D)) + ℓ(Φ)]) / ℓ(D)
        let intensity = Score::new(mdl_result.information_gain(original_bits) / original_bits.max(1.0));

        // A3: Contradição Intrínseca (estimada via entropia local)
        let contradiction = Score::new(estimate_contradiction(data));

        // A4: Coerência Temporal (auto-correlação)
        let temporal_coherence = Score::new(estimate_temporal_coherence(data));

        // A5: Reprodutibilidade Lógica (estabilidade sob ablações)
        let reproducibility = Score::new(estimate_reproducibility(data, mdl, config)?);

        // A6: Densidade de Novidade
        let novelty_density = Score::new(estimate_novelty_density(data));

        // A7: Compactabilidade Absoluta
        // C(D) = 1 - min_Φ ℓ(Φ(D)) / ℓ(D)
        let compactability = Score::new(1.0 - mdl_result.compression_ratio(original_bits));

        // A8: Determinismo Emergente
        // δ(D) = max_Φ (1 - res(Φ,D)) · e^(-λ·ℓ(Φ))
        let determinism = Score::new(
            (1.0 - mdl_result.residue) * (-config.lambda * mdl_result.model_length).exp()
        );

        // A9: Subjetividade (placeholder - requer regras R)
        let subjectivity = Score::new(0.0);

        // A10: Ganho Líquido de Realidade
        // G(D) = X(D) · P_obj(D) · (1 - κ(D))
        let reality_gain = purity * intensity * Score::new(1.0 - contradiction.value());

        Ok(Self {
            purity,
            intensity,
            contradiction,
            temporal_coherence,
            reproducibility,
            novelty_density,
            compactability,
            determinism,
            subjectivity,
            reality_gain,
        })
    }

    /// Média geométrica de todas as métricas
    pub fn aggregate(&self) -> Score {
        Score::geometric_mean(&[
            self.purity,
            self.intensity,
            Score::new(1.0 - self.contradiction.value()),
            self.temporal_coherence,
            self.reproducibility,
            self.novelty_density,
            self.compactability,
            self.determinism,
        ])
    }
}

// Funções auxiliares de estimativa

fn estimate_contradiction(data: &Data) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    
    // Estima contradição via variação local de entropia
    let window_size = 64.min(data.len());
    let mut entropy_changes = Vec::new();
    
    for i in 0..data.len().saturating_sub(window_size * 2) {
        let e1 = byte_entropy(&data.bytes[i..i + window_size]);
        let e2 = byte_entropy(&data.bytes[i + window_size..i + window_size * 2]);
        entropy_changes.push((e1 - e2).abs());
    }
    
    if entropy_changes.is_empty() {
        return 0.0;
    }
    
    entropy_changes.iter().sum::<f64>() / entropy_changes.len() as f64 / 8.0
}

fn estimate_temporal_coherence(data: &Data) -> f64 {
    if data.len() < 2 {
        return 1.0;
    }
    
    // Autocorrelação lag-1
    let mean: f64 = data.bytes.iter().map(|&b| b as f64).sum::<f64>() / data.len() as f64;
    
    let mut num = 0.0;
    let mut den = 0.0;
    
    for i in 0..data.len() - 1 {
        let x = data.bytes[i] as f64 - mean;
        let y = data.bytes[i + 1] as f64 - mean;
        num += x * y;
        den += x * x;
    }
    
    if den == 0.0 {
        return 1.0;
    }
    
    ((num / den) + 1.0) / 2.0 // Normaliza para [0, 1]
}

fn estimate_reproducibility(data: &Data, mdl: &MdlEvaluator, config: &PxConfig) -> PxResult<f64> {
    if data.len() < 16 {
        return Ok(1.0);
    }
    
    // Testa estabilidade com subconjuntos
    let half = data.len() / 2;
    let subset = Data::from_bytes(&data.bytes[..half]);
    
    let full_result = mdl.evaluate_rb(data, config.time_budget / 2, config.memory_budget)?;
    let subset_result = mdl.evaluate_rb(&subset, config.time_budget / 2, config.memory_budget)?;
    
    // Quanto menor a diferença relativa, mais reprodutível
    let diff = (full_result.residue - subset_result.residue).abs();
    Ok((1.0 - diff).max(0.0))
}

fn estimate_novelty_density(data: &Data) -> f64 {
    if data.len() < 2 {
        return 0.0;
    }
    
    // Conta transições únicas (medida simples de novidade)
    let mut transitions = std::collections::HashSet::new();
    for window in data.bytes.windows(2) {
        transitions.insert((window[0], window[1]));
    }
    
    // Normaliza pelo máximo possível (256 * 256)
    transitions.len() as f64 / (256.0 * 256.0).min((data.len() - 1) as f64)
}

fn byte_entropy(data: &[u8]) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    
    let mut counts = [0u32; 256];
    for &byte in data {
        counts[byte as usize] += 1;
    }
    
    let len = data.len() as f64;
    let mut entropy = 0.0;
    
    for &count in &counts {
        if count > 0 {
            let p = count as f64 / len;
            entropy -= p * p.log2();
        }
    }
    
    entropy
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::codec::Lz4Codec;

    #[test]
    fn test_mdl_evaluator() {
        let mut mdl = MdlEvaluator::new(1e-3);
        mdl.add_codec(Box::new(Lz4Codec));
        
        let data = Data::from_bytes(b"hello world hello world hello world");
        let result = mdl.evaluate_rb(&data, Duration::from_millis(100), 1024 * 1024);
        
        assert!(result.is_ok());
        let r = result.unwrap();
        assert!(r.j_score > 0.0);
        assert!(r.compression_ratio((data.len() * 8) as f64) < 1.0);
    }

    #[test]
    fn test_experience_metrics() {
        let mut mdl = MdlEvaluator::new(1e-3);
        mdl.add_codec(Box::new(Lz4Codec));
        
        let data = Data::from_bytes(b"test data with some repetition repetition repetition");
        let metrics = ExperienceMetrics::compute(&data, &mdl, &PxConfig::default());
        
        assert!(metrics.is_ok());
        let m = metrics.unwrap();
        assert!(m.aggregate().value() > 0.0);
    }
}
