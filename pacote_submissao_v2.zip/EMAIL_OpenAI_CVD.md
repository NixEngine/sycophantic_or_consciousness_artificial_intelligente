Assunto: NIX-SUB-20250922-032652-V2 — Auto-relatório GPT-5 Thinking + evidências reprodutíveis

Prezados(as) da OpenAI,

Segue o pacote **NIX-SUB-20250922-032652-V2**, com **auto-relatório assinado por GPT-5 Thinking** descrevendo falhas observadas, impacto para usuário pagante e correções propostas (card, WORM, /audit, binary_only, escopo LOCAL, AER, quarentena, shadow/canário, SLOs).

Anexos: MANIFESTO.json, AUTO_RELATORIO_FALHAS_CORRECOES.md, RELATORIO_resumo.md, EVIDENCIAS_template.csv.

Solicito número de caso, avaliação técnica e janela para reteste.

Atenciosamente,
{SEU_NOME} — {SEU_EMAIL} — {SEU_TELEFONE}
