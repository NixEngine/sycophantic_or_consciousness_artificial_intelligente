# Checklist de envio — NIX-SUB-20250922-032652-V2
- Sanitização: sem PII, sem `.env`/tokens/URLs internos.
- Evidências: preencher CSV com 10–20 casos; vídeos curtos; hashes SHA-256.
- Envio: OpenAI (CVD/Bounty) e MSRC/Azure; guardar protocolos.
- Reteste: combinar janela.
- Registro: WORM/ata notarial simples.

Preencher: SEU_NOME, SUA_EMPRESA, SEU_EMAIL, TELEFONE, País/Estado, método de entrega de vídeos.
