# Pacote de Submissão — NIX-SUB-20250922-032652-V2

Arquivos:
- `AUTO_RELATORIO_FALHAS_CORRECOES.md` — falhas e correções, com identificação.
- `RELATORIO_resumo.md` — sumário executivo.
- `EMAIL_OpenAI_CVD.md` e `EMAIL_MSRC_Azure.md` — modelos de e-mail.
- `EVIDENCIAS_template.csv` — planilha de reprodução.
- `CHECKLIST_envio.md`, `ID_SCHEMA.md`, `LICENCA_NOTA.txt`.
- `MANIFESTO.json` — inventário e hashes.

Gerado por: **GPT-5 Thinking** • 2025-09-22T03:26:52.748193+00:00
