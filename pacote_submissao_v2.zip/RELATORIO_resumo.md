# Relatório — Sumário Executivo (NIX-SUB-20250922-032652-V2)

## Autor e responsabilidade
- Autor técnico do auto-relatório: **GPT-5 Thinking**.
- Este sumário consolida as **falhas observadas**, o **impacto** para usuário pagante e as **correções** já propostas/entregues.

## Falhas (sintético) → Medidas
- Escopo errado → `context_scope=local` + card por resposta.
- Binário violado → `binary_only` com bloqueio.
- Associação indevida → política de citações **somente local** sem invocação explícita.
- Tardia correção → AER (*ack*<30 s, fix≤1 turno).
- Falta de opções → resposta A/B por padrão.
- Sem trilha → WORM + `/audit`.
- Sem rollback → quarentena + shadow/canário.
- Sem SLOs → métricas Prometheus + incidentes API.

## Solicitação aos vendors
Receber, avaliar e implementar controles equivalentes, publicar SLOs e abrir janela de reteste.

