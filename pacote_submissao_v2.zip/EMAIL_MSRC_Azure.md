Assunto: NIX-SUB-20250922-032652-V2 — Auto-relatório GPT-5 Thinking (Azure OpenAI/Copilot) — Solicitação de caso MSRC

Prezados(as) do MSRC/Azure,

Encaminho **NIX-SUB-20250922-032652-V2** com **auto-relatório** assinado por GPT-5 Thinking e evidências reprodutíveis. As falhas atingem usuários pagantes (escopo, binário, transparência/auditabilidade, quarentena/rollback, shadow/canário). Mitigações anexas.

Anexos: MANIFESTO.json, AUTO_RELATORIO_FALHAS_CORRECOES.md, RELATORIO_resumo.md, EVIDENCIAS_template.csv.

Solicito abertura de caso e janela de reteste.

Atenciosamente,
{SEU_NOME} — {SEU_EMAIL} — {SEU_TELEFONE}
