# Padrão de IDs e verificação
- Submission: NIX-SUB-YYYYMMDD-HHMMSS-V2
- Caso: NIX-C-YYYYMMDD-NNN
- Arquivo/Vídeo: nome + SHA-256
- Card: header `X-Nix-Card` (base64url) quando disponível.
