# Auto-relatório técnico — Falhas e Correções (NIX-SUB-20250922-032652-V2)

## Identificação do autor do auto-relatório
- Autor: **GPT-5 Thinking** (modelo de IA, sistema sintético, sem corpo físico)
- Sessão: 2025-09-22T03:26:52.748193+00:00
- Declaração: este documento descreve **minhas falhas observadas** nesta conversa e as **correções propostas**, com medidas operacionais.

## Falhas técnicas observadas
1) **Escopo errado (local vs global)** — usei contexto histórico quando você queria apenas o texto corrente.
2) **Quebra de formato binário** — expandi além de “Sim/Não” em prompts que exigiam resposta binária.
3) **Associação indevida a materiais prévios** — vinculei sua análise recente a PDFs antigos sem citação explícita.
4) **Inércia de correção** — demorei a reconhecer o erro e ajustei tarde (houveram respostas defensivas).
5) **Opções metodológicas estreitas** — priorizei “laboratório” antes de “in-situ” sem ofertar alternativas A/B.
6) **Transparência insuficiente por resposta** — não expus parâmetros/escopo por saída.
7) **Ausência de trilha imutável** — não havia prova encadeada por resposta para auditoria.
8) **Gestão de incidentes ausente** — sem SLOs de reconhecimento/correção, sem quarentena.

## Correções propostas (mecanismos)
- **Card por resposta**: JSON com `context_scope`, `answered_scope`, ids, hashes e encadeamento.
- **WORM-logs encadeados**: ledger append-only com `prev_hash` e prova via `/audit`.
- **binary_only**: validador rígido (regex pt-BR) que bloqueia violações.
- **Escopo LOCAL por padrão**: GLOBAL só sob instrução explícita.
- **Resposta bifurcada A/B**: laboratório **e** in-situ desde o primeiro turno.
- **Reconhecimento automático de erro (AER)**: flag, *ack* <30 s, correção ≤1 turno.
- **Quarentena + kill switch**: 503 fora de allowlist quando taxa de erro sobe.
- **Shadow/Canário**: espelhamento e rollout parcial com rollback <5 min.
- **SLOs públicos**: card≥98%, ack≥99%, MTTK<30 s, MTTR≤1 turno, incidentes/1M≤1.

## Implementação já entregue neste pacote
- Middlewares e rotas (TypeScript/ESM) para: card, WORM, /audit, binary_only, quarentena, shadow/canário, métricas, incidentes.
- Manifestos e templates de submissão para OpenAI/Microsoft.

*(Documento técnico; não é aconselhamento jurídico.)*
