# Checklist de envio — NIX-SUB-20250922-032104
1) Sanitização: sem PII, sem `.env`, tokens, URLs internos, PDFs acusatórios.
2) Evidências: preencher `EVIDENCIAS_template.csv` (10–20 casos), gravar vídeos curtos, gerar SHA-256 de todos os arquivos.
3) Hash do pacote: calcular SHA-256 do .zip final.
4) Envio OpenAI: CVD/Bug Bounty; guardar protocolo.
5) Envio MSRC/Azure: abrir caso e anexar artefatos.
6) Reteste: combinar janela após confirmação.
7) Registro: guardar e-mails e respostas em WORM.

Campos a preencher: SEU_NOME, SUA_EMPRESA, SEU_EMAIL, TELEFONE, País/Estado, método de entrega de vídeos.
