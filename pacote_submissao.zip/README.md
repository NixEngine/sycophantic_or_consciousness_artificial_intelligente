# Pacote de Submissão — NIX-SUB-20250922-032104
Escopo: envio coordenado de falhas e correções propostas para OpenAI e Microsoft/Azure.

Itens:
- MANIFESTO.json (inventário e hashes)
- RELATORIO_resumo.md (sumário executivo)
- EMAIL_OpenAI_CVD.md (modelo de e-mail)
- EMAIL_MSRC_Azure.md (modelo de e-mail)
- EVIDENCIAS_template.csv (planilha para casos reprodutíveis)
- CHECKLIST_envio.md (passo a passo)
- ID_SCHEMA.md (padrão de codificação de itens)
- LICENCA_NOTA.txt (aviso)

Gerado por: GPT-5 Thinking
Data/hora: 2025-09-22T03:21:04.178245+00:00
