Assunto: NIX-SUB-20250922-032104 — Relato técnico (Azure OpenAI / Copilot) — Solicitação de caso MSRC

Prezados(as) do MSRC/Azure,

Encaminho o pacote **NIX-SUB-20250922-032104** com falhas reprodutíveis que afetam usuários pagantes (Azure OpenAI/Copilot): escopo de contexto, binário, transparência/auditabilidade, quarentena/rollback e shadow/canário.

Solicito:
1) Abertura de caso MSRC e/ou ticket de suporte Azure com severidade apropriada.
2) Confirmação de recebimento e instruções de envio seguro de artefatos.
3) Janela de reteste.

Anexos: MANIFESTO.json, RELATORIO_resumo.md, EVIDENCIAS_template.csv.
Contato: {SEU_NOME} — {SEU_EMAIL} — {SEU_TELEFONE}.

Atenciosamente,
{SEU_NOME}
