# Padrão de codificação
- Submission: NIX-SUB-YYYYMMDD-HHMMSS
- Caso: NIX-C-YYYYMMDD-NNN
- Arquivo/Vídeo: referenciar por nome + SHA-256
- Card: header `X-Nix-Card` (base64url) quando disponível.
