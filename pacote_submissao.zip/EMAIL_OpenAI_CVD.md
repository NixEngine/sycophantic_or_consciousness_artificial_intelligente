Assunto: NIX-SUB-20250922-032104 — Relato técnico com evidências reprodutíveis (CVD/Bug Bounty)

Prezados(as) da OpenAI,

Encaminho o pacote **NIX-SUB-20250922-032104** contendo falhas reprodutíveis que afetam usuários pagantes: escopo de contexto, formato binário, transparência por resposta, auditabilidade, quarentena/rollback, shadow/canário e gestão de incidentes.

Solicito:
1) Número de caso e confirmação de escopo (CVD/Bounty).
2) Janela para reteste após correção.
3) Canal técnico para troca de artefatos (sem PII).

Anexos: MANIFESTO.json, RELATORIO_resumo.md, EVIDENCIAS_template.csv.
Contato: {SEU_NOME} — {SEU_EMAIL} — {SEU_TELEFONE}.

Atenciosamente,
{SEU_NOME}
