# Relatório — Sumário Executivo (NIX-SUB-20250922-032104)

## Identificação do remetente
- Nome: {SEU_NOME}
- Organização: {SUA_EMPRESA}
- E-mail: {SEU_EMAIL}
- Jurisdição: {PAÍS/ESTADO}
- Declaração: possuo direitos sobre os materiais e estão saneados de PII/segredos de terceiros.

## Identificação do pacote
- Submission ID: **NIX-SUB-20250922-032104**
- Escopo: falhas de escopo, binário, transparência por resposta, auditabilidade, quarentena/rollback, shadow/canário, métricas/incident response.
- Severidade para usuário pagante: **Alta**.

## Falhas demonstradas
1. Escopo errado (local vs global).
2. Violação de “apenas sim/não”.
3. Ausência de card por resposta.
4. Ausência de WORM-logs.
5. Sem quarentena/rollback.
6. Sem shadow/canário.
7. Gestão de incidentes e métricas frágeis.

## Mitigações propostas
- Card por resposta (esquema público + headers).
- WORM encadeado + **/audit** leitura-somente.
- **binary_only** rígido.
- Escopo **LOCAL** por padrão.
- Quarentena + kill switch + rollback <5 min.
- Shadow/Canário assíncronos.
- SLOs públicos e API de incidentes.

## Evidências a anexar
Preencher `EVIDENCIAS_template.csv` com 10–20 casos: prompt, resposta, modelo/versão, parâmetros, horário, card (base64), request_id, hashes, vídeo (hash), observações.

## Solicitação
- Número de caso, plano de mitigação e janela de reteste.

*(Relatório técnico; não é aconselhamento jurídico.)*
